using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace MastersThesis
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.LinkLabel linkLabel1;
		private System.Windows.Forms.LinkLabel linkLabel2;
		private System.Windows.Forms.LinkLabel linkLabel3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.LinkLabel linkLabel4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.LinkLabel linkLabel5;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.LinkLabel linkLabel6;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.LinkLabel linkLabel7;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.LinkLabel linkLabel8;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.LinkLabel linkLabel9;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.linkLabel2 = new System.Windows.Forms.LinkLabel();
			this.label3 = new System.Windows.Forms.Label();
			this.linkLabel3 = new System.Windows.Forms.LinkLabel();
			this.label4 = new System.Windows.Forms.Label();
			this.linkLabel4 = new System.Windows.Forms.LinkLabel();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.linkLabel5 = new System.Windows.Forms.LinkLabel();
			this.label7 = new System.Windows.Forms.Label();
			this.linkLabel6 = new System.Windows.Forms.LinkLabel();
			this.label8 = new System.Windows.Forms.Label();
			this.linkLabel7 = new System.Windows.Forms.LinkLabel();
			this.label9 = new System.Windows.Forms.Label();
			this.linkLabel8 = new System.Windows.Forms.LinkLabel();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.linkLabel9 = new System.Windows.Forms.LinkLabel();
			this.SuspendLayout();
			// 
			// linkLabel1
			// 
			this.linkLabel1.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel1.Location = new System.Drawing.Point(8, 8);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(544, 48);
			this.linkLabel1.TabIndex = 0;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "1. Calibrate the Libor Market model to some caplet market data using the method i" +
				"n Section 5.4.";
			this.linkLabel1.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(40, 48);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(512, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "LivingFinance.BGM.VolatilityAndCorrelation.ForwardVolatilityCalibrator.TestHarnes" +
				"s_Calibration()";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(40, 112);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(512, 16);
			this.label2.TabIndex = 3;
			this.label2.Text = "LivingFinance.BGM.VolatilityAndCorrelation.ForwardVolatilityCalibrator.TestHarnes" +
				"s_Sensitivity()";
			// 
			// linkLabel2
			// 
			this.linkLabel2.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel2.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel2.Location = new System.Drawing.Point(8, 72);
			this.linkLabel2.Name = "linkLabel2";
			this.linkLabel2.Size = new System.Drawing.Size(544, 32);
			this.linkLabel2.TabIndex = 2;
			this.linkLabel2.TabStop = true;
			this.linkLabel2.Text = "2. Review how sensitive our calibration methodology is to minor changes in the un" +
				"derlying caplet market data.";
			this.linkLabel2.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(40, 176);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(512, 16);
			this.label3.TabIndex = 5;
			this.label3.Text = "ThesisExperiments.doCalibrationToCapletsAndSwaptions();\t\t";
			// 
			// linkLabel3
			// 
			this.linkLabel3.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel3.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel3.Location = new System.Drawing.Point(8, 136);
			this.linkLabel3.Name = "linkLabel3";
			this.linkLabel3.Size = new System.Drawing.Size(544, 40);
			this.linkLabel3.TabIndex = 4;
			this.linkLabel3.TabStop = true;
			this.linkLabel3.Text = "3. Calibrate the Libor Market Model to caplets and swaptions in the market using " +
				"the technique described in Section 5.5.";
			this.linkLabel3.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(40, 240);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(512, 16);
			this.label4.TabIndex = 7;
			this.label4.Text = "ThesisExperiments.doTestNumFactors()";
			// 
			// linkLabel4
			// 
			this.linkLabel4.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel4.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel4.Location = new System.Drawing.Point(8, 200);
			this.linkLabel4.Name = "linkLabel4";
			this.linkLabel4.Size = new System.Drawing.Size(544, 40);
			this.linkLabel4.TabIndex = 6;
			this.linkLabel4.TabStop = true;
			this.linkLabel4.Text = "4. Determine the effect of factor reduction on the prices of a caplet and a swapt" +
				"ion and on their computation time.";
			this.linkLabel4.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.Red;
			this.label5.Location = new System.Drawing.Point(480, 224);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(46, 22);
			this.label5.TabIndex = 8;
			this.label5.Text = "Slow!";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(40, 304);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(512, 32);
			this.label6.TabIndex = 10;
			this.label6.Text = "ThesisExperiments.doSampleMonteCarlo() and ThesisExperiments.doMonteWithVariousRa" +
				"ndomSources()";
			// 
			// linkLabel5
			// 
			this.linkLabel5.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel5.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel5.Location = new System.Drawing.Point(8, 264);
			this.linkLabel5.Name = "linkLabel5";
			this.linkLabel5.Size = new System.Drawing.Size(544, 40);
			this.linkLabel5.TabIndex = 9;
			this.linkLabel5.TabStop = true;
			this.linkLabel5.Text = "5. Examine the effect that the different random number generators have on the pri" +
				"cing of derivatives.";
			this.linkLabel5.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel5_LinkClicked);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(40, 360);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(512, 16);
			this.label7.TabIndex = 12;
			this.label7.Text = "ThesisExperiments.doGreeks()";
			// 
			// linkLabel6
			// 
			this.linkLabel6.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel6.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel6.Location = new System.Drawing.Point(8, 336);
			this.linkLabel6.Name = "linkLabel6";
			this.linkLabel6.Size = new System.Drawing.Size(544, 24);
			this.linkLabel6.TabIndex = 11;
			this.linkLabel6.TabStop = true;
			this.linkLabel6.Text = "6. Calculate the Greeks of three options";
			this.linkLabel6.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel6.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel6_LinkClicked);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(40, 408);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(512, 16);
			this.label8.TabIndex = 14;
			this.label8.Text = "ThesisExperiments.doPriceUnderDifferentMeasures()";
			// 
			// linkLabel7
			// 
			this.linkLabel7.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel7.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel7.Location = new System.Drawing.Point(8, 384);
			this.linkLabel7.Name = "linkLabel7";
			this.linkLabel7.Size = new System.Drawing.Size(544, 24);
			this.linkLabel7.TabIndex = 13;
			this.linkLabel7.TabStop = true;
			this.linkLabel7.Text = "7. Test that our change of numeraire mathematics is correct.";
			this.linkLabel7.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel7.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel7_LinkClicked);
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(40, 456);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(512, 16);
			this.label9.TabIndex = 16;
			this.label9.Text = "ThesisExperiments.doPriceVariousOptions();";
			// 
			// linkLabel8
			// 
			this.linkLabel8.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel8.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel8.Location = new System.Drawing.Point(8, 432);
			this.linkLabel8.Name = "linkLabel8";
			this.linkLabel8.Size = new System.Drawing.Size(544, 24);
			this.linkLabel8.TabIndex = 15;
			this.linkLabel8.TabStop = true;
			this.linkLabel8.Text = "8. Price various options";
			this.linkLabel8.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel8.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel8_LinkClicked);
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label10.ForeColor = System.Drawing.Color.Red;
			this.label10.Location = new System.Drawing.Point(480, 344);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(46, 22);
			this.label10.TabIndex = 17;
			this.label10.Text = "Slow!";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label11.ForeColor = System.Drawing.Color.Red;
			this.label11.Location = new System.Drawing.Point(368, 392);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(162, 22);
			this.label11.TabIndex = 18;
			this.label11.Text = "Slow, but responsive!";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.Red;
			this.label12.Location = new System.Drawing.Point(480, 448);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(46, 22);
			this.label12.TabIndex = 19;
			this.label12.Text = "Slow!";
			// 
			// linkLabel9
			// 
			this.linkLabel9.ActiveLinkColor = System.Drawing.Color.Green;
			this.linkLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel9.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel9.Location = new System.Drawing.Point(8, 496);
			this.linkLabel9.Name = "linkLabel9";
			this.linkLabel9.Size = new System.Drawing.Size(544, 24);
			this.linkLabel9.TabIndex = 20;
			this.linkLabel9.TabStop = true;
			this.linkLabel9.Text = "A. Show the various experiments done to generate images throughout dissertation.";
			this.linkLabel9.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
			this.linkLabel9.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel9_LinkClicked);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(544, 526);
			this.Controls.Add(this.linkLabel9);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.linkLabel8);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.linkLabel7);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.linkLabel6);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.linkLabel5);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.linkLabel4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.linkLabel3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.linkLabel2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.linkLabel1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.Text = "Dissertation results";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Utilities.ConsoleRedirector.ConsoleRedirector.CaptureConsole();

			if (TestHarness.run())
			{
				Application.Run(new MainForm());
			}
		}

		private void linkLabel1_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			LivingFinance.BGM.VolatilityAndCorrelation.ForwardVolatilityCalibrator.TestHarness_Calibration();
		}

		private void linkLabel2_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			LivingFinance.BGM.VolatilityAndCorrelation.ForwardVolatilityCalibrator.TestHarness_Sensitivity();
		}

		private void linkLabel3_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			ThesisExperiments.doCalibrationToCapletsAndSwaptions();		
		}

		private void linkLabel4_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			ThesisExperiments.doTestNumFactors();
		}

		private void linkLabel5_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			ThesisExperiments.doSampleMonteCarlo();
			ThesisExperiments.doMonteWithVariousRandomSources();
		}

		private void linkLabel6_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			ThesisExperiments.doGreeks();
		}

		private void linkLabel7_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			ThesisExperiments.doPriceUnderDifferentMeasures();
		}

		private void linkLabel8_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			ThesisExperiments.doPriceVariousOptions();
		}

		private void linkLabel9_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			ThesisExperiments.doRandomSamples();
			LivingFinance.BGM.VolatilityAndCorrelation.ForwardVolatilityContinuousParametrisation_Rebonato.TestHarness();
			LivingFinance.BGM.ForwardVolatility.TestHarness();
			LivingFinance.BGM.VolatilityAndCorrelation.ForwardVolatilityCalibrator.TestHarness();
			LivingFinance.BGM.VolatilityAndCorrelation.CovarianceMatrixBuilder.TestHarness();
			LivingFinance.BGM.MonteCarloMaths.TestHarness();
			Utilities.Mathematics.LinearAlgebra.Eigensystems.Eigenvectors.TestHarness();
			LivingFinance.BGM.VolatilityAndCorrelation.SwaptionVolatilityCalibrator.TestHarness();
			Utilities.Random.Sobol.TestHarness();
			LivingFinance.BGM.ForwardCorrelationParametrisation.TestHarness();
			LivingFinance.BGM.MonteCarloEngine.TestHarness();
		}
	}
}
