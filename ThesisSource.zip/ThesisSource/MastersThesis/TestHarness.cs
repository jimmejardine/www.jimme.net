using System;
using System.Threading;
using Utilities.GUI.Charting;
using Utilities.Random;

namespace MastersThesis
{
	public class TestHarness
	{
		
		public static bool run()
		{
			try
			{
				Console.WriteLine("Masters thesis test harness");

//				LivingFinance.BGM.VolatilityAndCorrelation.ForwardVolatilityContinuousParametrisation_Rebonato.TestHarness();
//				LivingFinance.BGM.ForwardVolatility.TestHarness();
//				LivingFinance.BGM.VolatilityAndCorrelation.ForwardVolatilityCalibrator.TestHarness();
//				LivingFinance.BGM.VolatilityAndCorrelation.CovarianceMatrixBuilder.TestHarness();
//				LivingFinance.BGM.MonteCarloMaths.TestHarness();
//				Utilities.Mathematics.LinearAlgebra.Eigensystems.Eigenvectors.TestHarness();
//				LivingFinance.BGM.VolatilityAndCorrelation.SwaptionVolatilityCalibrator.TestHarness();
//				Utilities.Random.Sobol.TestHarness();
//				LivingFinance.BGM.ForwardCorrelationParametrisation.TestHarness();
//				LivingFinance.BGM.MonteCarloEngine.TestHarness();
//				Utilities.GUI.Charting.MultiChart2D.TestHarness();
			}

			catch (Exception e)
			{
				Console.WriteLine(e.ToString());
			}

			return true;
		}
	}
}
