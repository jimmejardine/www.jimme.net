using System;
using System.Threading;
using Utilities.Mathematics.LinearAlgebra;
using LivingFinance.Options.Equity.Portfolios;
using Utilities.Random;
using Utilities.GUI.Charting;
using LivingFinance.BGM;
using LivingFinance.BGM.Products;
using LivingFinance.BGM.VolatilityAndCorrelation;
using LivingFinance.BGM.Engine;

namespace MastersThesis
{
	public class ThesisExperiments
	{
		// --------------------------------------------------------------------------------------------------------------

		public static void doCalibrationToCapletsAndSwaptions()
		{
			LivingFinance.BGM.VolatilityAndCorrelation.SwaptionVolatilityCalibrator.TestHarness();
		}

		// --------------------------------------------------------------------------------------------------------------

		public static void TestVanillaCaplet(Vector Ti, Vector delta, Vector L0)
		{
			// Calculate the target price of our caplet - a caplet from T1 to T2
			//			double caplet_price = delta[2] * Options.Vanilla.Black76.calculatePrice_UsingCumulativeVol(PutCallType.CALL, STRIKE, Ti[1], L0[2], covariances[1][2,2], P0[2]);
			//			Console.WriteLine("The analytical price is {0}", caplet_price);
			double caplet_price = 0;
			double NUM_REPS = 0;

			Series series_analytic = new Series("Analytic", ChartType.Line);
			series_analytic.addPoint(1, caplet_price);
			series_analytic.addPoint(NUM_REPS, caplet_price);

			MultiChart2D chart = new MultiChart2D();
			chart.addSeries(series_analytic);
			
			chart.title = "Chart of Monte Carlo and analytical price of a caplet";
			chart.x_axis_title = "Iteration";
			chart.y1_axis_title = "Caplet price";

			chart.y1_axis_min = 0.00484;
			chart.y1_axis_max = 0.00486;


			SingleControlForm form = new SingleControlForm();
			form.setControl(chart);
			form.ShowDialog();
		}

		// --------------------------------------------------------------------------------------------------------------

		public static void TestNumFactors_INSTANCE(int N, int NUM_FACTORS, out PricingResults pricing_results_caplet, out PricingResults pricing_results_swaption)
		{
			const int NUM_REPS = 1024*32*4;
			const int OUTPUT_PERIOD = NUM_REPS / 256;
		
			bool VERBOSE = false;

			const double STRIKE = 0.005;


			// Define the maturities and initial forward curve
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);

			// Define our volatility and correlation parametrisations
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, NUM_FACTORS);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);
			CovarianceMatrixSource covariance_matrix_source = covariance_matrix_builder;

			IUniformRandomSource random = new Sobol(N*NUM_FACTORS);

			
			// A caplet - antithetic
			IProduct product_caplet = new LivingFinance.BGM.Products.Caplet(N-2, STRIKE);
			pricing_results_caplet = MonteCarloEngine.price(VERBOSE, false, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_caplet);
			
			// A swaption
			IProduct product_swaption = new LivingFinance.BGM.Products.Swaption(2, STRIKE);
			pricing_results_swaption = MonteCarloEngine.price(VERBOSE, false, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_swaption);
		}

		public static void doTestNumFactors()
		{
			int[] NUM_FACTOR_CHOICES =
			{
				1, 2, 3, 4, 6, 8, 10
			};

			Series series_caplet = new Series("Caplet", ChartType.LineAndPoint);
			Series series_timetaken_caplet = new Series("CPU time", ChartType.LineAndPoint);
			Series series_swaption = new Series("Swaption", ChartType.LineAndPoint);
			Series series_timetaken_swaption = new Series("CPU time", ChartType.LineAndPoint);

			for (int i = 0; i < NUM_FACTOR_CHOICES.Length; ++i)
			{
				int NUM_FACTORS = NUM_FACTOR_CHOICES[i];

				PricingResults pricing_results_caplet;
				PricingResults pricing_results_swaption;
				TestNumFactors_INSTANCE(10, NUM_FACTORS, out pricing_results_caplet, out pricing_results_swaption);

				series_caplet.addPoint(NUM_FACTORS, pricing_results_caplet.price);
				series_timetaken_caplet.addPoint(NUM_FACTORS, pricing_results_caplet.time_taken);
				series_swaption.addPoint(NUM_FACTORS, pricing_results_swaption.price);
				series_timetaken_swaption.addPoint(NUM_FACTORS, pricing_results_swaption.time_taken);

				Console.WriteLine("NUM_FACTORS is {0}", NUM_FACTORS);
				
				Console.WriteLine("Priced a caplet");
				Console.WriteLine("It took {0} seconds", pricing_results_caplet.time_taken);
				Console.WriteLine("Price is {0}", pricing_results_caplet.price);

				Console.WriteLine("Priced a swaption");
				Console.WriteLine("It took {0} seconds", pricing_results_swaption.time_taken);
				Console.WriteLine("Price is {0}", pricing_results_swaption.price);

				Console.WriteLine();
			}

			// First the caplet
		
			MultiChart2D chart_caplet = new MultiChart2D();
			chart_caplet.addSeries(series_caplet);
			chart_caplet.addSeries(series_timetaken_caplet);
			series_timetaken_caplet.chartaxis = ChartAxis.Secondary;			
			
			chart_caplet.title = "Chart of simulation results of a caplet for different number of factors";
			chart_caplet.x_axis_title = "Number of factors";
			chart_caplet.y1_axis_title = "Option price";
			chart_caplet.y2_axis_title = "Time taken";

			SingleControlForm form_caplet = new SingleControlForm();
			form_caplet.setControl(chart_caplet);
			form_caplet.ShowDialog();

			// Then the swaption

			MultiChart2D chart_swaption = new MultiChart2D();
			chart_swaption.addSeries(series_swaption);
			chart_swaption.addSeries(series_timetaken_swaption);
			series_timetaken_swaption.chartaxis = ChartAxis.Secondary;			
			
			chart_swaption.title = "Chart of simulation results of a swaption for different number of factors";
			chart_swaption.x_axis_title = "Number of factors";
			chart_swaption.y1_axis_title = "Option price";
			chart_swaption.y2_axis_title = "Time taken";

			SingleControlForm form_swaption = new SingleControlForm();
			form_swaption.setControl(chart_swaption);
			form_swaption.ShowDialog();
		}

		// --------------------------------------------------------------------------------------------------------------

		public static void doSampleMonteCarlo()
		{
			const int N = 5;
			const int NUM_FACTORS = 4;

			const int NUM_REPS = 1024*32*4;
			const int OUTPUT_PERIOD = NUM_REPS / 256;
		
			bool VERBOSE = false;

			const double STRIKE = 0.005;

			// Define the maturities and initial forward curve
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);

			// Define our volatility and correlation parametrisations
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, NUM_FACTORS);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);
			CovarianceMatrixSource covariance_matrix_source = covariance_matrix_builder;

			IUniformRandomSource random = new Sobol(N*NUM_FACTORS);

			
			// A caplet - antithetic
			IProduct product_caplet = new LivingFinance.BGM.Products.Caplet(N-2, STRIKE);
			PricingResults pricing_results_caplet = MonteCarloEngine.price(VERBOSE, false, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_caplet);			

			MultiChart2D chart = new MultiChart2D();
			chart.addSeries(pricing_results_caplet.series_price);
			chart.addSeries(pricing_results_caplet.series_error);
			pricing_results_caplet.series_error.chartaxis = ChartAxis.Secondary;			
			
			chart.title = "An example of a Monte Carlo simulation";
			chart.x_axis_title = "Iterations";
			chart.y1_axis_title = "Price";
			chart.y2_axis_title = "Standard error";

			chart.y2_axis_min = 0;
			chart.y2_axis_max = 0.002;

			SingleControlForm form = new SingleControlForm();
			form.setControl(chart);
			form.ShowDialog();
		}

		// --------------------------------------------------------------------------------------------------------------

		public static void doRandomSamples()
		{
			IUniformRandomSource random_sobol = new Sobol(2);
			IUniformRandomSource random_mersenne = new MersenneTwister(1);
			IUniformRandomSource random_antithetic = new AntitheticRandomSource(new MersenneTwister(1));

			Series series_sobol = new Series("Sobol", ChartType.Point);
			Series series_mersenne = new Series("Mersenne", ChartType.Point);
			Series series_antithetic = new Series("Antithetic Mersenne", ChartType.Point);

			const int N = 512;
			Vector v = new Vector(2);

			for (int i = 0; i < N; ++i)
			{	
				random_sobol.nextRandomVector(v);
				series_sobol.addPoint(v[0], v[1]);

				random_mersenne.nextRandomVector(v);
				series_mersenne.addPoint(v[0], v[1]);

				random_antithetic.nextRandomVector(v);
				series_antithetic.addPoint(v[0], v[1]);

			}

			MultiChart2D chart = new MultiChart2D();
			chart.x_axis_min = 0;
			chart.x_axis_max = 1;
			chart.y1_axis_min = 0;
			chart.y1_axis_max = 1;
			chart.legend_height = 0;


			SingleControlForm form = new SingleControlForm();
			form.setControl(chart);
			form.Width = form.Height = 500;

			chart.clearSeries();
			chart.title = "Random numbers - � la Sobol";
			chart.addSeries(series_sobol);
			form.ShowDialog();

			chart.clearSeries();
			chart.title = "Random numbers - � la Mersenne";
			chart.addSeries(series_mersenne);
			form.ShowDialog();

			chart.clearSeries();
			chart.title = "Random numbers - � la Antithetic Mersenne";
			chart.addSeries(series_antithetic);
			form.ShowDialog();
		}
		
		// --------------------------------------------------------------------------------------------------------------

		public static void doMonteWithVariousRandomSources()
		{
			const int N = 5;
			const int NUM_FACTORS = 3;

			IUniformRandomSource random_sobol = new Sobol(N*NUM_FACTORS);
			IUniformRandomSource random_mersenne = new MersenneTwister(1);
			IUniformRandomSource random_antithetic = new AntitheticRandomSource(new MersenneTwister(1));

//			const int NUM_REPS = 1024*32*4;
			const int NUM_REPS = 1024*16*4;
			const int OUTPUT_PERIOD = NUM_REPS / 256;
		
			bool VERBOSE = false;

			const double STRIKE = 0.005;

			// Define the maturities and initial forward curve
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);

			// Define our volatility and correlation parametrisations
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, NUM_FACTORS);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);
			CovarianceMatrixSource covariance_matrix_source = covariance_matrix_builder;
			
			// A caplet - antithetic
			IProduct product_caplet = new LivingFinance.BGM.Products.Caplet(N-2, STRIKE);
			PricingResults pricing_results_caplet_sobol = MonteCarloEngine.price(VERBOSE, false, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random_sobol, product_caplet);
			PricingResults pricing_results_caplet_mersenne = MonteCarloEngine.price(VERBOSE, false, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random_mersenne, product_caplet);
			PricingResults pricing_results_caplet_antithetic = MonteCarloEngine.price(VERBOSE, false, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random_antithetic, product_caplet);

			pricing_results_caplet_sobol.series_price.name = "Sobol";
			pricing_results_caplet_mersenne.series_price.name = "Mersenne";
			pricing_results_caplet_antithetic.series_price.name = "Antithetic Mersenne";
			
			MultiChart2D chart = new MultiChart2D();
			chart.addSeries(pricing_results_caplet_sobol.series_price);
			chart.addSeries(pricing_results_caplet_mersenne.series_price);
			chart.addSeries(pricing_results_caplet_antithetic.series_price);
			
			chart.title = "Illustration of the power of Sobol sequences and of antithetic variables";
			chart.x_axis_title = "Iterations";
			chart.y1_axis_title = "Price";

			SingleControlForm form = new SingleControlForm();
			form.setControl(chart);
			form.ShowDialog();
		}

		// --------------------------------------------------------------------------------------------------------------

		static PricingResults doPriceUnderDifferentMeasures_INSTANCE(int N)
		{
			int NUM_FACTORS = 4;

			const int NUM_REPS = 1024*32*4;
			const int OUTPUT_PERIOD = NUM_REPS / 256;
		
			bool VERBOSE = false;

			const double STRIKE = 0.005;


			// Define the maturities and initial forward curve
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);

			// Define our volatility and correlation parametrisations
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, NUM_FACTORS);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);
			CovarianceMatrixSource covariance_matrix_source = covariance_matrix_builder;

			IUniformRandomSource random = new Sobol(N*NUM_FACTORS);
			
			// A caplet
			IProduct product_caplet = new LivingFinance.BGM.Products.Caplet(2, STRIKE);
			return MonteCarloEngine.price(VERBOSE, false, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_caplet);
		}

		public static void doPriceUnderDifferentMeasures()
		{
			
			Series series_price = new Series("Price", ChartType.LineAndPoint);
			Series series_stderr = new Series("Standard error", ChartType.LineAndPoint);
			series_stderr.chartaxis = ChartAxis.Secondary;			
			
			MultiChart2D chart = new MultiChart2D();
			chart.addSeries(series_price);
			chart.addSeries(series_stderr);
			
			chart.title = "Effect of choice of numeraire";
			chart.x_axis_title = "Numeraire expiry";
			chart.y1_axis_title = "Price";
			chart.y2_axis_title = "Standard error";

			chart.y1_axis_min = 0.0048;
			chart.y1_axis_max = 0.0049;
			chart.y2_axis_min = 6E-6;
			chart.y2_axis_max = 2E-5;

			SingleControlForm form = new SingleControlForm();
			form.setControl(chart);
			form.Show();

			for (int i = 4; i < 20; ++i)
			{
				PricingResults pr = doPriceUnderDifferentMeasures_INSTANCE(i);

				series_price.addPoint(i, pr.price);
				series_stderr.addPoint(i, pr.standard_error);
				chart.Refresh();

				System.Console.WriteLine("{0}\t{1}\t{2}", i, pr.price, pr.standard_error);
			}

			form.Hide();
			form.ShowDialog();
		}

		// --------------------------------------------------------------------------------------------------------------

		public static void doGreeks()
		{
			int N = 10;
			int NUM_FACTORS = 4;

			const int NUM_REPS = 1024*32*4;
			const int OUTPUT_PERIOD = NUM_REPS / 256;
		
			bool VERBOSE = false;

			const double STRIKE = 0.005;


			// Define the maturities and initial forward curve
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getUniformMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);

			// Define our volatility and correlation parametrisations
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, NUM_FACTORS);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);
			CovarianceMatrixSource covariance_matrix_source = covariance_matrix_builder;

			IUniformRandomSource random = new Sobol(N*NUM_FACTORS);
			
			// A caplet
			IProduct product_caplet2 = new LivingFinance.BGM.Products.Caplet(2, STRIKE);
			PricingResults pr_caplet2 = MonteCarloEngine.price(VERBOSE, true, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_caplet2);
			System.Console.WriteLine("Caplet 2");
			System.Console.WriteLine(pr_caplet2.price);
			System.Console.WriteLine("Delta");
			System.Console.WriteLine(pr_caplet2.greeks_delta);
			System.Console.WriteLine("Gamma");
			System.Console.WriteLine(pr_caplet2.greeks_gamma);

			IProduct product_caplet4 = new LivingFinance.BGM.Products.Caplet(4, STRIKE);
			PricingResults pr_caplet4 = MonteCarloEngine.price(VERBOSE, true, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_caplet4);
			System.Console.WriteLine("Caplet 4");
			System.Console.WriteLine(pr_caplet4.price);
			System.Console.WriteLine("Delta");
			System.Console.WriteLine(pr_caplet4.greeks_delta);
			System.Console.WriteLine("Gamma");
			System.Console.WriteLine(pr_caplet4.greeks_gamma);
	
			IProduct product_swaption = new LivingFinance.BGM.Products.Swaption(4, STRIKE);
			PricingResults pr_swaption = MonteCarloEngine.price(VERBOSE, true, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_swaption);
			System.Console.WriteLine("Swaption");
			System.Console.WriteLine(pr_swaption.price);
			System.Console.WriteLine("Delta");
			System.Console.WriteLine(pr_swaption.greeks_delta);
			System.Console.WriteLine("Gamma");
			System.Console.WriteLine(pr_swaption.greeks_gamma);
		}

		static void doPriceVariousOptions_Instance(IProduct product)
		{
			int N = 8;
			int NUM_FACTORS = 4;

			const int NUM_REPS = 1024*32;
			const int OUTPUT_PERIOD = NUM_REPS / 256;
		
			bool VERBOSE = false;

			// Define the maturities and initial forward curve
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getUniformMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);

			// Define our volatility and correlation parametrisations
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, NUM_FACTORS);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);
			CovarianceMatrixSource covariance_matrix_source = covariance_matrix_builder;

			IUniformRandomSource random = new Sobol(N*NUM_FACTORS);
			random.reset();
			
			System.Console.WriteLine(product);
			PricingResults pricingresults = MonteCarloEngine.price(VERBOSE, true, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product);
			System.Console.WriteLine("Price");
			System.Console.WriteLine(pricingresults.price);
			System.Console.WriteLine("Delta");
			System.Console.WriteLine(pricingresults.greeks_delta);
			System.Console.WriteLine("Gamma");
			System.Console.WriteLine(pricingresults.greeks_gamma);
		}

		public static void doPriceVariousOptions()
		{
			int N = 8;
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);

			doPriceVariousOptions_Instance(new LivingFinance.BGM.Products.Caplet(4, 0.085));
			doPriceVariousOptions_Instance(new LivingFinance.BGM.Products.DownAndOutCaplet(4, 0.085, 0.075));
//			doPriceVariousOptions_Instance(new LivingFinance.BGM.Products.Cap(2, 7, STRIKE));
//			doPriceVariousOptions_Instance(new LivingFinance.BGM.Products.LimitCap(2, 7, 2, STRIKE));
//			doPriceVariousOptions_Instance(new LivingFinance.BGM.Products.Swaption(2, STRIKE));
//			doPriceVariousOptions_Instance(new LivingFinance.BGM.Products.TriggerSwap(2, L0[1]));
		}
	}
}
