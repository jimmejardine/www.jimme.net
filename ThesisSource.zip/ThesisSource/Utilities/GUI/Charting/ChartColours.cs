using System;
using System.Drawing;

using Utilities.Random;

namespace Utilities.GUI.Charting
{
	public class ChartColours
	{
		public static Color getOrderedColour(int i)
		{
			switch (i)
			{
				case 0:
					return Color.Red;
				case 1:
					return Color.Orange;
				case 2:
					return Color.Blue;
				case 3:
					return Color.Green;
				case 4:
					return Color.Violet;
				case 5:
					return Color.Indigo;
				case 6:
					return Color.Yellow;
				case 7:
					return Color.Brown;
				default:
				{
					RandomAugmented random = RandomAugmented.getSeededRandomAugmented();
					return Utilities.Colours.getRandomBrilliantColour(random);
				}
			}
		}
	}
}
