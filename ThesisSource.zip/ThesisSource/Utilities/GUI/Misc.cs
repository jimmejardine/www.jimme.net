using System;
using System.Windows.Forms;

namespace Utilities.GUI
{
	public class Misc
	{
	}
}
