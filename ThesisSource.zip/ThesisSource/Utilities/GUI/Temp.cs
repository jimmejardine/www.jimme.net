using System;

namespace Utilities.GUI
{
	/// <summary>
	/// Summary description for Temp.
	/// </summary>
	public class Temp
	{
		public Temp()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
