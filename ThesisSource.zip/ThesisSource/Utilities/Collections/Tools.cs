using System;
using System.Collections;

namespace Utilities.Collections
{
	public class Tools
	{
		public static ArrayList removeDuplicates(ArrayList input)
		{
			input.Sort();
			ArrayList result = new ArrayList();
			object last_item = null;
			foreach (object current in input)
			{
				if (!current.Equals(last_item))
				{
					result.Add(current);
					last_item = current;
				}
			}

			return result;
		}
		
		public static object[] enumeratorToObjectArray(IEnumerator i)
		{
			ArrayList list = new ArrayList();
			while (i.MoveNext())
			{
				list.Add(i.Current);
			}

			return list.ToArray();			
		}
	}
}
