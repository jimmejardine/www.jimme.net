using System;

namespace Utilities.Collections
{
	public class Set
	{
		Object _dummy = new Object();

		System.Collections.Hashtable _set;
		
		public Set()
		{
			_set = new System.Collections.Hashtable();
		}

		public void Add(object item)
		{
			if (!_set.Contains(item))
			{
				_set.Add(item, _dummy);
			}
		}

		public void Remove(object item)
		{
			_set.Remove(item);
		}

		public int Count
		{
			get { return _set.Count; }
		}

		public System.Collections.IEnumerator GetEnumerator()
		{
			return _set.Keys.GetEnumerator();
		}
	}
}
