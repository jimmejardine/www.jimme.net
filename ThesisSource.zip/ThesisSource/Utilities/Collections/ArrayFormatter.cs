using System;
using System.Text;
using System.Collections;


namespace Utilities.Collections
{
	public class ArrayFormatter
	{
		public static string listElements(System.Array array)
		{
			StringBuilder sb = new StringBuilder();
			foreach (Object i in array)
			{
				sb.Append(i);
				sb.Append(", ");
			}
			return sb.ToString();
		}

		public static string listElements(System.Collections.ICollection array)
		{
			return listElements(array, ", ");
		}

		public static string listElements(System.Collections.ICollection array, string separator)
		{
			StringBuilder sb = new StringBuilder();
			foreach (Object i in array)
			{
				sb.Append(i);
				sb.Append(separator);
			}
			return sb.ToString();
		}


		public static string listHashtableElements(Hashtable counters)
		{
			StringBuilder sb = new StringBuilder();
			foreach (object key in counters.Keys)
			{
				object counter = counters[key];

				sb.AppendFormat("{0}\t{1}\r\n", key, counter);
			}

			return sb.ToString();
		}
	}
}
