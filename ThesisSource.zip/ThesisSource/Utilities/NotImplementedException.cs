using System;

namespace Utilities
{
	public class NotImplementedException : GenericException
	{
		public NotImplementedException() : base("Not yet implemented.")
		{
			
		}
	}
}
