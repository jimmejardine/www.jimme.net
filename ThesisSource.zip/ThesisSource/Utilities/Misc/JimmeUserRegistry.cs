using System;
using Microsoft.Win32;

namespace Utilities.Misc
{
	public class JimmeUserRegistry
	{
		string _appname;

		public JimmeUserRegistry(string appname)
		{
			_appname = appname;
		}

		private RegistryKey getAppKey()
		{
			return Registry.CurrentUser.CreateSubKey("Software").CreateSubKey("Jimme").CreateSubKey(_appname);
		}

		public void write(string key, string data)
		{
			RegistryKey appkey = getAppKey();
			appkey.SetValue(key, data);
			appkey.Close();
		}

		public string read(string key)
		{
			RegistryKey appkey = getAppKey();
			string data = (string) appkey.GetValue(key);
			appkey.Close();

			if (null == data) data = "";
			return data;
		}

		public void write(string section, string key, string data)
		{
			RegistryKey appkey = getAppKey();
			RegistryKey sub_appkey = appkey.CreateSubKey(section);
			sub_appkey.SetValue(key, data);
			sub_appkey.Close();
		}

		public string read(string section, string key)
		{
			RegistryKey appkey = getAppKey();
			RegistryKey sub_appkey = appkey.CreateSubKey(section);
			string data = (string) sub_appkey.GetValue(key);
			sub_appkey.Close();

			if (null == data) data = "";
			return data;
		}
	}
}
