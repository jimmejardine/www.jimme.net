using System;

namespace Utilities.DateTimeTools
{
	public class DateFormatter
	{
		public static string asMMYY(DateTime date)
		{
			string year_string = date.Year.ToString();
			return date.Month + "/" + year_string.Substring(2);
		}
	}
}
