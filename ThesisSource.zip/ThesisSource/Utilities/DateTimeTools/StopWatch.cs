using System;

namespace Utilities.DateTimeTools
{
	public class StopWatch
	{
		static DateTime NULL_TIME = DateTime.MinValue;

		DateTime start_timestamp = NULL_TIME;
		DateTime stop_timestamp = NULL_TIME;

		public StopWatch()
		{
			start();
		}

		public void start()
		{
			start_timestamp = DateTime.Now;
			stop_timestamp = NULL_TIME;
		}

		public void stop()
		{
			stop_timestamp = DateTime.Now;
		}

		public double elapsedSeconds()
		{
			if (NULL_TIME == stop_timestamp)
			{
				TimeSpan span = DateTime.Now.Subtract(start_timestamp);
				return span.TotalSeconds;
			}
			else
			{
				TimeSpan span = stop_timestamp.Subtract(start_timestamp);
				return span.TotalSeconds;
				
			}
		}

		public override string ToString()
		{
			if (NULL_TIME == stop_timestamp)
			{
				return "Started " + start_timestamp + ", elapsed " + elapsedSeconds() + " seconds";
			}
			else
			{
				return "Started " + start_timestamp + ", stopped " + stop_timestamp + ", elapsed " + elapsedSeconds() + " seconds";
			}
		}
	}
}
