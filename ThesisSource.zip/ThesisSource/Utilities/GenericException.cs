using System;

namespace Utilities
{
	public class GenericException : Exception
	{
		public GenericException(string message) : base(message)
		{		
		}
	}
}
