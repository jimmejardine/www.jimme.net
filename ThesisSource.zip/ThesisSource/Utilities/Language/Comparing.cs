using System;

namespace Utilities.Language
{
	/// <summary>
	/// Summary description for Comparing.
	/// </summary>
	public class Comparing
	{
		public static bool isKeyboardCompatible(char c1, char c2)
		{
			// Some straightforward tests
			if (c1 == c2) return true;

			// Case insensitive comapre now
			c1 = System.Char.ToLower(c1);
			c2 = System.Char.ToLower(c2);
			if (c1 == c2) return true;

			// Get it into canonical order for our more elaborate tests
			if (c1 > c2)
			{
				Utilities.Swap.swap(ref c1, ref c2);
			}

			// A non-exhaustive compare of augmented characters with the english character most similar
			// Is there a better method??!
			switch (c1)
			{
				case 'a':
					if ("�������".IndexOf(c2) != -1) return true;
					break;
				case 'e':
					if ("�����".IndexOf(c2) != -1) return true;
					break;
				case 'i':
					if ("����".IndexOf(c2) != -1) return true;
					break;
				case 'o':
					if ("�������".IndexOf(c2) != -1) return true;
					break;
				case 'u':
					if ("����".IndexOf(c2) != -1) return true;
					break;
				case 'y':
					if ("��".IndexOf(c2) != -1) return true;
					break;
				case 'n':
					if ("�".IndexOf(c2) != -1) return true;
					break;
			}

			// If nothing has matched so far, they must be different
			return false;
		}
	}
}
