using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace Utilities
{
	public class Colours
	{
		public static int mapToColour(double d)
		{
			return (int) (255*Math.Abs(d));
		}


		public static Color getRandomColour(Utilities.Random.RandomAugmented random)
		{
			double r = random.NextDouble();
			double g = random.NextDouble();
			double b = random.NextDouble();
			return Color.FromArgb((int) (255*r), (int) (255*g), (int) (255*b));
		}

		public static Color getRandomBrilliantColour(Utilities.Random.RandomAugmented random)
		{
			double r;
			double g;
			double b;
			getRandomBrilliantColour(random, out r, out g, out b);
			return Color.FromArgb((int) (255*r), (int) (255*g), (int) (255*b));
		}

		public static void getRandomBrilliantColour(Utilities.Random.RandomAugmented random, out double r, out double g, out double b)
		{
			r = g = b = 0.5;
			while
				( 
				(isValueNearBottom(r) && isValueNearBottom(g) && isValueNearBottom(b)) || 
				(isValueNearMiddle(r) && isValueNearMiddle(g)) || (isValueNearMiddle(r) && isValueNearMiddle(b)) || (isValueNearMiddle(g) && isValueNearMiddle(b)) 
				)
			{
				r = random.NextDouble();
				g = random.NextDouble();
				b = random.NextDouble();
			}
		}

		public static bool isValueNearMiddle(double d)
		{
			return (d > 0.25 && d < 0.75);
		}

		public static bool isValueNearBottom(double d)
		{
			return (d < 0.5);
		}
	}
}
