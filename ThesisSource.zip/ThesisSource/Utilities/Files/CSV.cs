using System;

namespace Utilities.Files
{
	public class CSV
	{
		public static string[] splitAtCommas(string source)
		{
			return source.Split(',');
		}
	}
}
