using System;

namespace Utilities.Files
{
	public class FileSystem
	{
		public static String getFilenameFromFullPathname(String longname)
		{
			int last_separator_pos = longname.LastIndexOf('\\');
			if (-1 == last_separator_pos) return longname;
			if (last_separator_pos+1 < longname.Length)
			{
				return longname.Substring(last_separator_pos+1);
			}
			else
			{
				return "";
			}
		}

		public static bool isValidFilenameCharacter(char c)
		{
			if (Char.IsLetterOrDigit(c)) return true;
			if ('-' == c) return true;
			if (' ' == c) return true;
			if ('.' == c) return true;
			if (',' == c) return true;
			if ('(' == c) return true;
			if (')' == c) return true;
			if ('_' == c) return true;
			if ('\'' == c) return true;

			return false;
		}


		public static string makeGoodFilename(string source)
		{
			string target = "";
			for (int i = 0; i < source.Length; ++i)
			{
				char c = source[i];
				if (isValidFilenameCharacter(c)) target = target + c;
			}

			return target;
		}
	}
}
