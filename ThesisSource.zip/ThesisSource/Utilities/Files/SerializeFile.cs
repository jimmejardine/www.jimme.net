using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Utilities.Files
{
	public class SerializeFile
	{
		public static void save(string filename, object animal_to_save)
		{
			Stream stream = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None);

			try
			{
				BinaryFormatter formatter = new BinaryFormatter();
				formatter.Serialize(stream, animal_to_save);
			}

			finally
			{
				stream.Close();
			}
		}
		
		public static object load(string filename)
		{	
			Stream stream = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read);

			try
			{
				BinaryFormatter formatter = new BinaryFormatter();
				Object animal_to_load = formatter.Deserialize(stream);
				return animal_to_load;
			}

			finally
			{
				stream.Close();
			}

			
		}

	}
}
