using System;
using System.IO;
using System.Collections;

namespace Utilities.Files
{
	public class TextFile
	{
		public static void saveTextFile(String filename, String[] lines)
		{
			StreamWriter sr = new StreamWriter(filename, false);

			try
			{
				foreach (String line in lines)
				{
					sr.WriteLine(line);
				}
			}

			finally
			{
				sr.Close();
			}
		}

		public static String[] loadTextFile(String filename)
		{
			return  loadTextFile(filename, false, false);
		}

		public static String[] loadTextFile(String filename, bool skip_comments, bool skip_empties)
		{
			ArrayList result = new ArrayList();
			StreamReader sr = Utilities.Files.FileOpener.openStreamReaderWithLocalCheck(filename);
			
			String next_line = null;
			while (null != (next_line = sr.ReadLine()))
			{
				// Shall we skip this line
				bool skip = (skip_comments && isComment(next_line)) || (skip_empties && (0 == next_line.Length));

				// Store only the non-skipped lines
				if (!skip)
				{
					result.Add(next_line);
				}
			}

			sr.Close();

			String return_type = "";
			return (String[]) result.ToArray(return_type.GetType());
		}

		public static bool isComment(string source)
		{
			return (source.StartsWith("//") || source.StartsWith("#"));
		}
	}
}
