using System;
using System.Collections;
using System.Text;

namespace Utilities.Strings
{
	public class StringTools
	{
		public static void TestHarness() 
		{
			StringArray resultA1 = splitAtChar("This is a  test and more   ", ' ');
			StringArray resultA2 = splitAtChar("This is a  test and more   so", ' ');
			StringArray resultA3 = splitAtChar("This is a  test and more   so  there! ", ' ');

			StringArray resultB1 = splitAtCharIgnoringDuplicates("This is a  test and more   ", ' ');
			StringArray resultB2 = splitAtCharIgnoringDuplicates("This is a  test and more   so", ' ');
			StringArray resultB3 = splitAtCharIgnoringDuplicates("This is a  test and more   so  there! ", ' ');
		}


		public static StringArray splitAtChar(string source, char delim)
		{
			StringArray result = new StringArray();
			int source_length = source.Length;
			int start_pos = 0;
			for (int i = 0; i < source_length; ++i)
			{
				// If we find a delimiter, chop out the string
				if (delim == source[i])
				{
					result.Add(source.Substring(start_pos, i - start_pos));
					start_pos = i + 1;
				}
			}

			// Add in the last item
			if (start_pos < source_length)
			{
				result.Add(source.Substring(start_pos, source_length - start_pos));
			}

			return result;
		}

		public static StringArray splitAtNewline(string source)
		{
			StringArray result = new StringArray();
			int source_length = source.Length;
			int start_pos = 0;
			for (int i = 0; i < source_length; ++i)
			{
				// If we find a \r or \n, chop out the string
				if ('\r' == source[i])
				{
					result.Add(source.Substring(start_pos, i - start_pos));
					start_pos = i + 1;

					// If \r is followed by \n ignore the \n
					if (start_pos < source_length && '\n' == source[start_pos])
					{
						++i;
						++start_pos;
					}
				}

				else if ('\n' == source[i])
				{
					result.Add(source.Substring(start_pos, i - start_pos));
					start_pos = i + 1;
				}
			}

			// Add in the last item
			if (start_pos < source_length)
			{
				result.Add(source.Substring(start_pos, source_length - start_pos));
			}

			return result;
		}
		
		public static StringArray splitAtCharIgnoringDuplicates(string source, char delim)
		{
			StringArray result = new StringArray();
			int source_length = source.Length;
			int start_pos = 0;
			for (int i = 0; i < source_length; ++i)
			{
				// If we find a delimiter, chop out the string
				if (delim == source[i])
				{
					result.Add(source.Substring(start_pos, i-start_pos));

					// Keep ignoring delimiters
					while (i < source_length && delim == source[i])
					{
						++i;
					}
					start_pos = i;
				}
			}

			// Add in the last item
			if (start_pos < source_length)
			{
				result.Add(source.Substring(start_pos, source_length-start_pos));
			}
			
			return result;
		}

		public static int getCharacterPositionOfRow(int row, string[] lines)
		{
			int position = 0;
			for (int i = 0; i < row; ++i)
			{
				position += lines[i].Length;
				position += 2;	//CRLF
			}

			return position;
		}

        public static void ChangeLfToCrLf(ref String buf)
        {
            byte[] abuf = new byte[256000];
            int abuf_index = 0;
            ASCIIEncoding ASCII = new ASCIIEncoding();

            int crCount = buf.IndexOf("\r", 0);
            if (crCount == -1)
            {    // No carriage returns
                buf = buf.Replace("\x0a", "\x0d\x0a");
                return;
            }
            int bufsize = buf.Length;
            for (int i = 0; i < bufsize - 1; i++)
            {
                char ch = buf[i];
                char nextch = buf[i + 1];
                if (ch == '\n')
                {
                    if (nextch != '\r')
                    {
                        abuf[abuf_index++] = (byte)'\r';
                        abuf[abuf_index++] = (byte)'\n';
                    }
                    else abuf[abuf_index++] = (byte)'\n';
                }
                else abuf[abuf_index++] = (byte)ch;
            }
            buf = ASCII.GetString((byte[])abuf);
        }
	}
}
