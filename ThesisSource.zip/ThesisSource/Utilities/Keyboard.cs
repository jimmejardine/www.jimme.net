using System;

namespace Utilities
{
	public class Keyboard
	{
		public static bool isAlphaNumeric(int code)
		{
			if (code >= 'A' && code <= 'Z') return true;
			if (code >= '0' && code <= '9') return true;
			if (code == ' ') return true;

			return false;
		}
	}
}
