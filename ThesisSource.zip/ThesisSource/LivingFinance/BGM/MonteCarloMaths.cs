using System;
using Utilities.Mathematics.LinearAlgebra;

namespace LivingFinance.BGM
{
	public class MonteCarloMaths
	{
		public static Vector calculateDelta(Vector Ti)
		{
			int N = Ti.cols;

			// Calculate the time between maturities
			Vector delta = new Vector(N);
			for (int i = 1; i < N; ++i)
			{
				delta[i] = Ti[i] - Ti[i-1];
			}

			return delta;
		}

		public static double calcSwapWeight(int i, int j, int N, Vector P0, Vector delta)
		{
			double w_numerator = delta[j]*P0[j];

			double w_denominator = 0.0;
			for (int k = i; k < N; ++k)
			{
				w_denominator += delta[k]*P0[k];
			}

			return w_numerator / w_denominator;
		}
		
		// See Joshi's "The Concepts and Practice of Mathematical Finance" pg 285 for the formula for a swap rate
		public static void buildSwapRates(Vector SR0, Vector P0, Vector L0, Vector delta)
		{
			int N = SR0.cols;

			// Loop through each of the swap rates we will be building (swaps from T[i] till T[N])
			for (int i = 1; i < N; ++i)
			{
				double w_denominator = 0.0;
				for (int k = i; k < N; ++k)
				{
					w_denominator += delta[k]*P0[k];
				}

				// Loop through the time periods that comprise the swap
				double SR_i = 0.0;
				for (int j = i; j < N; ++j)
				{
					double w_numerator = delta[j] * P0[j];
					SR_i += w_numerator / w_denominator * L0[j];
				}

				SR0[i] = SR_i;
			}
		}

		public static void buildZeroCurveFromForwardCurve(Vector Pi, Vector Li, Vector delta)
		{
			Matrix Pi_matrix = Pi.transpose().toMatrix();
			Matrix Li_matrix = Li.transpose().toMatrix();
			buildZeroCurveFromForwardCurve(Pi_matrix, Li_matrix, delta);
			Pi_matrix.getRow(0, Pi);
		}


		/**
		 * Note: this works only on the upper-right triangle of the matrix
		 */
		public static void buildZeroCurveFromForwardCurve(Matrix Pi, Matrix Li, Vector delta)
		{
			// Build our zero curve matrix
			for (int t = 0; t < Pi.rows; ++t)
			{
				// Zero from today till today
				Pi[t, t] = 1.0;

				// Each of the zeros going forward in time from today
				for (int j = t+1; j < Pi.cols; ++j)
				{
					Pi[t, j] = Pi[t, j-1] / (1.0 + delta[j] * Li[t,j]);
				}
			}
		}

		/**
		 * Note: this works only on the upper-right triangle of the matrix
		 */
		public static void buildForwardCurveFromZeroCurve(Matrix Li, Matrix Pi, Vector delta)
		{
			// Build our forward curve matrix
			for (int t = 0; t < Li.rows; ++t)
			{
				// Zero from today till today
				Li[t, t] = 0.0;

				// Each of the zeros going forward in time from today
				for (int j = t+1; j < Li.cols; ++j)
				{
					Li[t, j] = (Pi[t, j-1] / Pi[t, j] - 1.0) / delta[j];
				}
			}
		}

		public static void TestHarness()
		{
			const int N = 5;
			Matrix Li = new Matrix(N, N);
			Matrix Pi = new Matrix(N, N);
			Matrix Pi_reconstructed = new Matrix(N, N);
			Vector delta = new Vector(N);

			// Set up the delta
			for (int i = 0; i < N; ++i)
			{
				delta[i] = 0.5;
			}

			// Set up the initial bond matrix
			for (int i = 0; i < N; ++i)
			{
				for (int j = i; j < N; ++j)
				{
					Pi[i,j] = 1.0 - 0.01*(j-i);
				}
			}

			Console.WriteLine("Initial zero matrix");
			Console.WriteLine(Pi);

			buildForwardCurveFromZeroCurve(Li, Pi, delta);
			Console.WriteLine("Initial forward matrix");
			Console.WriteLine(Li);

			buildZeroCurveFromForwardCurve(Pi_reconstructed, Li, delta);
			Console.WriteLine("Final zero matrix");
			Console.WriteLine(Pi_reconstructed);
		}
	}
}
