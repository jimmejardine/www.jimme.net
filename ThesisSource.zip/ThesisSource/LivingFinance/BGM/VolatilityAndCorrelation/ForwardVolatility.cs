using System;
using System.Collections;
using System.IO;
using Utilities.GUI.Charting;

namespace LivingFinance.BGM
{
	public class ForwardVolatility
	{
		public double T;
		public double sigma;

		public ForwardVolatility(double aT, double asigma)
		{
			T = aT;
			sigma = asigma;
		}

		public override string ToString()
		{
			return T + ":" + sigma;
		}

		public static ArrayList getForwardVolatilityDataset(string filename)
		{
			ArrayList results = new ArrayList();

			String[] lines = Utilities.Files.TextFile.loadTextFile(filename, true, true);
			foreach (string line in lines)
			{
				String[] values = Utilities.Files.CSV.splitAtCommas(line);
				
				double T = Double.Parse(values[0]);
				double sigma = Utilities.Mathematics.General.parsePercentage(values[1]);
				results.Add(new ForwardVolatility(T, sigma));
			}

			return results;
		}

		public static void TestHarness()
		{
			ArrayList vols = getForwardVolatilityDataset(@"Z:\Personal\Development\MastersThesis\Material\data\BrigoCaplet.txt");
			Console.WriteLine(Utilities.Collections.ArrayFormatter.listElements(vols));
		}
	}

}
