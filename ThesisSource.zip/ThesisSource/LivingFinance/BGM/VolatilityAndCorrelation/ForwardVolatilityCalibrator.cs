using System;
using System.Collections;
using Utilities.GUI.Charting;
using Utilities.Mathematics.Optimisation.NelderMead;
using Utilities.Mathematics.LinearAlgebra;
using Utilities.Random;

namespace LivingFinance.BGM.VolatilityAndCorrelation
{
	public class ForwardVolatilityCalibrator : ObjectiveFunction
	{
		// Used only for the neldermead search
		ArrayList vols;  // ArrayList<ForwardVolatility> vols;

		public ForwardVolatilityCalibrator(ArrayList _vols)
		{
			vols = _vols;
		}

		public ForwardVolatilityContinuousParametrisation_Rebonato calibrateContinuous()
		{
			NelderMead nm = new NelderMead(4);
			double[] scales = {1,1,1,1};
			double[][] startup = nm.generateEmptyStartupParameters(scales);

			startup[0][0] = -0.0195607243404649;
			startup[0][1] =  0.307959394732521;
			startup[0][2] =  0.959891531655911;
			startup[0][3] =  0.103684750154901;

//			startup[1][0] =  1.3; startup[1][1] = -1.2; startup[1][2] = -0.3; startup[1][3] =  0.1;
//			startup[2][0] =  0.1; startup[2][1] = +0.3; startup[2][2] =  0.5; startup[2][3] =  0.2;
//			startup[3][0] =  -1.7; startup[3][1] = +1.7; startup[3][2] =  0.7; startup[3][3] =  0.6;
//			startup[4][0] =  0.4; startup[4][1] = -0.5; startup[4][2] = -1.9; startup[4][3] =  0.3;
			nm.initialiseSearch(this, startup);
			
			string error_message;
			double score;
			double[] result = nm.search(out error_message, out score);
			Console.WriteLine("Params are: " + Utilities.Collections.ArrayFormatter.listElements(result));

			// Build the best continuous time version of our calibration
			ForwardVolatilityContinuousParametrisation_Rebonato fvp = new ForwardVolatilityContinuousParametrisation_Rebonato();
			fvp.a = result[0];
			fvp.b = result[1];
			fvp.c = result[2];
			fvp.d = result[3];

			return fvp;
		}

		public ForwardVolatilityParametrisation_Rebonato calibrateDiscrete(ForwardVolatilityContinuousParametrisation_Rebonato fvcp, Vector Ti)
		{
			// Now we need to accurately discretise it for the requested maturities
			Vector Ki = new Vector(Ti.cols);
			for (int i = 0; i < Ti.cols; ++i)
			{
				ForwardVolatility fv_earlier = null;
				ForwardVolatility fv_later = null;

				// Look for a market data maturity coinciding with our maturity
				foreach (ForwardVolatility fv in vols)
				{
					if (fv.T <= Ti[i] && (fv_earlier == null || fv_earlier.T < fv.T))
					{
						fv_earlier = fv;
					}
					if (fv.T >= Ti[i] && (fv_later == null || fv_later.T > fv.T))
					{
						fv_later = fv;
					}
				}

				// Check that we have both surrounding points (we might not if our date is earlier or later than all the sample dates)
				if (null == fv_earlier) fv_earlier = fv_later;
				if (null == fv_later) fv_later = fv_earlier;

				// Now that we have our points, we interpolate our own point
				ForwardVolatility fv_interpolated = new ForwardVolatility(Ti[i], Utilities.Mathematics.General.interpolate_linear(Ti[i],fv_earlier.T, fv_later.T, fv_earlier.sigma, fv_later.sigma));
				Ki[i] = Math.Sqrt(fv_interpolated.sigma*fv_interpolated.sigma*fv_interpolated.T / fvcp.getIntegralDefinite(0, fv_interpolated.T, fv_interpolated.T, fv_interpolated.T));
			}

			ForwardVolatilityParametrisation_Rebonato fvp = new ForwardVolatilityParametrisation_Rebonato(Ti, Ki, fvcp);
			return fvp;
		}

		
		public double evaluate(double[] p)
		{
			ForwardVolatilityContinuousParametrisation_Rebonato fvp = new ForwardVolatilityContinuousParametrisation_Rebonato();
			fvp.a = p[0];
			fvp.b = p[1];
			fvp.c = p[2];
			fvp.d = p[3];

			double total = 0.0;
			foreach (ForwardVolatility fv in vols)
			{
				total += Math.Pow(fv.sigma*fv.sigma*fv.T - fvp.getIntegralDefinite(0, fv.T, fv.T, fv.T), 2.0);
			}

			return total;
		}

		public void constrainSearch(ref double[] p)
		{
//			if (p[3] < 0.0) p[3] = 0.0;
//			if (p[1] < 0.0) p[1] = 0.0;
//			if (p[2] < 0.0) p[2] = 0.0;
		}

		public static void TestHarness()
		{
			TestHarness_Calibration();
			TestHarness_Sensitivity();
		}

		public static void TestHarness_Sensitivity()
		{
			RandomAugmented ra = new RandomAugmented();


			ArrayList vols = LivingFinance.BGM.ForwardVolatility.getForwardVolatilityDataset(@"Z:\Personal\Development\MastersThesis\Material\data\BrigoCaplet.txt");
			ForwardVolatilityCalibrator fvc = new ForwardVolatilityCalibrator(vols);
			ForwardVolatilityContinuousParametrisation_Rebonato fvcp = fvc.calibrateContinuous();

			vols = LivingFinance.BGM.ForwardVolatility.getForwardVolatilityDataset(@"Z:\Personal\Development\MastersThesis\Material\data\BrigoCaplet.txt");
			for (int i = 0; i < vols.Count; ++i)
			{
				ForwardVolatility fv = (ForwardVolatility) vols[i];
				fv.sigma += 0.01;
			}
			ForwardVolatilityCalibrator fvc_bumped = new ForwardVolatilityCalibrator(vols);
			ForwardVolatilityContinuousParametrisation_Rebonato fvcp_bumped = fvc_bumped.calibrateContinuous();

			vols = LivingFinance.BGM.ForwardVolatility.getForwardVolatilityDataset(@"Z:\Personal\Development\MastersThesis\Material\data\BrigoCaplet.txt");
			for (int i = 2; i < 5; ++i)
			{
				ForwardVolatility fv = (ForwardVolatility) vols[i];
				fv.sigma += 0.01;
			}
			ForwardVolatilityCalibrator fvc_bumped_few = new ForwardVolatilityCalibrator(vols);
			ForwardVolatilityContinuousParametrisation_Rebonato fvcp_bumped_few = fvc_bumped_few.calibrateContinuous();

			vols = LivingFinance.BGM.ForwardVolatility.getForwardVolatilityDataset(@"Z:\Personal\Development\MastersThesis\Material\data\BrigoCaplet.txt");
			for (int i = 0; i < vols.Count; ++i)
			{
				ForwardVolatility fv = (ForwardVolatility) vols[i];
				fv.sigma += fv.sigma * 0.05 * ra.NextDoubleBalanced();
			}
			ForwardVolatilityCalibrator fvc_bumped_random = new ForwardVolatilityCalibrator(vols);
			ForwardVolatilityContinuousParametrisation_Rebonato fvcp_bumped_random = fvc_bumped_random.calibrateContinuous();


			Series series_original = new Series("Original", ChartType.LineAndPoint);
			Series series_bumped = new Series("Bumped up", ChartType.LineAndPoint);
			Series series_bumped_few = new Series("Bumped up (few)", ChartType.LineAndPoint);
			Series series_bumped_random = new Series("Bumped random", ChartType.LineAndPoint);
			
			const int NUM_POINTS = 50;
			double HORIZON = 20;
			for (int j = 0; j < NUM_POINTS; ++j)
			{
				double i = (HORIZON*j)/NUM_POINTS;
				series_original.addPoint(i, Math.Sqrt(fvcp.getIntegralDefinite(0, i, i, i)/i));
				series_bumped.addPoint(i, Math.Sqrt(fvcp_bumped.getIntegralDefinite(0, i, i, i)/i));
				series_bumped_few.addPoint(i, Math.Sqrt(fvcp_bumped_few.getIntegralDefinite(0, i, i, i)/i));
				series_bumped_random.addPoint(i, Math.Sqrt(fvcp_bumped_random.getIntegralDefinite(0, i, i, i)/i));
			}

			MultiChart2D chart = new MultiChart2D();
			chart.addSeries(series_original);
			chart.addSeries(series_bumped);
			chart.addSeries(series_bumped_few);
			chart.addSeries(series_bumped_random);

			chart.title = "Sensitivity of calibration to caplet market data";
			chart.x_axis_title = "Time";
			chart.y1_axis_title = "Volatility";
//			chart.y1_axis_min = 0.1;
//			chart.y1_axis_max = 0.2;
//			chart.y2_axis_min = 0.9;
//			chart.y2_axis_max = 1.1;
			chart.x_axis_min = 0;
			chart.x_axis_max = 20;

			SingleControlForm form = new SingleControlForm();
			form.setControl(chart);
			form.ShowDialog();

			

		}

		public static void TestHarness_Calibration()
		{
			ArrayList vols = LivingFinance.BGM.ForwardVolatility.getForwardVolatilityDataset(@"Z:\Personal\Development\MastersThesis\Material\data\BrigoCaplet.txt");
			Console.WriteLine(Utilities.Collections.ArrayFormatter.listElements(vols));

			Vector Ti = new Vector(11);
			for (int i = 0; i < 10; ++i)
			{
				Ti[i] = i*2;
			}
			Ti[10] = 20;

			ForwardVolatilityCalibrator fvc = new ForwardVolatilityCalibrator(vols);
			ForwardVolatilityContinuousParametrisation_Rebonato fvcp = fvc.calibrateContinuous();
			ForwardVolatilityParametrisation_Rebonato fvp = fvc.calibrateDiscrete(fvcp, Ti);

			Series series_instantaneous = new Series("Instantaneous", ChartType.Line);
			Series series_accumulated_over_t = new Series("Model-continuous", ChartType.Line);
			Series series_marketdata = new Series("Market", ChartType.Point);

			Series series_Ki = new Series("Ki", ChartType.Point);
			series_Ki.chartaxis = ChartAxis.Secondary;
			Series series_accumulated_over_t_forced = new Series("Model-discrete", ChartType.LineAndPoint);

			const int NUM_POINTS = 50;
			double HORIZON = Ti[Ti.cols-1];
			for (int j = 0; j < NUM_POINTS; ++j)
			{
				double i = (HORIZON*j)/NUM_POINTS;

				// Note that these two work with the conitnuous parametrisation
				series_instantaneous.addPoint(i, fvcp.getInstantaneousVolatility(0, i));
				series_accumulated_over_t.addPoint(i, Math.Sqrt(fvcp.getIntegralDefinite(0, i, i, i)/i));
			}

			foreach (ForwardVolatility fv in vols)
			{
				series_marketdata.addPoint(fv.T, fv.sigma);
			}

			for (int i = 0; i < Ti.cols; ++i)
			{
				// Note that these work with the discrete volatilities
				series_Ki.addPoint(Ti[i], fvp.Ki[i]);
				series_accumulated_over_t_forced.addPoint(Ti[i], Math.Sqrt(fvp.getIntegralDefinite(0, i, i, i) / Ti[i]));
			}

			Series series_unity = new Series("Unity", ChartType.Line);
			series_unity.addPoint(0, 1.0);
			series_unity.addPoint(20, 1.0);
			series_unity.chartaxis = ChartAxis.Secondary;			

			
			if (1 == 1)
			{
				MultiChart2D chart = new MultiChart2D();
				chart.addSeries(series_accumulated_over_t);
				chart.addSeries(series_marketdata);
				chart.addSeries(series_instantaneous);

				chart.title = "Results of calibration to caplets (time-homogenous)";
				chart.x_axis_title = "Time";
				chart.y1_axis_title = "Volatility";
				chart.y1_axis_min = 0.1;
				chart.y1_axis_max = 0.2;
				chart.y2_axis_min = 0.9;
				chart.y2_axis_max = 1.1;
				chart.x_axis_min = 0;
				chart.x_axis_max = 20;

				SingleControlForm form = new SingleControlForm();
				form.setControl(chart);
				form.ShowDialog();
			}

			if (1 == 1)
			{
				MultiChart2D chart = new MultiChart2D();
				chart.addSeries(series_marketdata);
				chart.addSeries(series_accumulated_over_t_forced);
				chart.addSeries(series_Ki);
				chart.addSeries(series_unity);

				chart.title = "Results of calibration to caplets (exact)";
				chart.x_axis_title = "Time";
				chart.y1_axis_title = "Volatility";
				chart.y1_axis_min = 0.1;
				chart.y1_axis_max = 0.2;
				chart.y2_axis_min = 0.9;
				chart.y2_axis_max = 1.1;
				chart.x_axis_min = 0;
				chart.x_axis_max = 20;

				SingleControlForm form = new SingleControlForm();
				form.setControl(chart);
				form.ShowDialog();
			}
		}
	}
}
