using System;
using Utilities.Mathematics.LinearAlgebra;

namespace LivingFinance.BGM.VolatilityAndCorrelation
{
	public interface CovarianceMatrixSource
	{
		void build(int current_time_index, out Matrix covariance, out Matrix correlations_root);
		void build(int start_time_index, int end_time_index, out Matrix covariance, out Matrix correlations_root);
	}
}
