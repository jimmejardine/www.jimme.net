using System;
using Utilities.Mathematics.LinearAlgebra;

namespace LivingFinance.BGM.VolatilityAndCorrelation
{
	public class CovarianceMatrixBuilder : CovarianceMatrixSource
	{
		Vector Ti;
		ForwardVolatilityParametrisation forward_volatility_parametrisation;
		ForwardCorrelationParametrisation forward_correlation_parametrisation;

		public CovarianceMatrixBuilder(Vector _Ti, ForwardVolatilityParametrisation _forward_volatility_parametrisation, ForwardCorrelationParametrisation _forward_correlation_parametrisation)
		{
			Ti = _Ti;
			forward_volatility_parametrisation = _forward_volatility_parametrisation;
			forward_correlation_parametrisation = _forward_correlation_parametrisation;
		}

		/**
		 * Builds the covariance matrix for the given forwards using the specified volatility and correlation parametrisations.
		 * The times in forward_maturities must be in increasing order, starting at 0.
		 * All vols and correlations with index <= end_time_index are set to zero.
		 * This is a one-time-step version of the more general method
		 */
		public void build(int end_time_index, out Matrix covariance, out Matrix correlations_root)
		{
			build(end_time_index-1, end_time_index, out covariance, out correlations_root);
		}
		
		/**
		 * Builds the covariance matrix for the given forwards using the specified volatility and correlation parametrisations.
		 * The times in forward_maturities must be in increasing order, starting at 0.
		 * All vols and correlations with index <= current_time_index are set to zero.
		 */
		public void build(int start_time_index, int end_time_index, out Matrix covariance, out Matrix correlations_root)
		{
			int N = Ti.cols;
			
			covariance = new Matrix(N, N);
			correlations_root = new Matrix(N, N);
			
			Matrix correlations = forward_correlation_parametrisation.getCorrelationMatrix(Ti);
			correlations_root = Utilities.Mathematics.LinearAlgebra.Cholesky.factorise(correlations);

			for (int i = start_time_index+1; i < N; ++i)
			{
				for (int j = start_time_index+1; j < N; ++j)
				{
					double raw_rho = correlations[i, j];
					double integral_sigma_i_sigma_j = forward_volatility_parametrisation.getIntegralDefinite(start_time_index, end_time_index, i, j);
					covariance[i,j] = raw_rho * integral_sigma_i_sigma_j;
				}
			}
		}

		public static void TestHarness()
		{
			Vector forward_maturities = LivingFinance.BGM.MarketData.SampleData.getMaturities(5);

			int NUM_MATURITIES = 5;
			int NUM_FACTORS = 5;
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getMaturities(NUM_MATURITIES);
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(forward_maturities);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, NUM_FACTORS);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);

			for (int i = 1; i < NUM_MATURITIES; ++i)
			{
				Console.WriteLine("Step is {0} with maturity {1}", i, forward_maturities[i]);
				Matrix covariances;
				Matrix correlations_root;

				covariance_matrix_builder.build(i, out covariances, out correlations_root);
				
				Console.WriteLine("Covariances");
				Console.WriteLine(covariances.ToString());
				Console.WriteLine("Correlations root");
				Console.WriteLine(correlations_root.ToString());

				Console.WriteLine();
			}
		}
	}
}
