using System;
using Utilities.GUI.Charting;
using Utilities.Mathematics.LinearAlgebra;
using Utilities;

namespace LivingFinance.BGM.VolatilityAndCorrelation
{
	public class SwaptionVolatilityCalibrator : CovarianceMatrixSource
	{
		CovarianceMatrixSource covariance_matrix_source;

		Matrix Z_stored;
		Matrix lambda_stored;

		public SwaptionVolatilityCalibrator(Vector Ti, Vector L0, Vector swaption_volatilities_market, CovarianceMatrixSource _covariance_matrix_source)
		{
			covariance_matrix_source = _covariance_matrix_source;

			int N = Ti.cols;

			// Calculate some useful constants from the supplied parameters
			Vector delta = MonteCarloMaths.calculateDelta(Ti);
			Vector P0 = new Vector(N);
			LivingFinance.BGM.MonteCarloMaths.buildZeroCurveFromForwardCurve(P0, L0, delta);
			Vector SR0 = new Vector(N);
			LivingFinance.BGM.MonteCarloMaths.buildSwapRates(SR0, P0, L0, delta);

			// Now we move on to build the Z matrix - the matrix rotating the caplet covariance to the swaption covariance coordinates
			Matrix Z = new Matrix(N, N);
			for (int i = 1; i < N; ++i)
			{
				for (int j = i; j < N; ++j)
				{
					Z[i,j] = L0[j] * MonteCarloMaths.calcSwapWeight(i, j, N, P0, delta) / SR0[i];
				}
			}
			Z[0,0] = 1.0;

			Matrix Z_inv = Z.inverse();

			Vector swaption_volatilities_model = new Vector(N);
			Matrix lambda = new Matrix(N, N);
			for (int i = 1; i < N; ++i)
			{
				Matrix forward_covariances;
				Matrix forward_correlations_root;
				covariance_matrix_source.build(i-1, i, out forward_covariances, out forward_correlations_root);

				Matrix Z_copy = Z.clone();
				for (int j = 1; j < i; ++j)
				{
					Z_copy.zeroRow(j);
					Z_copy.zeroColumn(j);
					Z_copy[j,j] = 1.0;
				}

				// Calculate the swap covariance
				Matrix swap_covariances = Z_copy.multiply(forward_covariances).multiply(Z_copy.transpose());
				swaption_volatilities_model[i] = Math.Sqrt(swap_covariances[i,i] / delta[i]);
				lambda[i,i] = swaption_volatilities_market[i] / swaption_volatilities_model[i];

//				Console.WriteLine("{0} - {1}", swaption_volatilities_model[i], swaption_volatilities_market[i]);
				Console.WriteLine("{0}", swaption_volatilities_model[i]);
//				Console.WriteLine("Z_copy is");
//				Console.WriteLine(Z_copy);
//				Console.WriteLine("Forward covariance is");
//				Console.WriteLine(forward_covariances);
//				Console.WriteLine("Swap covariances are");
//				Console.WriteLine(swap_covariances);

			}

			Z_stored = Z;
			lambda_stored = lambda;
		}

		public void build(int end_time_index, out Matrix covariance, out Matrix correlations_root)
		{
			build(end_time_index-1, end_time_index, out covariance, out correlations_root);
		}

		public void build(int start_time_index, int end_time_index, out Matrix covariance, out Matrix correlations_root)
		{
			// We need to reduce the size of the stored calibration variables to fit our current time
			Matrix Z = Z_stored.clone();
			Matrix lambda = lambda_stored.clone();

			// Clear down any lambda and Z that applies before the start time
			for (int k = 0; k < end_time_index; ++k)
			{
				lambda[k,k] = 0.0;
				for (int i = 0; i < Z.rows; ++i)
				{
					Z[i,k] = Z[k,i] = 0.0;
				}
				Z[k,k] = 1.0;
			}
			
			Matrix Z_inv = Z.inverse();


			// Calibrate what the underlying forward covariance builder gives to the swaptions adjustments
			Matrix forward_covariances_original;
			Matrix forward_correlations_root_original;
			covariance_matrix_source.build(start_time_index, end_time_index, out forward_covariances_original, out forward_correlations_root_original);
			Matrix forward_covariances_calibrated = Z_inv.multiply(lambda.multiply(Z.multiply(forward_covariances_original.multiply(Z.transpose().multiply(lambda.multiply(Z_inv.transpose()))))));

			// Because of rounding errors we have to massage the matrix back into a correlation matrix...
			Utilities.Mathematics.Precision.massageIntoCorrelation(forward_covariances_calibrated);

			covariance = forward_covariances_calibrated;
			correlations_root = forward_correlations_root_original;
		}

		public static void TestHarness()
		{
			const int N = 10;

			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, N);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);
			Vector swaption_volatilities_market = LivingFinance.BGM.MarketData.SampleData.getSwaptionVols(N);
			Vector swaption_volatilities_market_implied = getSwaptionVolsImpliedByModel(N);

			SwaptionVolatilityCalibrator SVC = new SwaptionVolatilityCalibrator(Ti, L0, swaption_volatilities_market, covariance_matrix_builder);
			
			// Print out only the first calibrated covariance matrix
			for (int i = 1; i < 2; ++i)
			{
				Matrix forward_covariances;
				Matrix forward_correlations_root;
				covariance_matrix_builder.build(i, out forward_covariances, out forward_correlations_root);
				Console.WriteLine("Forward covariance");
				Console.WriteLine(forward_covariances.convertCovarianceToCorrelation());
			
				Matrix forward_covariances_calibrated;
				Matrix forward_correlations_root_calibrated;
				SVC.build(i, out forward_covariances_calibrated, out forward_correlations_root_calibrated);
				Console.WriteLine("Forward covariance - calibrated");
				Console.WriteLine(forward_covariances_calibrated.convertCovarianceToCorrelation());

				// Print out the variances - before and after
				Series series_before = new Series("Forward pre-calibration", ChartType.LineAndPoint);
				Series series_after = new Series("Forward post-calibration", ChartType.LineAndPoint);
				Series series_swaption = new Series("Swaption market", ChartType.LineAndPoint);
				Series series_swaption_implied = new Series("Swaption caplet-implied", ChartType.LineAndPoint);
				
				Console.WriteLine("Before\tAfter");
				for (int j = i; j < N; ++j)
				{
					series_before.addPoint(j, Math.Sqrt(forward_covariances[j,j]));
					series_after.addPoint(j, Math.Sqrt(forward_covariances_calibrated[j,j]));

					series_swaption.addPoint(j, swaption_volatilities_market[j]);
					series_swaption_implied.addPoint(j, swaption_volatilities_market_implied[j]);

					Console.WriteLine("{0}\t{1}", Math.Sqrt(forward_covariances[j,j]), Math.Sqrt(forward_covariances_calibrated[j,j]));
				}

				MultiChart2D chart = new MultiChart2D();
				chart.addSeries(series_swaption_implied);
				chart.addSeries(series_swaption);
				chart.addSeries(series_before);
				chart.addSeries(series_after);

				chart.title = "Volatility of the forward rates before and after calibration to swaption market data";
				chart.x_axis_title = "Expiry";
				chart.y1_axis_title = "Volatility";
//				chart.y1_axis_min = 0.1;
//				chart.y1_axis_max = 0.2;
//				chart.y2_axis_min = 0.9;
//				chart.y2_axis_max = 1.1;
				chart.x_axis_min = 0;
				chart.x_axis_max = 10;

				SingleControlForm form = new SingleControlForm();
				form.setControl(chart);
				form.ShowDialog();


			}
		}
		
		public static Vector getSwaptionVolsImpliedByModel(int N)
		{
			double[] market10 =
				{
					0,
					0.0966652771749042,
					0.0979566280078924,
					0.103808664671656,
					0.144417205805202,
					0.158609522204018,
					0.16763394621723,
					0.178024711452413,
					0.186018695912811,
					0.178386150258098
				};
	
			Vector swaption_volatilities_market = new Vector(N);
			for (int i = 0; i < N; ++i)
			{
				swaption_volatilities_market[i] = market10[Math.Min(9,i)];
			}

			return swaption_volatilities_market;
		}

		public static void TestHarness_creating()
		{
			const int N = 5;


			// Define the maturities and initial forward curve
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, 5);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);

			Vector swaption_volatilities_market = LivingFinance.BGM.MarketData.SampleData.getSwaptionVols(N);			

			// Some useful calculated constants			
			Vector delta = MonteCarloMaths.calculateDelta(Ti);
			Vector P0 = new Vector(N);
			LivingFinance.BGM.MonteCarloMaths.buildZeroCurveFromForwardCurve(P0, L0, delta);
			Vector SR0 = new Vector(N);
			LivingFinance.BGM.MonteCarloMaths.buildSwapRates(SR0, P0, L0, delta);

			Console.WriteLine("Forward rates");
			Console.WriteLine(L0.ToString());
			Console.WriteLine("Zero rates");
			Console.WriteLine(P0.ToString());
			Console.WriteLine("Swap rates");
			Console.WriteLine(SR0.ToString());

			// Now we move on to build the Z matrix - the matrix rotating the caplet covariance to the swaption covariance coordinates
			Matrix Z = new Matrix(N-1, N-1);
			for (int i = 1; i < N; ++i)
			{
				for (int j = i; j < N; ++j)
				{
					Z[i-1,j-1] = L0[j] * MonteCarloMaths.calcSwapWeight(i, j, N, P0, delta) / SR0[i];
				}
			}

			Console.WriteLine("Rotation Z");
			Console.WriteLine(Z.ToString());

			Matrix Z_inv = Z.inverse();
			Console.WriteLine("Z inverse");
			Console.WriteLine(Z_inv.ToString());

			Vector swaption_volatilities_model = new Vector(N);
			Matrix lambda = new Matrix(N-1, N-1);
			for (int i = 1; i < N; ++i)
			{
				Matrix forward_covariances;
				Matrix forward_correlations_root;
				covariance_matrix_builder.build(0, i, out forward_covariances, out forward_correlations_root);

				Console.WriteLine("Forward covariance");
				Console.WriteLine(forward_covariances.ToString());

				// Calculate the swap covariance
				Matrix swap_covariances = Z.multiply(forward_covariances).multiply(Z.transpose());
				swaption_volatilities_model[i] = Math.Sqrt(swap_covariances[i-1,i-1] / Ti[i]);
				lambda[i-1,i-1] = swaption_volatilities_market[i] / swaption_volatilities_model[i];
			}

			Console.WriteLine("Swap vols - market");
			Console.WriteLine(swaption_volatilities_market);
			Console.WriteLine("Swap vols - model");
			Console.WriteLine(swaption_volatilities_model);
			
			Console.WriteLine("Lambda");
			Console.WriteLine(lambda);

			// --- and from here on is where we can use the calibration to generate covariance matrices

			// And so we are able to recalculate the caplet volatilities
			for (int i = 0; i < N; ++i)
			{
				Matrix forward_covariances_original;
				Matrix forward_correlations_root_original;
				covariance_matrix_builder.build(i, out forward_covariances_original, out forward_correlations_root_original);
				Matrix forward_covariances_calibrated = Z_inv.multiply(lambda.multiply(Z.multiply(forward_covariances_original.multiply(Z.transpose().multiply(lambda.multiply(Z_inv.transpose()))))));

				Console.WriteLine("Forward covariance - original");
				Console.WriteLine(forward_covariances_original);
				Console.WriteLine("Forward covariance - calibrated");
				Console.WriteLine(forward_covariances_calibrated);

				// Shrinks down the factors so they are the same size as our current correlation matrix (but only if there is something left: ie not on our last iteration)
				if (i < N-1)
				{
					Z = Z.removeRowAndColumn(0, 0);
					Z_inv = Z.inverse();
					lambda = lambda.removeRowAndColumn(0, 0);
				}
			}
		}
	}
}
