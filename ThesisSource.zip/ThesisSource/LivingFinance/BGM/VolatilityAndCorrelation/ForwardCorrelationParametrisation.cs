using System;
using Utilities.Mathematics.LinearAlgebra;

namespace LivingFinance.BGM
{
	public class ForwardCorrelationParametrisation
	{
		double beta;
		double long_correlation;
		int num_factors;
		

		public ForwardCorrelationParametrisation(double abeta, double along_correlation, int anum_factors)
		{
			beta = abeta;
			long_correlation = along_correlation;
			num_factors = anum_factors;
		}

		double getCorrelation(double Ti, double Tj)
		{
			return long_correlation + (1.0 - long_correlation) * Math.Exp(-beta*Math.Abs(Ti-Tj));
		}

		public Matrix getCorrelationMatrix(Vector Ti)
		{
			return getReducedFactorCorrelationMatrix(Ti);
		}

		public Matrix getRawCorrelationMatrix(Vector Ti)
		{
			int N = Ti.cols;
			Matrix correlations = new Matrix(N,N);
			for (int i = 0; i < N; ++i)
			{
				for (int j = 0; j < N; ++j)
				{
					correlations[i,j] = getCorrelation(Ti[i], Ti[j]);
				}
			}

			return correlations;
		}

		public Matrix getReducedFactorCorrelationMatrix(Vector Ti)
		{
			int N = Ti.cols;

			Matrix correlations = getRawCorrelationMatrix(Ti);
			correlations = Utilities.Mathematics.LinearAlgebra.Eigensystems.ReducedFactorMatrix.reduceFactors(correlations, num_factors, true);
			return correlations;
		}

		public static void TestHarness()
		{
			int N = 5;
			Vector Ti = new Vector(N);
			Ti[0] = 0.0;
			Ti[1] = 1.0;
			Ti[2] = 2.0;
			if (3 < N) Ti[3] = 5.0;
			if (4 < N) Ti[4] = 10.0;
			for (int i = 5; i < N; ++i)
			{
				Ti[i] = Ti[i-1] + 1;
			}
			
			ForwardCorrelationParametrisation fcp = new ForwardCorrelationParametrisation(0.1, 0.1, 2);
			Matrix correlations_raw = fcp.getRawCorrelationMatrix(Ti);
			Matrix correlations_reduced = fcp.getReducedFactorCorrelationMatrix(Ti);

			System.Console.WriteLine("Correlations - raw");
			System.Console.WriteLine(correlations_raw);
			System.Console.WriteLine("Correlations - 2 factor");
			System.Console.WriteLine(correlations_reduced);

			// Lets square root the final one and see what we get
			Matrix correlations_root_reduced = Cholesky.factorise(correlations_reduced);
			System.Console.WriteLine("Correlations - 2 factor root");
			System.Console.WriteLine(correlations_root_reduced);

		}
	}
}
