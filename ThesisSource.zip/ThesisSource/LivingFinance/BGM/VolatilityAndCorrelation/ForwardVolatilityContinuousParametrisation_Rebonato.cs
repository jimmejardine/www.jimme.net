using System;
using Utilities.GUI.Charting;

namespace LivingFinance.BGM.VolatilityAndCorrelation
{
	public class ForwardVolatilityContinuousParametrisation_Rebonato
	{
		public double a, b, c, d;

		public ForwardVolatilityContinuousParametrisation_Rebonato()
		{
		}

		public double getInstantaneousVolatility(double t, double T)
		{
			double tau = T - t;
			return ((a + b*tau) * Math.Exp(-c*tau) + d);
		}


		public double getIntegralIndefinite(double t, double T)
		{
			double ctmT=c*(t-T);
			double expctmT=(exp(ctmT));
			double q=2*ctmT;
			double ac=a*c;
			double cd=c*d;
			double f=1.0/(c*c*c);
			double A=ac*cd*(2*expctmT)+c*cd*cd*t;
			double B=b*cd*(2*expctmT*(ctmT-1));
			double C=exp(q)*(ac*(ac+b*(1-q))+b*b*(0.5*(1-q)+ctmT*ctmT))/2;
			return f*(A-B+C);
		}
		
		public double getIntegralIndefinite(double t, double Ti, double Tj)
		{
			double ctmTi=c*(t-Ti);
			double ctmTj=c*(t-Tj);
			double q=ctmTi+ctmTj;
			double ac=a*c;
			double cd=c*d;
			double f=1.0/(c*c*c);
			double A=ac*cd*(exp(ctmTj)+exp(ctmTi))+c*cd*cd*t;
			double B=b*cd*(exp(ctmTi)*(ctmTi-1)+exp(ctmTj)*(ctmTj-1));
			double C=exp(q)*(ac*(ac+b*(1-q))+b*b*(0.5*(1-q)+ctmTi*ctmTj))/2;
			return f*(A-B+C);
		}

		public double getIntegralDefinite(double s, double t, double Ti, double Tj)
		{
			return getIntegralIndefinite(t, Ti, Tj) - getIntegralIndefinite(s, Ti, Tj);
		}

		// Used as a shortcut to make concise formulae above
		double exp(double x)
		{
			return Math.Exp(x);
		}

		public static ForwardVolatilityContinuousParametrisation_Rebonato getSample()
		{
			ForwardVolatilityContinuousParametrisation_Rebonato fvp = new ForwardVolatilityContinuousParametrisation_Rebonato();
			fvp.a = -0.0195607243404649;
			fvp.b = 0.307959394732521;
			fvp.c = 0.959891531655911;
			fvp.d = 0.103684750154901;
			return fvp;
		}

		public static void TestHarness()
		{
			ForwardVolatilityContinuousParametrisation_Rebonato fv = ForwardVolatilityContinuousParametrisation_Rebonato.getSample();
			
			Series series_instantaneous = new Series("Instantaneous", ChartType.LineAndPoint);
			Series series_accumulated = new Series("Accumulated", ChartType.LineAndPoint);
			Series series_accumulated_over_t = new Series("Sqrt(Accumulated/T)", ChartType.LineAndPoint);
			const int N = 100;
			for (int j = 0; j < N; ++j)
			{
				double i = (10.0*j)/N;

				series_instantaneous.addPoint(i, fv.getInstantaneousVolatility(0, i));
				series_accumulated.addPoint(i, fv.getIntegralDefinite(0, i, i, i));
				series_accumulated_over_t.addPoint(i, Math.Sqrt(fv.getIntegralDefinite(0, i, i, i)/i));
			}
			if (1==1)
			{
				MultiChart2D chart = new MultiChart2D();
				chart.addSeries(series_instantaneous);
				chart.addSeries(series_accumulated);
				chart.addSeries(series_accumulated_over_t);
				SingleControlForm form = new SingleControlForm();
				form.setControl(chart);
				form.ShowDialog();
			}

			if (1==1)
			{
				MultiChart2D chart = new MultiChart2D();
				chart.title = "Example parametrisation of instantaneous volatility";
				chart.x_axis_title = "Time";
				chart.y1_axis_title = "Instantaneous volatility";
				chart.x_axis_max = 10;
				chart.y1_axis_max = 0.25;
				chart.y1_axis_min = 0;
				chart.addSeries(series_instantaneous);
				SingleControlForm form = new SingleControlForm();
				form.setControl(chart);
				form.ShowDialog();
			}
		}
	}
}

