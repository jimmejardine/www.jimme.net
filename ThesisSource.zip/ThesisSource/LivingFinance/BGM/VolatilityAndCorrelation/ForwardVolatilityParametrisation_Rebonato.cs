using System;
using System.Collections;
using Utilities.Mathematics.LinearAlgebra;


namespace LivingFinance.BGM.VolatilityAndCorrelation
{
	public class ForwardVolatilityParametrisation_Rebonato : ForwardVolatilityParametrisation
	{
		public Vector Ki;
		public ForwardVolatilityContinuousParametrisation_Rebonato continuous_parametrisation;

		public ForwardVolatilityParametrisation_Rebonato(Vector _Ti, Vector _Ki, ForwardVolatilityContinuousParametrisation_Rebonato _continuous_parametrisation) : base(_Ti)
		{
			Ki = _Ki;
			continuous_parametrisation = _continuous_parametrisation;
		}

		public static ForwardVolatilityParametrisation_Rebonato getSample(Vector Ti)
		{
			Vector Ki = new Vector(Ti.cols);
			for (int i = 0; i < Ti.cols; ++i)
			{
				Ki[i] = 1.0;
			}
			ForwardVolatilityContinuousParametrisation_Rebonato continuous_parametrisation = ForwardVolatilityContinuousParametrisation_Rebonato.getSample();

			return new ForwardVolatilityParametrisation_Rebonato(Ti, Ki, continuous_parametrisation);
		}

		public override double getInstantaneousVolatility(int t, int T)
		{
			return Ki[T] * continuous_parametrisation.getInstantaneousVolatility(Ti[t], Ti[T]);
		}


		public override double getIntegralIndefinite(int t, int T)
		{
			return Ki[T] * continuous_parametrisation.getIntegralIndefinite(Ti[t], Ti[T]);
		}
		
		public override double getIntegralIndefinite(int t, int T1, int T2)
		{
			return Ki[T1] * Ki[T2] * continuous_parametrisation.getIntegralIndefinite(Ti[t], Ti[T1], Ti[T2]);
		}

		public override double getIntegralDefinite(int s, int t, int T1, int T2)
		{
			return getIntegralIndefinite(t, T1, T2) - getIntegralIndefinite(s, T1, T2);
		}
	}
}

