using System;
using Utilities.Mathematics.LinearAlgebra;

namespace LivingFinance.BGM.VolatilityAndCorrelation
{
	public abstract class ForwardVolatilityParametrisation
	{
		protected Vector Ti;

		public ForwardVolatilityParametrisation(Vector _Ti)
		{
			Ti = _Ti;
		}

		/** The volatility surface \f$\sigma(t,T)\f$. 
		 */
		public abstract double getInstantaneousVolatility(int t, int T);

		/** The indefinite integral 
		 *  \f[\int\sigma(t,T)^2ds.\f]
		 *  Needed for covariation integrals.
		 */
		public abstract double getIntegralIndefinite(int t, int T);
		
		/** The indefinite integral 
		 *  \f[\int\sigma(t,T_1)\sigma(t,T_2)ds.\f]
		 *  Needed for covariation integrals.
		 */
		public abstract double getIntegralIndefinite(int t, int T1, int T2);

		/** The definite integral 
		 * \f[\int_s^t\sigma(u,T_1)\sigma(u,T_2)du.\f]
		 *  Needed for covariation integrals.
		 */
		public abstract double getIntegralDefinite(int s, int t, int T1, int T2);
	}
}
