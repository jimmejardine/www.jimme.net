using System;
using System.Threading;
using Utilities.Mathematics.LinearAlgebra;
using LivingFinance.Options.Equity.Portfolios;
using Utilities.Random;
using Utilities.GUI.Charting;
using LivingFinance.BGM.VolatilityAndCorrelation;
using LivingFinance.BGM.Engine;

namespace LivingFinance.BGM
{
	public class MonteCarloEngine
	{
		public static PricingResults price(bool verbose, bool calculate_greeks, int N, int NUM_FACTORS, int NUM_REPS, int OUTPUT_PERIOD, Vector Ti, Vector L0, CovarianceMatrixSource covariance_matrix_source, IUniformRandomSource random, Products.IProduct product)
		{
			PricingResults results = new PricingResults();

			// Calculate the time between maturities
			Vector delta = MonteCarloMaths.calculateDelta(Ti);

			Matrix[] covariances = new Matrix[N];
			Matrix[] correlations_root = new Matrix[N];
			for (int i = 1; i < N; ++i)
			{
				covariance_matrix_source.build(i, out covariances[i], out correlations_root[i]);
			}

			// Space for our forward curve evolution.
			SimulationInstance si_atm = new SimulationInstance(N);
			si_atm.populateL0(L0);
			si_atm.buildPi(delta);

			// Change this for various delta bumps in the underlying
			double GREEK_DELTA_RATIO = GreeksBump.POINT_ONE_PERCENT;;

			SimulationInstance[] si_bumped_up = new SimulationInstance[N];
			SimulationInstance[] si_bumped_down = new SimulationInstance[N];
			for (int i = 0; i < N; ++i)
			{
				si_bumped_up[i] = new SimulationInstance(N);
				si_bumped_up[i].populateL0(L0);
				si_bumped_up[i].bumpL0(i, GREEK_DELTA_RATIO);
				si_bumped_up[i].buildPi(delta);

				si_bumped_down[i] = new SimulationInstance(N);
				si_bumped_down[i].populateL0(L0);
				si_bumped_down[i].bumpL0(i, -GREEK_DELTA_RATIO);
				si_bumped_down[i].buildPi(delta);
			}

			// We use the structure si_allinone to group all the simulation instances together in one object so we can use it easily perform the same operations on all instances
			// We can still refer to si_atm, si_bumped_up and si_bumped_down individually.
			SimulationInstance[] si_allinone = new SimulationInstance[1+2*N];
			si_allinone[0] = si_atm;
			for (int i = 0; i < N; ++i)
			{
				si_allinone[2*i + 1] = si_bumped_up[i];
				si_allinone[2*i + 2] = si_bumped_down[i];
			}

			// Evolve our forward curve
			Vector cashflows = new Vector(N);
			Vector random_numbers = new Vector(N*NUM_FACTORS);
			Vector Z = new Vector(NUM_FACTORS);
						
			Utilities.DateTimeTools.StopWatch stopwatch = new Utilities.DateTimeTools.StopWatch();

			Series series_price = new Series("Price", ChartType.LineAndPoint);
			Series series_error = new Series("Error", ChartType.LineAndPoint);

			for (int rep = 1; rep <= NUM_REPS; ++rep)
			{
				// Draw our random numbers
				random.nextRandomVector(random_numbers);
				Utilities.Mathematics.Statistics.Distributions.Distributions.InvDist_SN(random_numbers);

				// Process each of our simulation instances, one for the actual price, and then one for each of the greek bumps in two directions
				for (int i = 0; i < 2*N+1; ++i)
				{
					if (i > 0 && !calculate_greeks)
					{
						break;
					}

					SimulationInstance si = si_allinone[i];

					// Build the simulation path
					buildSimulationInstance(N, NUM_FACTORS, delta, Z, random_numbers, covariances, correlations_root, si);
					si.buildPi(delta);

					// Print out the forward rates and their equivalent discount bonds
//					System.Console.WriteLine("Li is");
//					System.Console.WriteLine(si.Li);
//					System.Console.WriteLine("Pi is");
//					System.Console.WriteLine(si.Pi);

					// Get the product to tell us its cashflows
					product.priceAgainstCurve(si.Li, si.Pi, delta, cashflows);

					// Calculate the properly discounted cashflows
					double cashflow_at_numeraire = calculateCashflowsAtNumeraireAndClearCashflows(N, si, cashflows);

					si.pricing_total += cashflow_at_numeraire;
					si.pricing_total_squared += cashflow_at_numeraire*cashflow_at_numeraire;
				}


				if (rep % OUTPUT_PERIOD == 0)
				{
					double pricing_average = si_atm.pricing_total / rep;
					double pricing_variance = Math.Sqrt( (si_atm.pricing_total_squared/rep) - Math.Pow(si_atm.pricing_total/rep, 2.0) );
					double pricing_standard_error = pricing_variance / Math.Sqrt(rep);
					double pricing_average_discounted = pricing_average * si_atm.Pi[0,N-1];

					if (verbose)
					{
						Console.WriteLine("{3}: The discounted average value is {0} with variance {1} and error {2}", pricing_average_discounted, pricing_variance, pricing_standard_error, rep);
					}

					series_price.addPoint(rep, pricing_average);
					series_error.addPoint(rep, pricing_standard_error);
				}
			}

			// Calculate the price
			for (int i = 0; i < 2*N+1; ++i)
			{
				if (i > 0 && !calculate_greeks)
				{
					break;
				}

				SimulationInstance si = si_allinone[i];
				si.final_discounted_price = si.pricing_total / NUM_REPS * si.Pi[0,N-1];
			}

			// Calculate the standard error
			double final_variance = Math.Sqrt( (si_atm.pricing_total_squared/NUM_REPS) - Math.Pow(si_atm.pricing_total/NUM_REPS, 2.0) );
			double final_standard_error = final_variance / Math.Sqrt(NUM_REPS);

			// Calculate the greeks
			Vector greeks_delta = new Vector(N);
			Vector greeks_gamma = new Vector(N);
			if (calculate_greeks)
			{
				for (int i = 0; i < N; ++i)
				{
					greeks_delta[i] = (si_bumped_up[i].final_discounted_price - si_bumped_down[i].final_discounted_price) / (si_bumped_up[i].Li[0,i] - si_bumped_down[i].Li[0,i]);
					greeks_gamma[i] = (si_bumped_up[i].final_discounted_price - 2*si_atm.final_discounted_price + si_bumped_down[i].final_discounted_price) / ( (si_bumped_up[i].Li[0,i] - si_atm.Li[0,i])*(si_atm.Li[0,i]-si_bumped_down[i].Li[0,i]) );
				}
			}

			// Store our results
			results.price = si_atm.final_discounted_price;
			results.standard_error = final_standard_error;
			results.series_price = series_price;
			results.series_error = series_error;
			results.greeks_delta = greeks_delta;
			results.greeks_gamma = greeks_gamma;
			results.time_taken = stopwatch.elapsedSeconds();

			return results;
		}

		static double calculateCashflowsAtNumeraireAndClearCashflows(int N, SimulationInstance si, Vector cashflows)
		{
			double cashflow_at_numeraire = 0.0;
			for (int i = 0; i < N; ++i)
			{
				if (0.0 != cashflows[i])
				{
					cashflow_at_numeraire += cashflows[i] / si.Pi[i,N-1];
					cashflows[i] = 0.0;
				}
			}

			return cashflow_at_numeraire;
		}

		static void buildSimulationInstance(int N, int NUM_FACTORS, Vector delta, Vector Z, Vector random_numbers, Matrix[] covariances, Matrix[] correlations_root, SimulationInstance si)
		{
			// Build our forwards matrix, starting at t=1
			for (int t = 1; t < N; ++t)
			{
				// Fill in a meaningful Z vector
				for (int k = 0; k < NUM_FACTORS; ++k)
				{
					Z[k] = random_numbers[t*NUM_FACTORS + k];
				}

				// First calculate the forward rates using the previous time-step's rate as the approximate forward rate
				for (int j = t+1; j < N; ++j)
				{
					// Calculate the movement caused by volatility by calculating a correlated dW and then multiplying in the variance
					double movement_vol = 0.0;
					for (int k = 0; k < NUM_FACTORS; ++k) movement_vol += Z[k] * correlations_root[t][j,k];
					movement_vol *= Math.Sqrt(covariances[t][j,j]);

					// Calculate the movement caused by time - note that the correlation and dt terms is already contained in covariances
					double movement_drift = -0.5 * covariances[t][j,j];
					for (int k = j+1; k < N; ++k) movement_drift -= (1.0 - 1.0 / (1.0 + delta[k]*si.Li[t-1,k])) * covariances[t][j,k];

					// Calculate the next Xj
					si.Xi[t, j] = si.Xi[t-1, j] + movement_drift + movement_vol;
					si.Li[t, j] = Math.Exp(si.Xi[t, j]);
				}

				// Then perform a predictor corrector calculation for the forward rate
				for (int j = t+1; j < N; ++j)
				{
					// Calculate the movement caused by volatility by calculating a correlated dW and then multiplying in the variance
					double movement_vol = 0.0;
					for (int k = 0; k < NUM_FACTORS; ++k) movement_vol += Z[k] * correlations_root[t][j,k];
					movement_vol *= Math.Sqrt(covariances[t][j,j]);

					// Calculate the movement caused by time - note that the correlation and dt terms is already contained in covariances
					double movement_drift = -0.5 * covariances[t][j,j];
					for (int k = j+1; k < N; ++k) movement_drift -= (1.0 - 1.0 / (1.0 + delta[k]*(si.Li[t-1,k]+si.Li[t,k])/2.0)) * covariances[t][j,k];

					// Calculate the next Xj
					si.Xi[t, j] = si.Xi[t-1, j] + movement_drift + movement_vol;
					si.Li[t, j] = Math.Exp(si.Xi[t, j]);
				}
			}
		}
		
		public static void TestHarness()
		{
			const int NUM_REPS = 1024*32*4;
			const int OUTPUT_PERIOD = NUM_REPS / 256;
		
			bool VERBOSE = false;
			const int N = 10;
			const int NUM_FACTORS = 2;

			const double STRIKE = 0.005;


			// Define the maturities and initial forward curve
			Vector Ti = LivingFinance.BGM.MarketData.SampleData.getMaturities(N);
			Vector L0 = LivingFinance.BGM.MarketData.SampleData.getL0(N);

			// Define our volatility and correlation parametrisations
			ForwardVolatilityParametrisation forward_volatility_parametrisation = ForwardVolatilityParametrisation_Rebonato.getSample(Ti);
			ForwardCorrelationParametrisation forward_correlation_parametrisation = new ForwardCorrelationParametrisation(0.1, 0.1, NUM_FACTORS);
			CovarianceMatrixBuilder covariance_matrix_builder = new CovarianceMatrixBuilder(Ti, forward_volatility_parametrisation, forward_correlation_parametrisation);
			CovarianceMatrixSource covariance_matrix_source = covariance_matrix_builder;

			MersenneTwister mersenne_twister = new MersenneTwister(1);
			RandomAugmented random_augmented = RandomAugmented.getSeededRandomAugmented();
			Sobol random_sobol = new Sobol(N*NUM_FACTORS);

			//IUniformRandomSource random = random_augmented;
			//IUniformRandomSource random = mersenne_twister;
			//IUniformRandomSource random = new AntitheticRandomSource(mersenne_twister);
			IUniformRandomSource random = random_sobol;
			
			// A caplet - antithetic
			//Products.IProduct product_caplet = new LivingFinance.BGM.Products.Caplet(N-1, STRIKE);
			//PricingResults pricing_results = price(VERBOSE, true, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_caplet);
			//Console.WriteLine("Priced a {0}", product_caplet.ToString());

			// A swaption
			Products.IProduct product_swaption = new LivingFinance.BGM.Products.Swaption(2, STRIKE);
			PricingResults pricing_results = price(VERBOSE, false, N, NUM_FACTORS, NUM_REPS, OUTPUT_PERIOD, Ti, L0, covariance_matrix_source, random, product_swaption);
			Console.WriteLine("Priced a {0}", product_swaption.ToString());


			Console.WriteLine("It took {0} seconds", pricing_results.time_taken);
			Console.WriteLine("Price is {0}", pricing_results.price);
			Console.WriteLine("Delta is");
			Console.WriteLine(pricing_results.greeks_delta);



//			// A down and out caplet
//			Products.IProduct product_down_and_out_caplet = new LivingFinance.BGM.Products.DownAndOutCaplet(N-2, STRIKE, STRIKE*0.999);
//			price(Ti, L0, covariance_matrix_source, random, product_down_and_out_caplet);
//
//			// A caplet - although swaption calibrated
//			Vector swaption_volatilities_market = LivingFinance.BGM.MarketData.SampleData.getSwaptionVols(N);
//			SwaptionVolatilityCalibrator swaption_volatility_calibrator = new SwaptionVolatilityCalibrator(Ti, L0, swaption_volatilities_market, covariance_matrix_source);
//			price(Ti, L0, swaption_volatility_calibrator, random, product_caplet);


			Console.WriteLine("Sleeping...");
			Thread.Sleep(200);
		}
	}
}
