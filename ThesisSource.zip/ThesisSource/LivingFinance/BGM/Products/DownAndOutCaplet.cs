using System;

namespace LivingFinance.BGM.Products
{
	public class DownAndOutCaplet : IProduct
	{
		int i;
		double strike;
		double down_barrier;

		public DownAndOutCaplet(int _i, double _strike, double _down_barrier)
		{
			i = _i;
			strike = _strike;
			down_barrier = _down_barrier;
		}

		public override string ToString()
		{
			return "Down-and-out caplet with strike " + strike + ", barrier " + down_barrier + " and maturity T" + i;
		}


		public void priceAgainstCurve(Utilities.Mathematics.LinearAlgebra.Matrix Li, Utilities.Mathematics.LinearAlgebra.Matrix Pi, Utilities.Mathematics.LinearAlgebra.Vector delta, Utilities.Mathematics.LinearAlgebra.Vector cashflows)
		{
			bool barrier_breached = false;
			
			// Check for a breach in barrier
			for (int j = 0; j < i; ++j)
			{
				if (Li[j,i] < down_barrier)
				{
					barrier_breached = true;
					break;
				}
			}

			// Define the payoffs only if the barrier was not breached
			if (!barrier_breached)
			{
				cashflows[i] = delta[i] * Math.Max(0.0, Li[i-1,i] - strike);
			}
		}
	}
}
