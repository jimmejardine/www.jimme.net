using System;

namespace LivingFinance.BGM.Products
{
	public class Caplet : IProduct
	{
		int i;
		double strike;

		public Caplet(int _i, double _strike)
		{
			i = _i;
			strike = _strike;
		}

		public override string ToString()
		{
			return "Caplet with strike " + strike + " and maturity T" + i;
		}
		
		public void priceAgainstCurve(Utilities.Mathematics.LinearAlgebra.Matrix Li, Utilities.Mathematics.LinearAlgebra.Matrix Pi, Utilities.Mathematics.LinearAlgebra.Vector delta, Utilities.Mathematics.LinearAlgebra.Vector cashflows)
		{
			cashflows[i] = delta[i] * Math.Max(0.0, Li[i-1,i] - strike);
		}
	}
}
