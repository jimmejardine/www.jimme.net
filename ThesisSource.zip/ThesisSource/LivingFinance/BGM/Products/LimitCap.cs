using System;

namespace LivingFinance.BGM.Products
{
	public class LimitCap : IProduct
	{
		int i;
		int j;
		int limit;
		double strike;

		public LimitCap(int _i, int _j, int _limit, double _strike)
		{
			i = _i;
			j = _j;
			limit = _limit;
			strike = _strike;
		}

		public override string ToString()
		{
			return String.Format("LimitCap with strike {0}, limit {1} and maturities from  T{2} to T{3}", strike, limit, i, j);
		}
		
		public void priceAgainstCurve(Utilities.Mathematics.LinearAlgebra.Matrix Li, Utilities.Mathematics.LinearAlgebra.Matrix Pi, Utilities.Mathematics.LinearAlgebra.Vector delta, Utilities.Mathematics.LinearAlgebra.Vector cashflows)
		{
			int limit_count = 0;

			for (int t = i; t <= j; ++t)
			{
				if (Li[t-1,t] - strike > 0)
				{
					++limit_count;
				}

				if (limit_count <= limit)
				{
					cashflows[t] = delta[t] * Math.Max(0.0, Li[t-1,t] - strike);
				}
			}
		}
	}
}
