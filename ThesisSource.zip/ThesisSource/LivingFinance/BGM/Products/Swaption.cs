using System;

namespace LivingFinance.BGM.Products
{
	public class Swaption : IProduct
	{
		int first_included_time;
		double strike;

		public Swaption(int _first_included_time, double _strike)
		{
			first_included_time = _first_included_time;
			strike = _strike;
		}

		public override string ToString()
		{
			return "Swaption with strike " + strike + " and first payment time T" + first_included_time;
		}
		
		public void priceAgainstCurve(Utilities.Mathematics.LinearAlgebra.Matrix Li, Utilities.Mathematics.LinearAlgebra.Matrix Pi, Utilities.Mathematics.LinearAlgebra.Vector delta, Utilities.Mathematics.LinearAlgebra.Vector cashflows)
		{
			int N = delta.cols;

			// Calculate the swap rate
			double w_denominator = 0.0;
			for (int k = first_included_time; k < N; ++k)
			{
				w_denominator += delta[k]*Pi[first_included_time,k];
			}

			// Loop through the time periods that comprise the swap
			double swap_rate = 0.0;
			for (int j = first_included_time; j < N; ++j)
			{
				double w_numerator = delta[j] * Pi[first_included_time,j];
				swap_rate += w_numerator / w_denominator * Li[first_included_time,j];
			}

			cashflows[first_included_time] = Math.Max(0.0, swap_rate - strike);
		}
	}
}
