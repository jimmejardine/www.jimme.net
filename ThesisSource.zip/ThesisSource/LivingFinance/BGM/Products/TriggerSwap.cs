using System;

namespace LivingFinance.BGM.Products
{
	public class TriggerSwap : IProduct
	{
		int first_included_time;
		double ceiling;

		public TriggerSwap(int _first_included_time, double _ceiling)
		{
			first_included_time = _first_included_time;
			ceiling = _ceiling;
		}

		public override string ToString()
		{
			return "TriggerSwap with ceiling " + ceiling + " and first payment time T" + first_included_time;
		}
		
		public void priceAgainstCurve(Utilities.Mathematics.LinearAlgebra.Matrix Li, Utilities.Mathematics.LinearAlgebra.Matrix Pi, Utilities.Mathematics.LinearAlgebra.Vector delta, Utilities.Mathematics.LinearAlgebra.Vector cashflows)
		{
			int N = delta.cols;

			for (int i = first_included_time; i < N; ++i)
			{
				cashflows[i] = delta[i] * Math.Min(ceiling, Li[i-1, i]);
			}
		}
	}
}
