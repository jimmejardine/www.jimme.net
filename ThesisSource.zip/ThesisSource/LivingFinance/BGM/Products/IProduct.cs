using System;
using Utilities.Mathematics.LinearAlgebra;

namespace LivingFinance.BGM.Products
{
	public interface IProduct
	{
		void priceAgainstCurve(Matrix Li, Matrix Pi, Vector delta, Vector cashflows);
	}
}
