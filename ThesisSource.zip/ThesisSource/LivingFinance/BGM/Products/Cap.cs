using System;

namespace LivingFinance.BGM.Products
{
	public class Cap : IProduct
	{
		int i;
		int j;
		double strike;

		public Cap(int _i, int _j, double _strike)
		{
			i = _i;
			j = _j;
			strike = _strike;
		}

		public override string ToString()
		{
			return String.Format("Cap with strike {0} and maturities from  T{1} to T{2}", strike, i, j);
		}
		
		public void priceAgainstCurve(Utilities.Mathematics.LinearAlgebra.Matrix Li, Utilities.Mathematics.LinearAlgebra.Matrix Pi, Utilities.Mathematics.LinearAlgebra.Vector delta, Utilities.Mathematics.LinearAlgebra.Vector cashflows)
		{
			for (int t = i; t <= j; ++t)
			{
				cashflows[t] = delta[t] * Math.Max(0.0, Li[t-1,t] - strike);
			}
		}
	}
}
