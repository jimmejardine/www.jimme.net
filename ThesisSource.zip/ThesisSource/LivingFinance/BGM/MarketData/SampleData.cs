using System;
using Utilities.Mathematics.LinearAlgebra;

namespace LivingFinance.BGM.MarketData
{
	public class SampleData
	{
		public static Vector getUniformMaturities(int N)
		{
			Vector Ti = new Vector(N);
			for (int i = 0; i < N; ++i)
			{
				Ti[i] = i;
			}
			return Ti;
		}
			
		// Define the maturities for which we have data
		public static Vector getMaturities(int N)
		{
			Vector Ti = new Vector(N);
			Ti[0] = 0.0;
			Ti[1] = 1.0;
			Ti[2] = 2.0;
			if (3 < N) Ti[3] = 5.0;
			if (4 < N) Ti[4] = 10.0;
			for (int i = 5; i < N; ++i)
			{
				Ti[i] = Ti[i-1] + 1;
			}

			return Ti;
		}

		// Define our initial forward curve 
		public static Vector getL0(int N)
		{
			Vector L0 = new Vector(N);
			L0[0] = 0.00;	// This is not actually used
			L0[1] = 0.02;
			L0[2] = 0.01;
			if (3 < N) L0[3] = 0.02;
			if (4 < N) L0[4] = 0.09;
			for (int i = 5; i < N; ++i)
			{
				L0[i] = L0[i-1] * 0.9;
			}

			return L0;
		}

		// Define some swaption vols
		public static Vector getSwaptionVols(int N)
		{
			double[] market10 =
				{
					0,
					0.09,
					0.09,
					0.10,
					0.14,
					0.15,
					0.16,
					0.17,
					0.18,
					0.178

//									0,
//					0.09,
//					0.09,
//					0.10,
//					0.14,
//					0.15,
//					0.16,
//					0.17,
//					0.18,
//					0.178
				};
	
			Vector swaption_volatilities_market = new Vector(N);
			for (int i = 0; i < N; ++i)
			{
				swaption_volatilities_market[i] = market10[Math.Min(9,i)];
			}

			return swaption_volatilities_market;
		}
	}
}
