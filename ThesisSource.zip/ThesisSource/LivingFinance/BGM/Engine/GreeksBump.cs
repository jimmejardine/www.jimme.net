using System;

namespace LivingFinance.BGM.Engine
{
	public class GreeksBump
	{
		public static double EPSILON = Math.Pow(Single.Epsilon, 0.25);
		public static double ONE_PERCENT = 0.01;
		public static double POINT_ONE_PERCENT = 0.001;
	}
}
