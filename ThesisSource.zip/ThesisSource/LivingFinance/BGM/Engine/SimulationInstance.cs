using System;
using Utilities.Mathematics.LinearAlgebra;

namespace LivingFinance.BGM.Engine
{
	public class SimulationInstance
	{
		// Convention L[t, i] = L(t, Ti-1, Ti]
		// Xi = log(Li)
		int N;
		public Matrix Li;
		public Matrix Xi;
		public Matrix Pi;

		public double pricing_total = 0.0;
		public double pricing_total_squared = 0.0;
		public double final_discounted_price = 0.0;
		
		public SimulationInstance(int aN)
		{
			N = aN;
			Li = new Matrix(N, N);			
			Xi = new Matrix(N, N);
			Pi = new Matrix(N, N);			
		}

		public void populateL0(Vector L0)
		{
			for (int i = 1; i < N; ++i)
			{
				Li[0,i] = L0[i];
				Xi[0,i] = Math.Log(Li[0,i]);
			}
		}

		public void bumpL0(int i, double ratio)
		{
			Li[0,i] += Li[0,i] * ratio;
			Xi[0,i] = Math.Log(Li[0,i]);
		}

		public void buildPi(Vector delta)
		{
			// Get our discount factors
			MonteCarloMaths.buildZeroCurveFromForwardCurve(Pi, Li, delta);

		}
	}
}
