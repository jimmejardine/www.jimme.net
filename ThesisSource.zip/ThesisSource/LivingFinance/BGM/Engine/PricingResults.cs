using System;
using Utilities.Mathematics.LinearAlgebra;
using Utilities.GUI.Charting;


namespace LivingFinance.BGM.Engine
{
	public class PricingResults
	{
		public double price = 0;
		public double standard_error = 0;
		public Series series_price = null;
		public Series series_error = null;
		public Vector greeks_delta = null;
		public Vector greeks_gamma = null;
		public double time_taken;
	}
}
