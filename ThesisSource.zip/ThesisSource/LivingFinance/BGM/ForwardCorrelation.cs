using System;

namespace LivingFinance.BGM
{
	public class ForwardCorrelation
	{
		double beta;

		public ForwardCorrelation()
		{
			beta = 0.1;
		}

		public double getCorrelation(double expiry_date_a, double expiry_date_b)
		{
			return Math.Exp(-beta*Math.Abs(expiry_date_a-expiry_date_b));
		}
	}
}
