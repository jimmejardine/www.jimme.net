using System;

using LivingFinance.Options.Equity.Portfolios;

namespace LivingFinance.Options.American
{
	public class OptionParameters
	{
		public double quantity;
		public PutCallType type;
		public double S0;
		public double K;
		public double T;
		public double r;
		public double q;
		public double sigma;

		public OptionParameters(OptionParameters other)
		{
			quantity = other.quantity;
			type = other.type;
			S0 = other.S0;
			K = other.K;
			T = other.T;
			r = other.r;
			q = other.q;
			sigma = other.sigma;
		}

		public OptionParameters(double aquantity, PutCallType atype, double aS0, double aK, double aT, double ar, double aq, double asigma)
		{
			quantity = aquantity;
			type = atype;
			S0 = aS0;
			K = aK;
			T = aT;
			r = ar;
			q = aq;
			sigma = asigma;
		}
	}
}
