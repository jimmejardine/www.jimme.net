using System;
using System.Collections;

using Utilities;
using LivingFinance.Options.Equity.Portfolios;

namespace LivingFinance.Options.American
{
	public class PortfolioPricer : Utilities.Mathematics.ObjectiveFunction.ObjectiveFunction
	{
		OptionParameters american_option_parameters;
		ArrayList portfolio;
		double T_current;
		
		public PortfolioPricer(OptionParameters aamerican_option_parameters, ArrayList aportfolio, double aT_current)
		{
			american_option_parameters = aamerican_option_parameters;
			portfolio = aportfolio;
			T_current = aT_current;
		}

		public double evaluate(double x)
		{
			return pricePortfolio(x) - priceAmerican(x);
		}
		
		public double priceAmerican(double S0)
		{
			if (PutCallType.CALL == american_option_parameters.type) return american_option_parameters.quantity * Math.Max(S0 - american_option_parameters.K, 0);
			if (PutCallType.PUT == american_option_parameters.type) return american_option_parameters.quantity * Math.Max(american_option_parameters.K - S0, 0);
			
			throw new GenericException("Unknown option type");
		}
			
		public double pricePortfolio(double S0)
		{
			if (null == portfolio)
			{
				return 0.0;
			}

			// Go through each trade in the portfolio and price it
			double total_price = 0.0;
			IEnumerator e = portfolio.GetEnumerator();
			while (e.MoveNext())
			{
				OptionParameters option_parameters = (OptionParameters) e.Current;

				if (T_current <= option_parameters.T)
				{
					total_price += option_parameters.quantity * LivingFinance.Options.Vanilla.Vanilla.calculatePrice(option_parameters.type, option_parameters.K, option_parameters.T - T_current, S0, option_parameters.q, option_parameters.sigma, option_parameters.r);
				}
			}

			return total_price;
		}

		public double getPortfolioDelta(double S0)
		{
			if (null == portfolio)
			{
				return 0.0;
			}

			// Go through each trade in the portfolio and price it
			double total_delta = 0.0;
			IEnumerator e = portfolio.GetEnumerator();
			while (e.MoveNext())
			{
				OptionParameters option_parameters = (OptionParameters) e.Current;

				if (T_current <= option_parameters.T)
				{
					total_delta += option_parameters.quantity * LivingFinance.Options.Vanilla.Vanilla.calculateDelta(option_parameters.type, option_parameters.K, option_parameters.T - T_current, S0, option_parameters.q, option_parameters.sigma, option_parameters.r);
				}
			}

			return total_delta;
		}
	}
}
