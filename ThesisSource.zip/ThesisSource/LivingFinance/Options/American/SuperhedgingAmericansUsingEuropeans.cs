using System;
using System.Collections;

using LivingFinance.Options.Equity.Portfolios;

namespace LivingFinance.Options.American
{
	public class SuperhedgingAmericansUsingEuropeans
	{
		public static double calculatePrice(OptionParameters american_option_parameters, int num_bases, bool show_steps, out ArrayList portfolio)
		{
			double PLOT_RANGE = 0.3;
			double PLOT_DENSITY = 50;

			Utilities.GUI.Charting.GenericChartForm charts = new Utilities.GUI.Charting.GenericChartForm();
			charts.setChartCounts(num_bases+1,1);
			for (int i = 0; i < num_bases+1; ++i)
			{
				charts[i].x_axis_title = "Stock price";
				charts[i].y1_axis_title = "Option/portfolio price";
			}
			charts.Text = "Charts of the time value of the American option and its superhedged portfolio";

			portfolio = new ArrayList();

			OptionParameters initial_option_parameters = new OptionParameters(american_option_parameters);
			portfolio.Add(initial_option_parameters);

			PortfolioPricer gui_portfolio_pricer = new PortfolioPricer(american_option_parameters, portfolio, 1);
			Utilities.GUI.Charting.Series series_american = new Utilities.GUI.Charting.Series("American", Utilities.GUI.Charting.ChartType.Line);
			for (double S0 = american_option_parameters.K * (1.0-PLOT_RANGE); S0 < american_option_parameters.K * (1.0+PLOT_RANGE); S0 += american_option_parameters.K/PLOT_DENSITY)
			{
				series_american.addPoint(S0, gui_portfolio_pricer.priceAmerican(S0));
			}
			charts[0,0].addSeries(series_american);
			charts[0,0].title = "Payoffs at T=" + Math.Round(american_option_parameters.T, 4);
			charts[0,0].Refresh();

			for (int i = 1; i < num_bases; ++i)
			{
				double T_current = (num_bases - i) * american_option_parameters.T / num_bases;

				PortfolioPricer portfolio_pricer = new PortfolioPricer(american_option_parameters, portfolio, T_current);

				Utilities.GUI.Charting.Series series_portfolio = new Utilities.GUI.Charting.Series("Without", Utilities.GUI.Charting.ChartType.Line);
				for (double S0 = american_option_parameters.K * (1.0-PLOT_RANGE); S0 < american_option_parameters.K * (1.0+PLOT_RANGE); S0 += american_option_parameters.K/PLOT_DENSITY)
				{
					series_portfolio.addPoint(S0, portfolio_pricer.pricePortfolio(S0));
				}

				// Find the interval containing our first intersection - it is somewhere just after the american strike, K
				double S_gap = american_option_parameters.K * 0.01;
				double S_lowest = american_option_parameters.K;
				double P_lowest = portfolio_pricer.evaluate(S_lowest);
				double S_highest = S_lowest;
				double P_highest = portfolio_pricer.evaluate(S_highest);
				do
				{
					S_highest += S_gap;
					P_highest = portfolio_pricer.evaluate(S_highest);
				} while (P_highest / P_lowest > 0 && P_highest / P_lowest < 1000);

				// Find the intersection point of our portfolio and the american option
				double S_star = Utilities.Mathematics.Optimisation.BisectionSearch.BisectionSearch.locateMonotonic(portfolio_pricer, S_lowest, S_highest, 0, 0.00001, 1000);
//				System.Console.WriteLine("S* is {0}", S_star);

				// Find the delta of our portfolio
				double delta = portfolio_pricer.getPortfolioDelta(S_star);
//				System.Console.WriteLine("Before new trade, delta is {0}", delta);

				// Add the corresponding new trade to our portfolio
				OptionParameters optiolina_option_parameters = new OptionParameters(american_option_parameters);
				optiolina_option_parameters.K = S_star;
				optiolina_option_parameters.S0 = S_star;
				optiolina_option_parameters.T = T_current;
				optiolina_option_parameters.quantity = american_option_parameters.quantity - delta;
				portfolio.Add(optiolina_option_parameters);
			
				PortfolioPricer portfolio_pricer_new = new PortfolioPricer(american_option_parameters, portfolio, T_current);
				double delta_new = portfolio_pricer_new.getPortfolioDelta(S_star);
//				System.Console.WriteLine("After new trade, delta is {0}", delta_new);

				Utilities.GUI.Charting.Series series_portfolio_new = new Utilities.GUI.Charting.Series("With", Utilities.GUI.Charting.ChartType.Line);
				for (double S0 = american_option_parameters.K * (1.0-PLOT_RANGE); S0 < american_option_parameters.K * (1.0+PLOT_RANGE); S0 += american_option_parameters.K/PLOT_DENSITY)
				{
					series_portfolio_new.addPoint(S0, portfolio_pricer_new.pricePortfolio(S0));
				}

				charts[i,0].title = "Payoffs at T=" + Math.Round(T_current, 4);
				charts[i,0].addSeries(series_american);
				charts[i,0].addSeries(series_portfolio);
				charts[i,0].addSeries(series_portfolio_new);
				charts[i,0].Refresh();			
			}

			PortfolioPricer portfolio_pricer_final = new PortfolioPricer(american_option_parameters, portfolio, 0.0);
			Utilities.GUI.Charting.Series series_portfolio_final = new Utilities.GUI.Charting.Series("Portfolio", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_european_final = new Utilities.GUI.Charting.Series("European", Utilities.GUI.Charting.ChartType.Line);
			for (double S0 = american_option_parameters.K * (1.0-PLOT_RANGE); S0 < american_option_parameters.K * (1.0+PLOT_RANGE); S0 += american_option_parameters.K/PLOT_DENSITY)
			{
				series_portfolio_final.addPoint(S0, portfolio_pricer_final.pricePortfolio(S0));
				series_european_final.addPoint(S0, american_option_parameters.quantity*Vanilla.Vanilla.calculatePrice(american_option_parameters.type, american_option_parameters.K, american_option_parameters.T, S0, american_option_parameters.q, american_option_parameters.sigma, american_option_parameters.r));
			}

			charts[num_bases,0].title = "Payoffs at T=0";
			charts[num_bases,0].addSeries(series_american);
			charts[num_bases,0].addSeries(series_portfolio_final);
			charts[num_bases,0].addSeries(series_european_final);
			charts[num_bases,0].Refresh();

			charts.BackColor = System.Drawing.Color.White;

			if (show_steps)
			{
				charts.ShowDialog();
			}
			
			return portfolio_pricer_final.pricePortfolio(american_option_parameters.S0);
		}
		

		public static void TestHarness_ShowPaperSteps()
		{
			// First a pretty picture
			OptionParameters american_option_parameters = new OptionParameters(1, PutCallType.CALL, 105, 105, 3, 0.0425, 0.065, 0.1);
			ArrayList portfolio;
			double american_price = calculatePrice(american_option_parameters, 3, true, out portfolio);
			System.Console.WriteLine("Superhedged price is {0}", american_price);
		}

		public static void TestHarness_ShowPrices()
		{
			OptionParameters american_option_parameters = new OptionParameters(1, PutCallType.CALL, 105, 105, 3, 0.0425, 0.065, 0.1);

			Utilities.GUI.Charting.Series series = new Utilities.GUI.Charting.Series("Portfolio price", Utilities.GUI.Charting.ChartType.LineAndPoint);
			
			for (int i = 1; i < 20; ++i)
			{
				ArrayList portfolio;
				double american_price = calculatePrice(american_option_parameters, i, false, out portfolio);
				series.addPoint(i, american_price);
			}

			Utilities.GUI.Charting.GenericChartForm charts = new Utilities.GUI.Charting.GenericChartForm();
			charts.Text = "Plot of portfolio price for various number of replicating timesteps";
			charts.setChartCounts(1,1);
			charts[0].addSeries(series);
			charts[0].x_axis_title = "Number of replicating timesteps";
			charts[0].y1_axis_title = "Portfolio price";
			charts[0].legend_height = 0;
			charts[0].title = "Plot of portfolio price for various number of replicating timesteps";
			charts.ShowDialog();

		}

		public static void TestHarness()
		{			
			TestHarness_ShowPaperSteps();
			TestHarness_ShowPrices();
		}
	}
}
