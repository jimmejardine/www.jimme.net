using System;

using LivingFinance.Options.Equity.Portfolios;
using Utilities.Mathematics.Optimisation.BisectionSearch;

namespace LivingFinance.Options.Vanilla
{
	public class ImpliedVolatility
	{
		public static double calculateImpliedVol(PutCallType type, double K, double T, double S0, double q, double r, double price)
		{
			double vol_lower = 0.001;
			double vol_upper = 1.0;;

			ImpliedVolatilityObjective objective = new ImpliedVolatilityObjective(type, K, T, S0, q, r);
			return BisectionSearch.locateMonotonic(objective, vol_lower, vol_upper, price, 0.000001, 1000);
		}

		public static void TestHarness()
		{
			double input_vol = 0.24;

			double price = Vanilla.calculatePrice(PutCallType.CALL, 100, 1, 100, 0, input_vol, 0);
			double implied_vol = ImpliedVolatility.calculateImpliedVol(PutCallType.CALL, 100, 1, 100, 0, 0, price);
			System.Console.WriteLine("implied vol is {0} and should be {1}", implied_vol, input_vol);

		}
	}
}
