using System;

using LivingFinance.Options.Equity.Portfolios;
using Utilities;

namespace LivingFinance.Options.Vanilla
{
	public class Vanilla
	{
		public static void TestHarness()
		{
			System.Console.WriteLine("Vanilla price is {0}", calculatePrice(PutCallType.CALL, 100, 1, 100, 0.07, 0.20, 0.05));
		}

		public static double N(double x)
		{
			return Utilities.Mathematics.Statistics.Distributions.Distributions.CDistStandardNormal(x);
		}

		public static double convertTypeToAlpha(PutCallType type)
		{
			// Work out our alpha values
			if (PutCallType.CALL == type)
			{
				return 1.0;
			}
			else if (PutCallType.PUT == type)
			{
				return -1.0;
			}
			else
			{
				PutCallType.ThrowUnknownType(type);
				return 0.0;
			}
		}
		
		public static double calculatePrice(PutCallType type, double K, double T, double S0, double q, double sigma, double r)
		{
			// Deal with options at expiry
			if (0.0 == T)
			{
				if (PutCallType.CALL == type) return Math.Max(S0-K, 0.0);
				if (PutCallType.PUT == type) return Math.Max(K-S0, 0.0);
				PutCallType.ThrowUnknownType(type);
			}

			double alpha = convertTypeToAlpha(type);

			double d1 = (Math.Log(S0/K) + (r - q + 0.5 * sigma*sigma) * T) / (sigma * Math.Sqrt(T));
			double d2 = d1 - (sigma * Math.Sqrt(T));

			return 0.0
				+ alpha*S0 * Math.Exp(-q*T) * N(alpha*d1)
				- alpha*K * Math.Exp(-r*T) * N(alpha*d2);
		}

		public static double calculateDelta(PutCallType type, double K, double T, double S0, double q, double sigma, double r)
		{
			// Deal with options at expiry
			if (0.0 == T)
			{
				if (PutCallType.CALL == type) return (S0 >= K) ? 1.0 : 0.0;
				if (PutCallType.PUT == type) return (K >= S0) ? -1.0 : 0.0;
				PutCallType.ThrowUnknownType(type);
				return 0.0;
			}

			
			double d1 = (Math.Log(S0/K) + (r - q + 0.5 * sigma*sigma) * T) / (sigma * Math.Sqrt(T));
			if (PutCallType.CALL == type) return N(d1);
			if (PutCallType.PUT == type) return 1.0 - N(d1);
			PutCallType.ThrowUnknownType(type);
			return 0.0;
		}
	}
}
