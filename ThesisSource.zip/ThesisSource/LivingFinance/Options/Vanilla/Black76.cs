using LivingFinance.Options.Equity.Portfolios;
using System;

namespace LivingFinance.Options.Vanilla
{
	public class Black76
	{
		private static double N(double x)
		{
			return Vanilla.N(x);
		}

		public static double convertTypeToAlpha(PutCallType type)
		{
			return Vanilla.convertTypeToAlpha(type);
		}

		public static double calculatePrice(PutCallType type, double K, double T, double S0, double sigma, double discount)
		{
			// Deal with options at expiry
			if (0.0 == T)
			{
				if (PutCallType.CALL == type) return Math.Max(S0-K, 0.0);
				if (PutCallType.PUT == type) return Math.Max(K-S0, 0.0);
				PutCallType.ThrowUnknownType(type);
			}

			double alpha = convertTypeToAlpha(type);

			double d1 = (Math.Log(S0/K) + (0.5 * sigma*sigma) * T) / (sigma * Math.Sqrt(T));
			double d2 = d1 - (sigma * Math.Sqrt(T));

			return discount * (alpha*S0 * N(alpha*d1) - alpha*K * N(alpha*d2));
		}

		public static double calculatePrice_UsingCumulativeVol(PutCallType type, double K, double T, double S0, double sigma_root_T, double discount)
		{
			// Deal with options at expiry
			if (0.0 == T)
			{
				if (PutCallType.CALL == type) return Math.Max(S0-K, 0.0);
				if (PutCallType.PUT == type) return Math.Max(K-S0, 0.0);
				PutCallType.ThrowUnknownType(type);
			}

			double alpha = convertTypeToAlpha(type);

			double d1 = (Math.Log(S0/K) + 0.5*sigma_root_T*sigma_root_T) / sigma_root_T;
			double d2 = d1 - sigma_root_T;

			return discount * (alpha*S0 * N(alpha*d1) - alpha*K * N(alpha*d2));
		}

	}
}
