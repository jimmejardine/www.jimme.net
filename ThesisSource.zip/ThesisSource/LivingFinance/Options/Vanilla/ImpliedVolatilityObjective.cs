using System;

using Utilities.Mathematics;
using Utilities.Mathematics.Optimisation.BisectionSearch;
using LivingFinance.Options.Equity.Portfolios;

namespace LivingFinance.Options.Vanilla
{
	public class ImpliedVolatilityObjective : Utilities.Mathematics.ObjectiveFunction.ObjectiveFunction
	{
		PutCallType type;
		double K;
		double T;
		double S0;
		double q;
		double r;

		public ImpliedVolatilityObjective(PutCallType type, double K, double T, double S0, double q, double r)
		{
			this.type = type;
			this.K = K;
			this.T = T;
			this.S0 = S0;
			this.q = q;
			this.r = r;
		}

		public double evaluate(double x)
		{
			return Vanilla.calculatePrice(type, K, T, S0, q, x, r);
		}
	}
}
