using System;

using Utilities.Mathematics.LinearAlgebra;
using Utilities;

namespace LivingFinance.Options.Exotics
{
	public class RainbowOptions
	{
		public static void showSimpleOption()
		{
			Vector S0 = new Vector(3);
			
			Vector q = new Vector(3);
			q[0] = 0.0;
			q[1] = 0.0;
			q[2] = 0.0;
			
			Matrix volatility = new Matrix(3,3);
			volatility[0,0] = 0.2;
			volatility[1,1] = 0.3;
			volatility[2,2] = 0.4;

			double r = 0.05;
			double T = 1;
			double K = 0;

			S0[0] = 100; S0[1] = 100;  S0[2] = 100;  K = 100;
			System.Console.WriteLine("The price is {0}", calculatePriceOfMaxAndCash(r, T, K, S0, q, volatility));
		}
		
		public static void chartOption_VaryingCorrelation(string chart_title)
		{
			Vector S0 = new Vector(3);
			
			Vector q = new Vector(3);
			q[0] = 0.0;
			q[1] = 0.0;
			q[2] = 0.0;
			
			Matrix volatility = new Matrix(3,3);
			volatility[0,0] = 0.2;
			volatility[1,1] = 0.3;
			volatility[2,2] = 0.4;

			volatility[0,1] = volatility[1,0] = volatility[0,2] = volatility[2,0] = volatility[1,2] = volatility[2,1] = 0;

			double r = 0.05;
			double T = 1;
			double K = 0;

			Utilities.GUI.Charting.Series series = new Utilities.GUI.Charting.Series("Asset correlation", Utilities.GUI.Charting.ChartType.Line);

			for (double vol = 0; vol <= 1; vol += 0.01)
			{
				S0[0] = 100; S0[1] = 100;  S0[2] = 100;  K = 100;
				volatility[0,1] = volatility[1,0] = volatility[0,2] = volatility[2,0] = volatility[1,2] = volatility[2,1] = vol;
				series.addPoint(vol, calculatePriceOfMaxAndCash(r, T, K, S0, q, volatility));
			}

			Utilities.GUI.Charting.GenericChartForm charts = new Utilities.GUI.Charting.GenericChartForm();
			charts.BackColor = System.Drawing.Color.White;
			charts.Text = "Plots of rainbow option price against asset correlation";
			charts.setChartCounts(1,1);

			charts[0,0].title = chart_title;
			charts[0,0].x_axis_title = "Asset correlation";
			charts[0,0].y1_axis_title = "Option price";
			charts[0,0].legend_height = 0;
			charts[0,0].addSeries(series);

			charts.ShowDialog();

		}

		public static void chartOption(string chart_title, double stock_correlation)
		{
			Vector S0 = new Vector(3);
			
			Vector q = new Vector(3);
			q[0] = 0.0;
			q[1] = 0.0;
			q[2] = 0.0;
			
			Matrix volatility = new Matrix(3,3);
			volatility[0,0] = 0.2;
			volatility[1,1] = 0.3;
			volatility[2,2] = 0.4;


			volatility[0,1] = volatility[1,0] = stock_correlation;
			volatility[0,2] = volatility[2,0] = stock_correlation;
			volatility[1,2] = volatility[2,1] = stock_correlation;

			double r = 0.05;
			double T = 1;
			double K = 0;

			Utilities.GUI.Charting.Series series_1 = new Utilities.GUI.Charting.Series("Asset 1", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_2 = new Utilities.GUI.Charting.Series("Asset 2", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_3 = new Utilities.GUI.Charting.Series("Asset 3", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_K = new Utilities.GUI.Charting.Series("Cash strike", Utilities.GUI.Charting.ChartType.Line);

			for (double i = 10; i <= 190; i+=10)
			{
				S0[0] = i; S0[1] = 100;  S0[2] = 100;  K = 100;
				series_1.addPoint(i, calculatePriceOfMaxAndCash(r, T, K, S0, q, volatility));

				S0[0] = 100; S0[1] = i;  S0[2] = 100;  K = 100;
				series_2.addPoint(i, calculatePriceOfMaxAndCash(r, T, K, S0, q, volatility));

				S0[0] = 100; S0[1] = 100;  S0[2] = i;  K = 100;
				series_3.addPoint(i, calculatePriceOfMaxAndCash(r, T, K, S0, q, volatility));

				S0[0] = 100; S0[1] = 100;  S0[2] = 100;  K = i;
				series_K.addPoint(i, calculatePriceOfMaxAndCash(r, T, K, S0, q, volatility));
			}

			Utilities.GUI.Charting.GenericChartForm charts = new Utilities.GUI.Charting.GenericChartForm();
			charts.BackColor = System.Drawing.Color.White;
			charts.Text = "Plots of various rainbow options";
			charts.setChartCounts(1,1);

			charts[0,0].title = chart_title;
			charts[0,0].addSeries(series_1);
			charts[0,0].addSeries(series_2);
			charts[0,0].addSeries(series_3);
			charts[0,0].addSeries(series_K);

			charts.ShowDialog();

		}

		public static void TestHarness()
		{
			//chartOption("No correlation between assets", 0.0);
			//chartOption("Correlation between assets", 0.5);
			chartOption_VaryingCorrelation("Varying asset correlations");
		}

		public static double calculatePriceOfMaxAndCash(double r, double T, double K, Vector aS0, Vector aq, Matrix avolatility)
		{
			Vector S0 = aS0;
			Vector q = aq;
			Matrix volatility = avolatility;

			// If we have a cash minimum, treat the cash as a Asset with no volatility
			if (K > 0)
			{
				Vector tS0 = new Vector(S0.cols+1);
				for (int i = 0; i < S0.cols; ++i)
				{
					tS0[i] = S0[i];
				}
				tS0[S0.cols] = K * Math.Exp(-r*T);

				Vector tq = new Vector(q.cols+1);
				for (int i = 0; i < q.cols; ++i)
				{
					tq[i] = q[i];
				}
				tq[q.cols] = 0;

				Matrix tvolatility = new Matrix(volatility.rows+1, volatility.cols+1);
				for (int i = 0; i < volatility.rows; ++i)
				{
					for (int j = 0; j < volatility.cols; ++j)
					{
						tvolatility[i,j] = volatility[i,j];
					}
				}

				S0 = tS0;
				q = tq;
				volatility = tvolatility;
			}


			int num_stocks = S0.cols;

			// Check that our matrices are reasonable
			if (num_stocks != S0.cols) throw new GenericException("Bad dimensions for S0");
			if (num_stocks != q.cols) throw new GenericException("Bad dimensions for q");
			if (num_stocks != volatility.cols && num_stocks != volatility.rows) throw new GenericException("Bad dimensions for correlation");

			// Initialise the total premium
			double total_price = 0.0;

			// Work out the total premium given that each stock might be the maximum
			for (int k = 0; k < num_stocks; ++k)
			{
				Vector d = new Vector(num_stocks-1);

				// Calculate d
				for (int m = 0; m < num_stocks; ++m)
				{
					// Skip the kth row and offset the array one back for all elements after k
					if (m == k) continue;
					int m_arr = m < k ? m : m-1;

					double sigma_squared_mk = 0;
					for (int i = 0; i < num_stocks; ++i)
					{
						sigma_squared_mk += (volatility[m,i] - volatility[k,i])*(volatility[m,i] - volatility[k,i]);
					}
					
					d[m_arr] = -(Math.Log(S0[m] / S0[k]) + (q[k] - q[m] - 0.5 * sigma_squared_mk) * T) / Math.Sqrt(sigma_squared_mk * T);
				}

				// Calculate rho
				Matrix rho = new Matrix(num_stocks-1, num_stocks-1);
				for (int m = 0; m < num_stocks; ++m)
				{
					// Skip the kth row and offset the array one back for all elements after k
					if (m == k) continue;
					int m_arr = m < k ? m : m-1;

					for (int n = 0; n < num_stocks; ++n)
					{
						// Skip the kth row and offset the array one back for all elements after k
						if (n == k) continue;
						int n_arr = n < k ? n : n-1;

						double sigma_mk_nk = 0;
						double sigma_mk_mk = 0;
						double sigma_nk_nk = 0;
						for (int i = 0; i < num_stocks; ++i)
						{
							sigma_mk_nk += (volatility[m,i] - volatility[k,i])*(volatility[n,i] - volatility[k,i]);
							sigma_mk_mk += (volatility[m,i] - volatility[k,i])*(volatility[m,i] - volatility[k,i]);
							sigma_nk_nk += (volatility[n,i] - volatility[k,i])*(volatility[n,i] - volatility[k,i]);
						}

						rho[m_arr,n_arr] = sigma_mk_nk / Math.Sqrt(sigma_mk_mk * sigma_nk_nk);
					}
				}

				// Now that we have our z values and correlations, use the multivariate to get the probabilities
//				System.Console.WriteLine("Price {0} is {1} with xvalue {2}", k, S0[k] * Math.Exp(-q[k] * T) * Utilities.Mathematics.Statistics.Distributions.GenzMultivariate.CNorm(d, rho), d[0]);
				total_price += S0[k] * Math.Exp(-q[k] * T) * Utilities.Mathematics.Statistics.Distributions.GenzMultivariate.CNorm(d, rho);
			}
			
			// Return our result
			return total_price;
		}
	}
}
