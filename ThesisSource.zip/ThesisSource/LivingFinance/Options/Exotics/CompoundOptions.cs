using System;

using LivingFinance.Options.Equity.Portfolios;
using Utilities.Mathematics.LinearAlgebra;
using Utilities;

namespace LivingFinance.Options.Exotics
{
	public class CompoundOptions
	{
		public static void TestHarness()
		{
			double T_compound = 1;
			double T_underlying = 2;
			double S0 = 100;
			double Q = 0.07;
			double SIGMA = 0.25;
			double R = 0.05;

			Utilities.GUI.Charting.Series series_coc_strike_compound = new Utilities.GUI.Charting.Series("Compound strike", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_coc_strike_underlying = new Utilities.GUI.Charting.Series("Underlying strike", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_coc_S0 = new Utilities.GUI.Charting.Series("S0", Utilities.GUI.Charting.ChartType.Line);

			Utilities.GUI.Charting.Series series_cop_strike_compound = new Utilities.GUI.Charting.Series("Compound strike", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_cop_strike_underlying = new Utilities.GUI.Charting.Series("Underlying strike", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_cop_S0 = new Utilities.GUI.Charting.Series("S0", Utilities.GUI.Charting.ChartType.Line);
			
			Utilities.GUI.Charting.Series series_poc_strike_compound = new Utilities.GUI.Charting.Series("Compound strike", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_poc_strike_underlying = new Utilities.GUI.Charting.Series("Underlying strike", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_poc_S0 = new Utilities.GUI.Charting.Series("S0", Utilities.GUI.Charting.ChartType.Line);

			Utilities.GUI.Charting.Series series_pop_strike_compound = new Utilities.GUI.Charting.Series("Compound strike", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_pop_strike_underlying = new Utilities.GUI.Charting.Series("Underlying strike", Utilities.GUI.Charting.ChartType.Line);
			Utilities.GUI.Charting.Series series_pop_S0 = new Utilities.GUI.Charting.Series("S0", Utilities.GUI.Charting.ChartType.Line);

			for (double k = 0.5*S0; k <= 1.5*S0; k+=1)
			{
				series_coc_strike_compound.addPoint(k, calculatePrice(PutCallType.CALL, k, T_compound, PutCallType.CALL, S0, T_underlying, S0, Q, SIGMA, R));
				series_coc_strike_underlying.addPoint(k, calculatePrice(PutCallType.CALL, S0, T_compound, PutCallType.CALL, k, T_underlying, S0, Q, SIGMA, R));
				series_coc_S0.addPoint(k, calculatePrice(PutCallType.CALL, S0, T_compound, PutCallType.CALL, S0, T_underlying, k, Q, SIGMA, R));

				series_cop_strike_compound.addPoint(k, calculatePrice(PutCallType.CALL, k, T_compound, PutCallType.PUT, S0, T_underlying, S0, Q, SIGMA, R));
				series_cop_strike_underlying.addPoint(k, calculatePrice(PutCallType.CALL, S0, T_compound, PutCallType.PUT, k, T_underlying, S0, Q, SIGMA, R));
				series_cop_S0.addPoint(k, calculatePrice(PutCallType.CALL, S0, T_compound, PutCallType.PUT, S0, T_underlying, k, Q, SIGMA, R));

				series_poc_strike_compound.addPoint(k, calculatePrice(PutCallType.PUT, k, T_compound, PutCallType.CALL, S0, T_underlying, S0, Q, SIGMA, R));
				series_poc_strike_underlying.addPoint(k, calculatePrice(PutCallType.PUT, S0, T_compound, PutCallType.CALL, k, T_underlying, S0, Q, SIGMA, R));
				series_poc_S0.addPoint(k, calculatePrice(PutCallType.PUT, S0, T_compound, PutCallType.CALL, S0, T_underlying, k, Q, SIGMA, R));

				series_pop_strike_compound.addPoint(k, calculatePrice(PutCallType.PUT, k, T_compound, PutCallType.PUT, S0, T_underlying, S0, Q, SIGMA, R));
				series_pop_strike_underlying.addPoint(k, calculatePrice(PutCallType.PUT, S0, T_compound, PutCallType.PUT, k, T_underlying, S0, Q, SIGMA, R));
				series_pop_S0.addPoint(k, calculatePrice(PutCallType.PUT, S0, T_compound, PutCallType.PUT, S0, T_underlying, k, Q, SIGMA, R));
			}

			Utilities.GUI.Charting.GenericChartForm charts = new Utilities.GUI.Charting.GenericChartForm();
			charts.BackColor = System.Drawing.Color.White;
			charts.Text = "Plots of various compound options";
			charts.setChartCounts(3,4);

			for (int i = 0; i < 12; ++i)
			{
				charts[i].title_height = 20;
				charts[i].legend_height = 0;
			}

			charts[0,0].y1_axis_title = "Call-on-Call";
			charts[0,1].y1_axis_title = "Call-on-Put";
			charts[0,2].y1_axis_title = "Put-on-Call";
			charts[0,3].y1_axis_title = "Put-on-Put";

			charts[0,3].x_axis_title = "Varying compound K";
			charts[1,3].x_axis_title = "Varying underlying K";
			charts[2,3].x_axis_title = "Varying S0";

			charts[0,0].addSeries(series_coc_strike_compound);
			charts[1,0].addSeries(series_coc_strike_underlying);
			charts[2,0].addSeries(series_coc_S0);

			charts[0,1].addSeries(series_cop_strike_compound);
			charts[1,1].addSeries(series_cop_strike_underlying);
			charts[2,1].addSeries(series_cop_S0);

			charts[0,2].addSeries(series_poc_strike_compound);
			charts[1,2].addSeries(series_poc_strike_underlying);
			charts[2,2].addSeries(series_poc_S0);

			charts[0,3].addSeries(series_pop_strike_compound);
			charts[1,3].addSeries(series_pop_strike_underlying);
			charts[2,3].addSeries(series_pop_S0);


			charts.ShowDialog();


			System.Console.WriteLine("Compound price is {0}", calculatePrice(PutCallType.CALL, 100, 1, PutCallType.CALL, 100, 2, 100, 0.07, 0.20, 0.05));
			System.Console.WriteLine("Compound price is {0}", calculatePrice(PutCallType.CALL, 100, 1, PutCallType.PUT, 100, 2, 100, 0.07, 0.20, 0.05));
			System.Console.WriteLine("Compound price is {0}", calculatePrice(PutCallType.PUT, 100, 1, PutCallType.CALL, 100, 2, 100, 0.07, 0.20, 0.05));
			System.Console.WriteLine("Compound price is {0}", calculatePrice(PutCallType.PUT, 100, 1, PutCallType.PUT, 100, 2, 100, 0.07, 0.20, 0.05));
		}

		private static double N(double x)
		{
			return Utilities.Mathematics.Statistics.Distributions.Distributions.CDistStandardNormal(x);
		}

		private static double N(double x, double y, double rho)
		{
			return Utilities.Mathematics.Statistics.Distributions.DreznerBivariate.CBivariateStandardNormal(x, y, rho);
//			return Utilities.Mathematics.Statistics.Distributions.GenzMultivariate.CNorm_2D(x, y, rho);
		}

		public static double calculatePrice(PutCallType type_compound, double K_compound, double T_compound, PutCallType type_underlying, double K_underlying, double T_underlying, double S0, double q, double sigma, double r)
		{
			bool found_price;
			double S_star = calculateCompoundATMStockPrice(type_underlying, T_compound, K_underlying, T_underlying, K_compound, q, sigma, r, out found_price);

			if (!found_price)
			{
				return Double.NaN;
			}

			double x1 = (Math.Log(S0/S_star) + (r - q + 0.5 * sigma*sigma) * T_compound) / (sigma * Math.Sqrt(T_compound));
			double x2 = x1 - (sigma * Math.Sqrt(T_compound));
			
			double y1 = (Math.Log(S0/K_underlying) + (r - q + 0.5 * sigma*sigma) * T_underlying) / (sigma * Math.Sqrt(T_underlying));
			double y2 = y1 - (sigma * Math.Sqrt(T_underlying));

			double rho = Math.Sqrt(T_compound / T_underlying);

			if (PutCallType.CALL == type_compound && PutCallType.CALL == type_underlying)
			{
				// var A = (assetprice * Math.exp((carry - zinssatz) * timeToMaturityUnderlying) * CBND(z1, y1, rho));
				// var B = ((strikepriceUnderlying * Math.exp((-1) * zinssatz * timeToMaturityUnderlying) * CBND(z2, y2, rho)));
				// var C = (strikeprice * Math.exp(-zinssatz * timeToMaturity) * CND(y2));
				//  value = A - B - C;
				return
					+ S0 * Math.Exp(-q*T_underlying) * N(y1, x1, rho)
					- K_underlying * Math.Exp(-r*T_underlying) * N(y2, x2, rho)
					- K_compound * Math.Exp(-r*T_compound) * N(x2);	
			}
			
			else if (PutCallType.CALL == type_compound && PutCallType.PUT == type_underlying)
			{
				// value =
				//		strikepriceUnderlying * Math.exp(-zinssatz * timeToMaturityUnderlying) * CBND(-z2, -y2, rho) 
				//		- assetprice * Math.exp((carry - zinssatz) * timeToMaturityUnderlying) * CBND(-z1, -y1, rho)
				//		- strikeprice * Math.exp(-zinssatz * timeToMaturity) * CND(-y2)
				return 
					- S0 * Math.Exp(-q*T_underlying) * N(-y1, -x1, rho)
					+ K_underlying * Math.Exp(-r*T_underlying) * N(-y2, -x2, rho)
					- K_compound * Math.Exp(-r*T_compound) * N(-x2);			
			}
			
			else if (PutCallType.PUT == type_compound && PutCallType.CALL == type_underlying)
			{
				// value = 
				//		strikepriceUnderlying * Math.exp(-zinssatz * timeToMaturityUnderlying) * CBND(z2, -y2, -rho) 
				//		- assetprice * Math.exp((carry - zinssatz) * timeToMaturityUnderlying) * CBND(z1, -y1, -rho) 
				//		+ strikeprice * Math.exp(-zinssatz * timeToMaturity) * CND(-y2)
				return 
					- S0 * Math.Exp(-q*T_underlying) * N(y1, -x1, -rho)
					+ K_underlying * Math.Exp(-r*T_underlying) * N(y2, -x2, -rho)
					+ K_compound * Math.Exp(-r*T_compound) * N(-x2);			
			}
			else if (PutCallType.PUT == type_compound && PutCallType.PUT == type_underlying)
			{
				// value = 
				//		assetprice * Math.exp((carry - zinssatz) * timeToMaturityUnderlying) * CBND(-z1, y1, -rho) 
				//		- strikepriceUnderlying * Math.exp(-zinssatz * timeToMaturityUnderlying) * CBND(-z2, y2, -rho) 
				//		+ Math.exp(-zinssatz * timeToMaturity) * strikeprice * CND(y2);
				return
					+ S0 * Math.Exp(-q*T_underlying) * N(-y1, x1, -rho)
					- K_underlying * Math.Exp(-r*T_underlying) * N(-y2, x2, -rho)
					+ K_compound * Math.Exp(-r*T_compound) * N(x2);			
			}

			else
			{
				PutCallType.ThrowUnknownType();
				return 0;
			}
			
//			double alpha_underlying = LivingFinance.Options.Vanilla.Vanilla.convertTypeToAlpha(type_underlying);
//			double alpha_compound = LivingFinance.Options.Vanilla.Vanilla.convertTypeToAlpha(type_compound);
//			double AA = alpha_underlying*alpha_compound*S0 * Math.Exp(-q*T_underlying) * N(alpha_underlying*alpha_compound*x1, alpha_underlying*y1, alpha_compound*rho);
//			double BB = alpha_underlying*alpha_compound*K_underlying * Math.Exp(-r*T_underlying) * N(alpha_underlying*alpha_compound*x2, alpha_underlying*y2, alpha_compound*rho);
//			double CC = alpha_underlying*K_compound * Math.Exp(-r*T_compound) * N(alpha_underlying*alpha_compound*x2);			
//			return 0.0
//				+ AA
//				- BB
//				- CC;
		}

		// This method determines where the compound option expires ATM.
		// That is, we search the value of S_star for an option starting at T_compound, ending at T_underlying, strike K_compound such that the option price is K_compound.
		// Currently using the bisection method.
		private static double calculateCompoundATMStockPrice(PutCallType type_underlying, double T_compound, double K_underlying, double T_underlying, double K_compound, double q, double sigma, double r, out bool found_price)
		{
			// *** There is some thinking to be done here for puts where their value can never be the same as some specified strike - they are limited by the stock price...
			// *** We will use a simplified approach for now and and exception will be thrown if there is any misbehaviour
			if (PutCallType.PUT ==  type_underlying && K_compound > K_underlying)
			{
				found_price = false;
				return 0;
			}

			double S_min = 0.0001;
			double S_max = 100000;
			double P_min = LivingFinance.Options.Vanilla.Vanilla.calculatePrice(type_underlying, K_underlying, T_underlying-T_compound, S_min, q, sigma, r);
			double P_max = LivingFinance.Options.Vanilla.Vanilla.calculatePrice(type_underlying, K_underlying, T_underlying-T_compound, S_max, q, sigma, r);

			while (!Utilities.Mathematics.Precision.closeToZero(S_max - S_min))
			{
				double S_current = 0.5 * (S_min + S_max);
				double P_current = LivingFinance.Options.Vanilla.Vanilla.calculatePrice(type_underlying, K_underlying, T_underlying-T_compound, S_current, q, sigma, r);

				if ((K_compound > P_current && P_max >  P_current) || (K_compound < P_current && P_max < P_current))
				{
					S_min = S_current;
					P_min = LivingFinance.Options.Vanilla.Vanilla.calculatePrice(type_underlying, K_underlying, T_underlying-T_compound, S_min, q, sigma, r);
				}
				
				else if ((K_compound < P_current && P_min <  P_current) || (K_compound > P_current && P_min > P_current))
				{
					S_max = S_current;
					P_max = LivingFinance.Options.Vanilla.Vanilla.calculatePrice(type_underlying, K_underlying, T_underlying-T_compound, S_max, q, sigma, r);
				}

				else
				{
					throw new GenericException("The price curve does not seem to be monotonic!");
				}
			}

			double aS_current = 0.5 * (S_min + S_max);
			double aP_current = LivingFinance.Options.Vanilla.Vanilla.calculatePrice(type_underlying, K_underlying, T_underlying-T_compound, aS_current, q, sigma, r);
			if (!Utilities.Mathematics.Precision.closeToZero(aP_current - K_compound))
			{
				//System.Console.WriteLine("Testing S* at {0} gives {1} not {2}", aS_current, aP_current, K_compound);
			}

			found_price = true;
			return 0.5 * (S_max + S_min);
		}
	}
}
