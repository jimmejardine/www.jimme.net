using System;
using Utilities.Mathematics;
using LivingFinance.Options.Equity.Portfolios;
using Utilities.Mathematics.Optimisation.NelderMead;
using Utilities.Mathematics.LinearAlgebra;
using Utilities;

namespace LivingFinance.Options.Equity.SABR
{
	public class SABRMathematics
	{
		public static double calcAlpha(double beta, double tau, double F, double rho, double nu, double sigma_atm)
		{
			// Calculate the coefficients of the cubic
			double a3 = Math.Pow(1.0 - beta, 2.0) * tau / (24.0 * Math.Pow(F, 2.0 - 2.0*beta));
			double a2 = rho * beta * nu * tau / (4.0 * Math.Pow(F, 1-beta));
			double a1 = 1.0 + (2.0 - 3*Math.Pow(rho, 2.0))/24.0*Math.Pow(nu,2.0)*tau;
			double a0 = -sigma_atm*Math.Pow(F, 1-beta);

			// Find our three roots
			Complex o1, o2, o3;
			Utilities.Mathematics.Polynomials.findCubicRoot(a3,a2,a1,a0, out o1, out o2, out o3);


			// We want to use the smallest positive root
			double result = o1.real;
			if (result < 0.0 || !o2.isComplex() && o2.real > 0.0 && o2.real < result)
			{
				result = o2.real;
			}
			if (result < 0.0 || !o3.isComplex() && o3.real > 0.0 && o3.real < result)
			{
				result = o3.real;
			}

			// Return the root
			return result;
		}		

		public static double calcSigma(double alpha, double beta, double nu, double rho, double tau, double F, double X)
		{
			double z = calcZ(nu, alpha, beta, F, X);
			double chi = calcChi(rho, z);

			if (Utilities.Mathematics.Precision.closeTo(F, X))
			{
				return (alpha * (1.0 + ((1.0-beta)*(1.0-beta)/24.0*alpha*alpha/Math.Pow(F, 2.0-2.0*beta) + 1.0/4.0*rho*beta*nu*alpha/Math.Pow(F, 1-beta) + (2.0-3.0*rho*rho)*nu*nu/24.0) * tau)) / (Math.Pow(F, 1-beta));
			}

			else
			{
				double num = (alpha * (1.0 + ((1.0-beta)*(1.0-beta)/24.0*alpha*alpha/Math.Pow(F*X, 1.0-beta) + 1.0/4.0*rho*beta*nu*alpha/Math.Pow(F*X, 0.5*(1.0-beta)) + (2.0-3.0*rho*rho)*nu*nu/24.0) * tau));
				double den = Math.Pow(F*X, 0.5*(1.0-beta)) * (1.0 + (1.0-beta)*(1.0-beta)/24.0*Math.Pow(Math.Log(F/X), 2.0) + Math.Pow((1.0-beta),4.0)/1920.0*Math.Pow(Math.Log(F/X), 4));

				if (Utilities.Mathematics.Precision.closeToZero(chi))
				{
					return (num / den);
				}
				else
				{
					return (num / den) * (z / chi);
				}
			}
		}
		
		public static double calcZ(double nu, double alpha, double beta, double F, double X)
		{
			if (Utilities.Mathematics.Precision.closeTo(F, X))
			{
				return 0.0;
			}
			else
			{
				return (nu / alpha) * Math.Pow(F*X, 0.5*(1.0-beta)) * Math.Log(F/X);
			}
		}

		public static double calcChi(double rho, double z)
		{
			return Math.Log((Math.Sqrt(1 - 2*rho*z+ z*z) + z - rho)/(1 - rho));	
		}


		public static void TestHarness()
		{
			double beta = 0.7;
			double tau = 2;
			double F = 600;
			double rho = -0.22;
			double nu = 0.40;
			double sigma_atm = 0.21;
			double X = 700;

			double alpha = calcAlpha(beta, tau, F, rho, nu, sigma_atm);
			double sigma = calcSigma(alpha, beta, nu, rho, tau, F, X);
			System.Console.WriteLine("Alpha is {0}", alpha);
			System.Console.WriteLine("Sigma is {0}", sigma);
		}

		public static double[] calculateGroupVolatilities(double beta, double rho, double nu, Trade[] trades)
		{
			const int MAX_ITERATIONS = 1000;
			int num_iterations = 0;

			int num_trades = trades.Length;

			// First we calculate the true_premium
			double true_premium = 0.0;
			for (int i = 0; i < num_trades; ++i)
			{
				Trade trade = trades[i];
				true_premium += priceTradeUsingSafexBlack(trade, trade.volatility);
			}

			// Build our L and K entries
			double [] L = new double[num_trades];
			double [] K = new double[num_trades];
			for (int i = 0; i < num_trades; ++i)
			{
				Trade trade = trades[i];
				double alpha = SABRMathematics.calcAlpha(beta, trade.tau, trade.mtm_future, rho, nu, trade.atm_vol);
				double sigma_model = SABRMathematics.calcSigma(alpha, beta, nu, rho, trade.tau, trade.mtm_future, trade.strike);

				L[i] = 2 * Math.Abs(trade.quantity) * SafexBlack.vega(trade.mtm_future, trade.strike, sigma_model, trade.tau);
				K[i] = L[i] * sigma_model;
			}

			// Build our n+1 vectors and n+1 x n+1 matrix for the jacobian
			Matrix x = new Matrix(num_trades+1,1);
			Matrix F = new Matrix(num_trades+1,1);
			Matrix J = new Matrix(num_trades+1,num_trades+1);
			
			// Populate initial x
			for (int i = 0; i < num_trades; ++i)
			{
				Trade trade = trades[i];
				double alpha = SABRMathematics.calcAlpha(beta, trade.tau, trade.mtm_future, rho, nu, trade.atm_vol);
				double sigma_model = SABRMathematics.calcSigma(alpha, beta, nu, rho, trade.tau, trade.mtm_future, trade.strike);

				x.data[i,0] = sigma_model;
			}
			x.data[num_trades,0] = 0.0;

			// Repeat forever unless our conditions are met inside the loop
			while (true)
			{
				// Work out our modelled premium for the current iteration
				double model_premium = 0.0;
				for (int i = 0; i < num_trades; ++i)
				{
					model_premium += priceTradeUsingSafexBlack(trades[i], x.data[i,0]);
				}

				// Populate our F
				for (int i = 0; i < num_trades; ++i)
				{
					Trade trade = trades[i];
					double vega = SafexBlack.vega(trade.mtm_future, trade.strike, x.data[i,0], trade.tau);
					F.data[i,0] = L[i] * x.data[i,0] - K[i] - x.data[num_trades,0] * trade.quantity * vega;
				}
				F.data[num_trades,0] = model_premium - true_premium;

				// Jacobian - initialise
				for (int i = 0; i < num_trades+1; ++i)
				{
					for (int j = 0; j < num_trades+1; ++j)
					{
						J.data[i,j] = 0.0;
					}
				}

				// Jacobian - diagonals (not bottom-right)
				for (int i = 0; i < num_trades; ++i)
				{
					Trade trade = trades[i];
					double volga = SafexBlack.volga(trade.mtm_future, trade.strike, x.data[i,0], trade.tau);
					J.data[i,i] = L[i] - x.data[num_trades,0] * trade.quantity * volga;
				}

				// Jacobian - bottom row and right column
				for (int i = 0; i < num_trades; ++i)
				{
					Trade trade = trades[i];

					double vega = SafexBlack.vega(trade.mtm_future, trade.strike, x.data[i,0], trade.tau);

					// Bottom row
					J.data[num_trades,i] = trade.quantity * vega;

					// Right column
					J.data[i,num_trades] = -trade.quantity * vega;
				}

				// Calculate the new x iteration
				LUDecomposition lu_decomposition = new LUDecomposition(J);
				Matrix new_x = x.subtract(lu_decomposition.solve(F));

				// Check that the new x values are positive
				for (int i = 0; i < num_trades; ++i)
				{
					if (0.0 > x.data[i,0])
					{
						x.data[i,0] = 0.0;
					}
				}

				// Calculate the convergence difference
				Matrix difference_vector = new_x.subtract(x);
				double difference_value = Norms.Norm2(difference_vector);

				// Update our position
				x = new_x;

				// Break out if we have converged
				if (difference_value < 1E-6)
				{
					break;
				}

				// If we have exceeded our maximum number of iterations
				if (++num_iterations > MAX_ITERATIONS)
				{
					throw new GenericException("Exceeded maximum number of iterations during 2D Newton's method.");
				}
			} // End of iteration of newton2d

			double[] fitted_vols = new double[num_trades];
			for (int i = 0; i < num_trades; ++i)
			{
				fitted_vols[i] = x.data[i,0];
			}

			return fitted_vols;
		}

		public static double priceTradeUsingSafexBlack(Trade trade, double volatility_override)
		{
			if (PutCallType.CALL == trade.putcalltype)
			{
				return trade.quantity * SafexBlack.priceCall(trade.mtm_future, trade.strike, volatility_override, trade.tau);
			}
			else if (PutCallType.PUT == trade.putcalltype)
			{
				return trade.quantity * SafexBlack.pricePut(trade.mtm_future, trade.strike, volatility_override, trade.tau);
			}
			else
			{
				PutCallType.ThrowUnknownType(trade.putcalltype);
				return 0.0;
			}
		}



	}
}
