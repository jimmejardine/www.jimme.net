using System;
using System.Collections;

using LivingFinance.Options.Equity.Portfolios;
using Utilities.Mathematics.Optimisation.NelderMead;
using Utilities.Mathematics.LinearAlgebra;
using Utilities;

namespace LivingFinance.Options.Equity.SABR
{
	public class SABRSearchObjective : ObjectiveFunction2D
	{
		double beta;
		Portfolio portfolio;
		double lambda;

		public SABRSearchObjective(double abeta, Portfolio aportfolio, double alambda)
		{
			beta = abeta;
			portfolio = aportfolio;
			lambda = alambda;
		}

		public double evaluate(Point2D p)
		{
			return evaluate_UsingSimplePremiumComparison(p);
		}

		public double evaluate_UsingSimplePremiumComparison(Point2D p)
		{
			double rho = p.x;
			double nu = p.y;

			double total_error = 0.0;

			// First do all the trades that are not in a group
			IEnumerator i_groupless_trades = portfolio.getGrouplessTradeEnumerator();
			while (i_groupless_trades.MoveNext())
			{
				Trade trade = (Trade) i_groupless_trades.Current;

				double true_premium = SABRMathematics.priceTradeUsingSafexBlack(trade, trade.volatility);

				double alpha = SABRMathematics.calcAlpha(beta, trade.tau, trade.mtm_future, rho, nu, trade.atm_vol);
				double sigma_model = SABRMathematics.calcSigma(alpha, beta, nu, rho, trade.tau, trade.mtm_future, trade.strike);
				double model_premium = SABRMathematics.priceTradeUsingSafexBlack(trade, sigma_model);
				
				TimeSpan trade_age_span = trade.expiry_date.Subtract(trade.trade_date);
				double trade_age = trade_age_span.Days / 365.0;
				double weight = Math.Pow(lambda, trade_age);

				total_error += weight * Math.Abs(true_premium - model_premium);
			}
			
			// Then the trades in a group
			IEnumerator i_trade_group = portfolio.getTradeGroupEnumerator();
			while (i_trade_group.MoveNext())
			{
				DictionaryEntry trade_group_dictionaryentry = (DictionaryEntry) i_trade_group.Current;
				Portfolio trade_group = (Portfolio) trade_group_dictionaryentry.Value;

				double true_premium = 0.0;
				double model_premium = 0.0;
				
				IEnumerator i_trade = trade_group.getTradeEnumerator();
				while (i_trade.MoveNext())
				{
					Trade trade = (Trade) i_trade.Current;

					true_premium += SABRMathematics.priceTradeUsingSafexBlack(trade, trade.volatility);

					double alpha = SABRMathematics.calcAlpha(beta, trade.tau, trade.mtm_future, rho, nu, trade.atm_vol);
					double sigma_model = SABRMathematics.calcSigma(alpha, beta, nu, rho, trade.tau, trade.mtm_future, trade.strike);
					model_premium += SABRMathematics.priceTradeUsingSafexBlack(trade, sigma_model);
				}

				Trade first_trade = trade_group.getFirstTrade();
				TimeSpan trade_age_span = first_trade.expiry_date.Subtract(first_trade.trade_date);
				double trade_age = trade_age_span.Days / 365.0;
				double weight = Math.Pow(lambda, trade_age);

				total_error += weight * Math.Abs(true_premium - model_premium);
			}

			return total_error;
		}
		
		public double evaluate_UsingNewtonRaphson(Point2D p)
		{
			double rho = p.x;
			double nu = p.y;

			double total_error = 0.0;

			// First do all the trades that are not in a group
			IEnumerator i_groupless_trades = portfolio.getGrouplessTradeEnumerator();
			while (i_groupless_trades.MoveNext())
			{
				Trade trade = (Trade) i_groupless_trades.Current;
				double single_error = evaluateTrade(rho, nu, trade);
				total_error += single_error;
			}
			
			// Then the trades in a group
			IEnumerator i_trade_group = portfolio.getTradeGroupEnumerator();
			while (i_trade_group.MoveNext())
			{
				DictionaryEntry trade_group_entry = (DictionaryEntry) i_trade_group.Current;
				Portfolio trade_group = (Portfolio) trade_group_entry.Value;
				if (1 == trade_group.Count)
				{
					double single_error = evaluateTrade(rho, nu, trade_group.getFirstTrade());
					total_error += single_error;
				}

				else
				{
					double single_error = evaluateTradeGroup(beta, rho, nu, trade_group);
					total_error += single_error;
				}
			}

			return total_error;
		}

		double evaluateTradeGroup(double beta, double rho, double nu, Portfolio portfolio)
		{
			// Count the number of trades in this group
			int num_trades = portfolio.Count;

			// Copy the enumerator into an array
			Trade [] trades = portfolio.getTradesArray();
			double[] fitted_vols = SABRMathematics.calculateGroupVolatilities(beta, rho, nu, trades);

			// Work out the final cost of this portfolio using our fitted vols
			double total_cost = 0.0;
			for (int i = 0; i < num_trades; ++i)
			{
				total_cost += evaluateTrade(rho, nu, trades[i], fitted_vols[i]);
			}
			
			return total_cost;
		}
		
		
		double evaluateTrade(double rho, double nu, Trade trade)
		{
			return evaluateTrade(rho, nu, trade, trade.volatility);
		}

		double evaluateTrade(double rho, double nu, Trade trade, double volatility_override)
		{
			double alpha = SABRMathematics.calcAlpha(beta, trade.tau, trade.mtm_future, rho, nu, trade.atm_vol);
			double sigma_model = SABRMathematics.calcSigma(alpha, beta, nu, rho, trade.tau, trade.mtm_future, trade.strike);
			double vega = SafexBlack.vega(trade.mtm_future, trade.strike, sigma_model, trade.tau);

			TimeSpan trade_age_span = trade.expiry_date.Subtract(trade.trade_date);
			double trade_age = trade_age_span.Days / 365.0;

			double error_contribution = Math.Abs(trade.quantity)*vega*Math.Pow(sigma_model - volatility_override, 2.0);
			double weight = Math.Pow(lambda, trade_age);
			double error = weight * error_contribution;

			return error;
		}

		
		public double old_evaluate(Point2D p)
		{
			double rho = p.x;
			double nu = p.y;

			double total_error = 0.0;

			IEnumerator i = portfolio.getTradeEnumerator();
			while (i.MoveNext())
			{
				Trade trade = (Trade) i.Current;

				double alpha = SABRMathematics.calcAlpha(beta, trade.tau, trade.mtm_future, rho, nu, trade.atm_vol);
				double sigma_model = SABRMathematics.calcSigma(alpha, beta, nu, rho, trade.tau, trade.mtm_future, trade.strike);
				double vega = SafexBlack.vega(trade.mtm_future, trade.strike, sigma_model, trade.tau);

				TimeSpan trade_age_span = trade.expiry_date.Subtract(trade.trade_date);
				double trade_age = trade_age_span.Days / 365.0;

				double error_contribution = Math.Abs(trade.quantity)*vega*Math.Pow(sigma_model - trade.volatility, 2.0);
				double weight = Math.Pow(lambda, trade_age);
				double error = weight * error_contribution;
				total_error += error;
			}

			return total_error;
		}

		public void constrainSearch(ref Point2D p)
		{
			const double MIN_RHO = -0.9;
			const double MIN_NU = 0.01;

			if (p.x < MIN_RHO)
			{
				p.x = MIN_RHO;
			}

			if (p.y < MIN_NU)
			{
				p.y = MIN_NU;
			}
		}
	}
}
