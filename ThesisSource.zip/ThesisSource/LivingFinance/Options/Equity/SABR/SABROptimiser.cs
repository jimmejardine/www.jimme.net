using System;
using System.Collections;
using System.Windows.Forms;

using LivingFinance.Options.Equity.Portfolios;
using Utilities;
using Utilities.Mathematics.Optimisation.NelderMead;

namespace LivingFinance.Options.Equity.SABR
{
	public class SABROptimiser
	{
		public static void optimise(double lambda, double beta, Portfolio portfolio, out double rho, out double nu, out double optimal_score)
		{
			const double TOLERANCE = 2E-5;
			const int MAX_ITERATIONS = 1000;
			Point2D p1 = new Point2D(-0.32, 0.5);
			Point2D p2 = new Point2D(-0.70, 0.3);
			Point2D p3 = new Point2D(-0.60, 0.6);
			
			NelderMead2D neldermead = new NelderMead2D();
			neldermead.TOLERANCE = TOLERANCE;
			neldermead.MAX_ITERATIONS = MAX_ITERATIONS;

			SABRSearchObjective searchobjective = new SABRSearchObjective(beta, portfolio, lambda);
			neldermead.initialiseSearch(searchobjective, p1, p2, p3);
			
			string error_message;
			Point2D optimum = neldermead.search(out error_message, out optimal_score);
			if (error_message.Length > 0)
			{
				MessageBox.Show(error_message, "Error during calibration", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}

			rho = optimum.x;
			nu = optimum.y;
		}

		public static void TestHarness()
		{
			ArrayList errors;

			Portfolio portfolio = Portfolio.loadSamplePortfolioFromFile(out errors);
			const double lambda = 0.98;
			double beta = 0.3;
			
			double rho;
			double nu;
			double optimal_score;
			SABROptimiser.optimise(lambda, beta, portfolio, out rho, out nu, out optimal_score);
			System.Console.WriteLine("rho={0}, nu={1}, score={2}", rho, nu, optimal_score);
		}

		public static double[,] getSampleValley(out string x_name, out double x_min, out double x_max, out string y_name, out double y_min, out double y_max)
		{
			const int rows = 50;
			const int cols = 50;

			const double rho_from = -1.0;
			const double rho_to = 0.9;
			const double nu_from = 0.01;
			const double nu_to = 0.2;

			return getParametrisedSampleValley(rows, cols, rho_from, rho_to, nu_from, nu_to, out x_name, out x_min, out x_max, out y_name, out y_min, out y_max);
		}
		
		public static double[,] getParametrisedSampleValley(int rows, int cols, double x_from, double x_to, double y_from, double y_to, out string x_name, out double x_min, out double x_max, out string y_name, out double y_min, out double y_max)
		{
			double rho_from = x_from;
			double rho_to = x_to;
			double nu_from = y_from;
			double nu_to = y_to;
			
			ArrayList errors;
			Portfolio portfolio = Portfolio.loadSampleHugePortfolioWithGroupsFromFile(out errors);
//			Portfolio portfolio = Portfolio.loadSamplePortfolioWithGroupsFromFile(out errors);
//			Portfolio portfolio = Portfolio.loadSamplePortfolioFromFile(out errors);
			const double lambda = 0.98;
			double beta = 0.3;

			double nelder_rho;
			double nelder_nu;
			double nelder_optimal_score;
			SABROptimiser.optimise(lambda, beta, portfolio, out nelder_rho, out nelder_nu, out nelder_optimal_score);
			
			SABRSearchObjective searchobjective = new SABRSearchObjective(beta, portfolio, lambda);
			System.Console.WriteLine("Optimal point: rho={0}, nu={1}, score={2}, value={3}", nelder_rho, nelder_nu, nelder_optimal_score, searchobjective.evaluate(new Point2D(nelder_rho, nelder_nu)));

			double[,] result = new double[rows, cols];
			Point2D current_point = new Point2D();
			
			for (int i = 0; i < rows; ++i)
			{
				for (int j = 0; j < cols; ++j)
				{
					double rho = rho_from + i * (rho_to - rho_from) / (rows-1);
					double nu = nu_from + j * (nu_to - nu_from) / (cols-1);

					current_point.x = rho;
					current_point.y = nu;

					result[i,j] = searchobjective.evaluate(current_point);
				}
			}

			x_name = "rho";
			x_min = rho_from;
			x_max = rho_to;
			y_name = "nu";
			y_min = nu_from;
			y_max = nu_to;

			return result;
		}
	}
}
