using System;

namespace LivingFinance.Options.Equity.Safex.Mtm
{
	public class MTMEntry
	{
		public DateTime date;
		public string contract;
		public double future;
		public double atm_vol;

		public MTMEntry(DateTime adate, string acontract, double afuture, double aatm_vol)
		{
			date = adate;
			contract = acontract;
			future = afuture;
			atm_vol = aatm_vol;
		}
	}
}
