using System;
using System.Collections;

using Utilities;

namespace LivingFinance.Options.Equity.Safex.Mtm
{
	public class MTMDataset
	{
		ArrayList dataset;

		public MTMDataset()
		{
			dataset = new ArrayList();
		}

		public void readFromExcelFile()
		{
			throw new Utilities.NotImplementedException();
		}

		public void readSampleDatabase()
		{
			dataset.Add(new MTMEntry(DateTime.Parse("10 Jan 2005"), "Mar05", 101.0, 0.255));
			dataset.Add(new MTMEntry(DateTime.Parse("11 Jan 2005"), "Mar05", 102.0, 0.24));
			dataset.Add(new MTMEntry(DateTime.Parse("12 Jan 2005"), "Mar05", 100.0, 0.25));
		}

		public double getMTMVol(DateTime date, string contract)
		{
			double future;
			double atm_vol;
			getMTMDetails(date, contract, out future, out atm_vol);
			return atm_vol;
		}
		
		public void getMTMDetails(DateTime date, string contract, out double future, out double atm_vol)
		{
			IEnumerator i = dataset.GetEnumerator();
			while (i.MoveNext())
			{
				MTMEntry entry = (MTMEntry) i.Current;
				if (entry.date == date && entry.contract == contract)
				{
					future = entry.future;
					atm_vol = entry.atm_vol;
					return;
				}
			}

			throw new GenericException("Database contains no information for " + contract + " on " + date);
		}
	}
}
