using System;

using Utilities;

namespace LivingFinance.Options.Equity.Safex
{
	public class SafexExpiryCalculator
	{
		// Mar05
		// Jun, Sep, Dec
		

		public static bool isPublicHoliday_ZA(DateTime date)
		{
			if (01 == date.Month && 01 == date.Day) return true;
			if (03 == date.Month && 21 == date.Day) return true;
			if (04 == date.Month && 27 == date.Day) return true;
			if (05 == date.Month && 01 == date.Day) return true;
			if (06 == date.Month && 16 == date.Day) return true;
			if (08 == date.Month && 09 == date.Day) return true;
			if (09 == date.Month && 24 == date.Day) return true;
			if (12 == date.Month && 16 == date.Day) return true;
			if (12 == date.Month && 25 == date.Day) return true;
			if (12 == date.Month && 26 == date.Day) return true;


			return false;
		}

		public static DateTime parseSafexExpiryDate(string expiry_date)
		{
			if (expiry_date.Length == 5)
			{
				return lookupSafexContractExpiry(expiry_date);
			}
			else
			{
				return DateTime.Parse(expiry_date);
			}
		}

		public static DateTime lookupSafexContractExpiry(string contract_name)
		{
			if (contract_name.Length != 5)
			{
				throw new GenericException("Contract name " + contract_name + " is not 5 characters long.");
			}

			string month_string = contract_name.Substring(0, 3);
			int year = 2000 + Int32.Parse(contract_name.Substring(3, 2));
			DateTime start_date = DateTime.Parse("1 " + month_string + " " + year);
			int month = start_date.Month;
			int day_of_month = getDayOfMonth(year, month, 5, 3);

			DateTime contract_date = new DateTime(year, month, day_of_month);;
			while (isPublicHoliday_ZA(contract_date))
			{
				contract_date = contract_date.Subtract(new TimeSpan(1,0,0,0));
			}

			return contract_date;
		}

		static int mapMonthNameToNumber(string month_name)
		{
			throw new GenericException("Not implemented");
		}

		
		static int getDayOfMonth(int year, int month, int required_day_of_week, int nth)
		{
			// Get day of week (such that Sun = 1, Sat = 7)
			int iSoMDoW = (int)(new DateTime(year, month, 1)).DayOfWeek + 1;

			if (iSoMDoW > required_day_of_week)
			{
				return 7 * nth - iSoMDoW + required_day_of_week + 1;
			}
			else
			{
				return 7 * (nth - 1) - iSoMDoW + required_day_of_week + 1;
			}
		}

		public static void TestHarness()
		{
			System.Console.WriteLine("First monday is {0}", getDayOfMonth(2005, 1, 2, 1));

			System.Console.WriteLine("Mar05 is {0}", lookupSafexContractExpiry("Mar05"));
			System.Console.WriteLine("Jun05 is {0}", lookupSafexContractExpiry("Jun05"));
			System.Console.WriteLine("Mar06 is {0}", lookupSafexContractExpiry("Mar06"));
			System.Console.WriteLine("Mar07 is {0}", lookupSafexContractExpiry("Mar07"));
			System.Console.WriteLine("Dec07 is {0}", lookupSafexContractExpiry("Dec07"));
			System.Console.WriteLine("Dec10 is {0}", lookupSafexContractExpiry("Dec10"));
		}
	}
}
