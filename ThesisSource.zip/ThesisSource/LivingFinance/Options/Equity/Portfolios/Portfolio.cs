using System;
using System.Collections;
using System.Text;

using Utilities;

namespace LivingFinance.Options.Equity.Portfolios
{
	public class Portfolio
	{
		ArrayList trades;
		ArrayList groupless_trades;
		Hashtable trade_groups;

		public Portfolio()
		{
			trades = new ArrayList();
			groupless_trades = new ArrayList();
			trade_groups = new Hashtable();
		}

		public void addTrade(Trade trade)
		{
			addTrade(trade, true);
		}

		public void addTrade(Trade trade, bool add_to_group)
		{
			// Add the trade to our full trade list
			trades.Add(trade);

			if (trade.trade_group.Length == 0)
			{
				groupless_trades.Add(trade);
			}

			// Add this trade to the groups structure if it belongs to a group and if we are tracking groups in this portfolio
			if (add_to_group && trade.trade_group.Length > 0)
			{
				// Get the trade group portfolio for this trade group id
				Portfolio trade_group = (Portfolio) trade_groups[trade.trade_group];

				// If one does not exist, create one
				if (null == trade_group)
				{
					trade_group = new Portfolio();
					trade_groups[trade.trade_group] = trade_group;
				}

				// Add the trade to the trade group
				trade_group.addTrade(trade, false);
			}
		}

		public int Count
		{
			get
			{
				return trades.Count;
			}
		}

		public Trade this[int index]
		{
			get
			{
				return (Trade) trades[index];
			}
		}
		
		public Trade getFirstTrade()
		{
			if (0 < Count)
			{
				return (Trade) trades[0];
			}
			else
			{
				return null;
			}
		}
		
		public IEnumerator getTradeEnumerator()
		{	
			return trades.GetEnumerator();
		}

		public IEnumerator getTradeGroupEnumerator()
		{
			// UNCOMMENT THE SLOW LINE TO AID DEBUGGING
			return getTradeGroupEnumerator_Fast();
			//return getTradeGroupEnumerator_Slow();
		}

		public IEnumerator getGrouplessTradeEnumerator()
		{
			return groupless_trades.GetEnumerator();
		}
		
		public IEnumerator getTradeGroupEnumerator_Slow()
		{
			ArrayList arraylist = new ArrayList();

			arraylist.AddRange(trade_groups);
			arraylist.Sort(new TradeGroupSorter());

			return arraylist.GetEnumerator();
		}
	
		public IEnumerator getTradeGroupEnumerator_Fast()
		{
			return trade_groups.GetEnumerator();

		}

		public Trade[] getTradesArray()
		{
			int i_array = 0;
			Trade [] trades = new Trade[this.Count];
			IEnumerator i_trade = this.getTradeEnumerator();
			while (i_trade.MoveNext())
			{
				Trade trade = (Trade) i_trade.Current;
				trades[i_array] = trade;
				++i_array;
			}

			return trades;
		}


		public string dump()
		{
			StringBuilder sb = new StringBuilder();

			sb.AppendFormat("A portfolio with {0} items\n", Count);
			
			IEnumerator i = getTradeEnumerator();
			while (i.MoveNext())
			{
				Trade trade = (Trade) i.Current;
				sb.Append(trade.dump());
			}

			return sb.ToString();
		}

		public void readFromCSVFile(string filename, out ArrayList errors)
		{
			string[] lines = Utilities.Files.TextFile.loadTextFile(filename);
			readFromCSVLines(lines, out errors);
		}
		
		public void readFromCSVLines(string[] lines, out ArrayList errors)
		{
			// Create the resulting error array
			errors = new ArrayList();

			// Parse the lines
			for (int i = 0; i < lines.Length; ++i)
			{
				string line = lines[i];

				try
				{
					// Ignore comments and empties
					if (0 == line.Length || line.StartsWith("//"))
					{
						continue;
					}

					string[] elements = Utilities.Files.CSV.splitAtCommas(line);

					// Not allowed any empty fields except the OrderID field
					for (int j = 0; j < 8; ++j)
					{
						if (elements[j].Length == 0)
						{
							throw new GenericException("Trade on line " + i + " has missing information in field " + j + ".");
						}
					}

					// Expiry date, Trade Date, Futures, ATM Volatility, Strike, Volatility, Style, Quantum, Order ID
					
					Trade trade = new Trade();
					trade.expiry_date = Safex.SafexExpiryCalculator.parseSafexExpiryDate(elements[0]);
					trade.trade_date = DateTime.Parse(elements[1]);
					trade.mtm_future = Double.Parse(elements[2]);
					trade.atm_vol = Utilities.Mathematics.General.parsePercentage(elements[3]);
					trade.strike = Double.Parse(elements[4]);
					trade.volatility = Utilities.Mathematics.General.parsePercentage(elements[5]);
					trade.putcalltype = PutCallType.Parse(elements[6]);
					trade.quantity = Double.Parse(elements[7]);
					trade.trade_group = elements[8];

					this.addTrade(trade);
				}

				catch (Exception e)
				{
					errors.Add(new PortfolioReadError(i, line, e.Message));
				}
			}
		}
		
		public void readFromTraderSkewCSVLines(string[] lines, out ArrayList errors)
		{
			// These are common across all trades
			DateTime common_trade_date = DateTime.Now;
			PutCallType common_putcalltype = PutCallType.CALL;

			// These are common only to a group of trades
			DateTime common_expiry_date = DateTime.Now;
			double common_atm_vol = 0.0;
			double common_mtm_future = 0.0;
			bool have_common_info = false;

			// Create the resulting error array
			errors = new ArrayList();

			for (int i = 0; i < lines.Length; ++i)
			{
				// Skip comments
				if (lines[i].StartsWith("//"))
				{
					continue;
				}
				
				// Skip blanks
				if (lines[i].Length == 0)
				{
					continue;
				}

				try
				{
					string[] elements = Utilities.Files.CSV.splitAtCommas(lines[i]);

					// If we have a common information  line
					if (elements.Length == 3)
					{
						// CSV: Expiry date,ATM vol,ATM future
						common_expiry_date = Safex.SafexExpiryCalculator.parseSafexExpiryDate(elements[0]);
						common_atm_vol = Utilities.Mathematics.General.parsePercentage(elements[1]);
						common_mtm_future = Double.Parse(elements[2]);
						have_common_info = true;
					}

					// Else if we have a trade line
					else if (elements.Length == 2)
					{
						// If we have not yet had a common into line, we have a problem
						if (!have_common_info)
						{
							throw new GenericException("We do not have any common information defined for this trade");
						}

						// CSV: strike, vol
						Trade trade = new Trade();
						trade.expiry_date = common_expiry_date;
						trade.trade_date = common_trade_date;
						trade.mtm_future = common_mtm_future;
						trade.atm_vol = common_atm_vol;
						trade.strike = Double.Parse(elements[0]);
						trade.volatility = Utilities.Mathematics.General.parsePercentage(elements[1]);
						trade.putcalltype = common_putcalltype;
						trade.quantity = 1;
						trade.trade_group = "";

						this.addTrade(trade);
					}

					// Otherwise we have something we dont understand
					else
					{
						throw new Exception("We discovered a line with an unexpected number of items (should be 2 or 3)");
					}
				}

				catch (Exception e)
				{
					errors.Add(new PortfolioReadError(i, lines[i], e.Message));
				}
			}
		}
		

		// Some test harness functionality
		
		public static void TestHarness()
		{
			Portfolio portfolio = generateSamplePortfolio();
			System.Console.WriteLine(portfolio.dump());
		}

		public static Portfolio loadSamplePortfolioFromFile(out ArrayList errors)
		{
			Portfolio portfolio = new Portfolio();
			portfolio.readFromCSVFile(@"Z:\Personal\Development\FinancialData\SafexPortfolio\test portfolio.csv", out errors);
			return portfolio;
		}


		public static Portfolio loadSamplePortfolioWithGroupsFromFile(out ArrayList errors)
		{
			Portfolio portfolio = new Portfolio();
			portfolio.readFromCSVFile(@"Z:\Personal\Development\FinancialData\SafexPortfolio\test portfolio with groups.csv", out errors);
			return portfolio;
		}

		public static Portfolio loadSampleHugePortfolioWithGroupsFromFile(out ArrayList errors)
		{
			Portfolio portfolio = new Portfolio();
			portfolio.readFromCSVFile(@"Z:\Personal\Development\FinancialData\SafexPortfolio\test huge portfolio with groups.csv", out errors);
			return portfolio;
		}

		public static Portfolio generateSamplePortfolio()
		{
			Portfolio portfolio = new Portfolio();
			portfolio.addTrade(new Trade(DateTime.Parse("10 Jan 2003"), DateTime.Parse("17 March 2005"),100.0, 100.00, 0.25, 1000, PutCallType.CALL, "JJ100", 100.00, .25));
			portfolio.addTrade(new Trade(DateTime.Parse("10 Jan 2004"), DateTime.Parse("17 March 2005"), 100.0, 120.00, 0.20, -2000, PutCallType.CALL, "JJ100", 100.00, .25));
			portfolio.addTrade(new Trade(DateTime.Parse("10 Jun 2004"), DateTime.Parse("17 March 2005"), 100.0, 100.00, 0.18, 1000, PutCallType.PUT, "JJ100", 100.00, .25));
			portfolio.addTrade(new Trade(DateTime.Parse("10 Dec 2004"), DateTime.Parse("17 March 2005"), 100.0, 120.00, 0.22, 1000, PutCallType.PUT, "JJ101", 100.00, .25));
			return portfolio;
		}

	}
}
