using System;
using System.Collections;

namespace LivingFinance.Options.Equity.Portfolios
{
	public class PortfolioFilter
	{
		public static Portfolio filterByExpiry(Portfolio portfolio, DateTime expiry_date)
		{
			Portfolio result = new Portfolio();

			IEnumerator i = portfolio.getTradeEnumerator();
			while (i.MoveNext())
			{
				Trade trade = (Trade) i.Current;
				if (trade.expiry_date == expiry_date)
				{
					result.addTrade(trade);
				}
			}

			return result;
		}
	}
}
