using System;

namespace LivingFinance.Options.Equity.Portfolios
{
	public class PortfolioReadError
	{
		public int line_number;
		public string line_text;
		public string error;
		
		public PortfolioReadError(int aline_number, string aline_text, string aerror)
		{
			line_number = aline_number;
			line_text = aline_text;
			error = aerror;
		}

		public override string ToString()
		{
			return line_number + ": " + error;
		}

	}
}
