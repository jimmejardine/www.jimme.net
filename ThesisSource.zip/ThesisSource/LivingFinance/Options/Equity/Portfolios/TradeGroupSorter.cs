using System;
using System.Collections;

namespace LivingFinance.Options.Equity.Portfolios
{
	/// <summary>
	/// Summary description for TradeGroupSorter.
	/// </summary>
	public class TradeGroupSorter : IComparer
	{
		public System.Int32 Compare(System.Object x, System.Object y)
		{
			DictionaryEntry x_dict = (DictionaryEntry) x;
			DictionaryEntry y_dict = (DictionaryEntry) y;

			Portfolio x_portfolio = (Portfolio) x_dict.Value;
			Portfolio y_portfolio = (Portfolio) y_dict.Value;

			Trade x_trade = x_portfolio.getFirstTrade();
			Trade y_trade = y_portfolio.getFirstTrade();

			Double x_double = Double.Parse(x_trade.trade_group);
			Double y_double = Double.Parse(y_trade.trade_group);

			return x_double.CompareTo(y_double);
		}
	}
}
