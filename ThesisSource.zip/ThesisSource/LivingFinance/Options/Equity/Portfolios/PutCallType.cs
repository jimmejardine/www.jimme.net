using System;
using Utilities;

namespace LivingFinance.Options.Equity.Portfolios
{
	public class PutCallType
	{
		string description;
		public static PutCallType PUT = new PutCallType("Put");
		public static PutCallType CALL = new PutCallType("Call");

		public static PutCallType Parse(string type)
		{
			switch (type)
			{
				case "C" : return CALL;
				case "c" : return CALL;
				case "Call" : return CALL;
				case "call" : return CALL;

				case "P" : return PUT;
				case "p" : return PUT;
				case "Put" : return PUT;
				case "put" : return PUT;

				default : throw new GenericException("Unknown type " + type);
			}
		}

		public static void ThrowUnknownType(PutCallType type)
		{
			throw new GenericException("Unknown option type: " + type.ToString());
		}

		public static void ThrowUnknownType()
		{
			throw new GenericException("Unknown option type");
		}

		private PutCallType(string adescription)
		{
			description = adescription;
		}

		public override string ToString()
		{
			return description;
		}
	}
}
