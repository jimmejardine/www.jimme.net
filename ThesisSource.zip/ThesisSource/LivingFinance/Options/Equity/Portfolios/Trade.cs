using System;
using System.Text;

using Utilities;

namespace LivingFinance.Options.Equity.Portfolios
{
	public class Trade
	{
		public DateTime trade_date;
		public DateTime expiry_date;
		public double future;
		public double strike;
		public double volatility;
		public double quantity;
		public PutCallType putcalltype;
		public string trade_group;
		public double mtm_future;
		public double atm_vol;
		
		public Trade()
		{
		}

		public Trade(DateTime atrade_date, DateTime aexpiry_date, double afuture, double astrike, double avolatility, double aquantity, PutCallType aputcalltype, string atrade_group, double amtm_future, double aatm_vol)
		{
			trade_date = atrade_date;
			expiry_date = aexpiry_date;
			future = afuture;
			strike = astrike;
			volatility = avolatility;
			quantity = aquantity;
			putcalltype = aputcalltype;
			trade_group = atrade_group;
			mtm_future = amtm_future;
			atm_vol = aatm_vol;
		}

		public double tau
		{
			get
			{
				TimeSpan timespan = expiry_date.Subtract(trade_date);
				return timespan.Days / 365.0;
			}
		}

		public string dump()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("Trade: date={0} vol={1} strike={2} expiry={3}\n", this.trade_date, this.volatility, this.strike, this.expiry_date);
			return sb.ToString();
		}



	}
}
