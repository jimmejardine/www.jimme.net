using System;

namespace LivingFinance.Options.Equity.IncompleteMarkets.BrittenJones
{
	public class Grid
	{
		int num_space_steps;
		int num_time_steps;
		double[,] S;


		public Grid(int anum_space_steps, int anum_time_steps)
		{
			num_space_steps = anum_space_steps;
			num_time_steps = anum_time_steps;
			S = new double[num_space_steps*2+1, num_time_steps+1];
		}

		public string dump()
		{
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			for (int i = -num_space_steps; i <= num_space_steps; ++i)
			{
				for (int j = 0; j <= num_time_steps; ++j)
				{
					sb.AppendFormat("{0:E}\t", this[i,j]);
				}
				sb.AppendFormat("\n");
			}

			return sb.ToString();
		}

		public double this[int s, int t]
		{
			get
			{
				return S[s+num_space_steps, t];
			}

			set
			{
				S[s+num_space_steps, t] = value;
			}
		}
	}
}
