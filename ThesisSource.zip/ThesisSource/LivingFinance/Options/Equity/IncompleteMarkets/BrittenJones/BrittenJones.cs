using System;
using System.Collections;

using LivingFinance.Options.Equity.Portfolios;
using Utilities;

namespace LivingFinance.Options.Equity.IncompleteMarkets.BrittenJones
{
	public class BrittenJones
	{
		public static void calculatePrice(double S0, double K, PutCallType type, int num_steps, double delta, int MAX_JUMP_SIZE_POSITIVE, int MAX_JUMP_SIZE_NEGATIVE, out double jump_price, out double binomial_price)
		{
			Grid S = new Grid(num_steps, num_steps);
			Grid V = new Grid(num_steps, num_steps);
			Grid V_binomial = new Grid(num_steps, num_steps);

			// Populate the S grid
			double S_positive = S0;
			double S_negative = S0;
			for (int i = 0; i <= num_steps; ++i)
			{
				for (int j = 0; j <= num_steps; ++j)
				{
					S[+i, j] = S_positive;
					S[-i, j] = S_negative;
				}

				S_positive = S_positive * Math.Exp(delta);
				S_negative = S_negative / Math.Exp(delta);
			}

			// Populate the terminal V grid
			for (int i = 0; i <= num_steps; ++i)
			{
				if (PutCallType.CALL == type)
				{
					V[+i, 0] = Math.Max(S[+i, 0] - K, 0.0);
					V[-i, 0] = Math.Max(S[-i, 0] - K, 0.0);

					V_binomial[+i, 0] = Math.Max(S[+i, 0] - K, 0.0);
					V_binomial[-i, 0] = Math.Max(S[-i, 0] - K, 0.0);
				}
				else if (PutCallType.PUT == type)
				{
					V[+i, 0] = Math.Max(K - S[+i, 0], 0.0);
					V[-i, 0] = Math.Max(K - S[-i, 0], 0.0);

					V_binomial[+i, 0] = Math.Max(K - S[+i, 0], 0.0);
					V_binomial[-i, 0] = Math.Max(K - S[-i, 0], 0.0);
				}
				else
				{
					PutCallType.ThrowUnknownType(type);
				}
			}

//			System.Console.WriteLine();
//			System.Console.WriteLine("--- S is ------------------------------------------");
//			System.Console.WriteLine(S.dump());
			
			for (int j = 1; j <= num_steps; ++j)
			{
				for (int i = -num_steps+j; i <= num_steps-j; ++i)
				{
					// Find the eligible destination points in the grid
					ArrayList pool_positive = new ArrayList();
					for (int n = 1; n*n <= j && n*n <= MAX_JUMP_SIZE_POSITIVE*MAX_JUMP_SIZE_POSITIVE; ++n)
					{
						pool_positive.Add(new Point2D(S[i+n,j-n*n], V[i+n,j-n*n]));
					}
					ArrayList pool_negative = new ArrayList();
					for (int n = 1; n*n <= j && n*n <= MAX_JUMP_SIZE_NEGATIVE*MAX_JUMP_SIZE_NEGATIVE; ++n)
					{
						pool_negative.Add(new Point2D(S[i-n,j-n*n], V[i-n,j-n*n]));
					}

					// Find our convex hull
					double m, c;
					Utilities.Mathematics.Optimisation.ConvexHull.ConvexHull2Pool.findHull(pool_positive, pool_negative, out m, out c);
					V[i, j] = c + m * S[i, j];

//					Utilities.GUI.Charting.GenericChartForm charts = new Utilities.GUI.Charting.GenericChartForm();
//					charts.setChartCounts(1,1);
//					charts[0].addSeries(new Utilities.GUI.Charting.Series("Positive", Utilities.GUI.Charting.ChartType.Point, pool_positive));
//					charts[0].addSeries(new Utilities.GUI.Charting.Series("Negative", Utilities.GUI.Charting.ChartType.Point, pool_negative));
//					charts[0].Refresh();
//					charts.ShowDialog();

					// The usual binomial tree condition
					double u = Math.Exp(delta);
					double d = Math.Exp(-delta);
					V_binomial[i, j] = (1.0 - d) * V_binomial[i+1, j-1] / (u - d) + (u - 1.0) * V_binomial[i-1, j-1] / (u - d);
				}
			}

//			System.Console.WriteLine();
//			System.Console.WriteLine("--- V is ------------------------------------------");
//			System.Console.WriteLine(V.dump());
//
//			System.Console.WriteLine();
//			System.Console.WriteLine("--- V_binomial is ------------------------------------------");
//			System.Console.WriteLine(V_binomial.dump());
//
//			// The final call option value
//			System.Console.WriteLine("FINAL OPTION VALUE IS {0} compared to binomial model of {1}", V[0, num_steps], V_binomial[0, num_steps]);

			// Return the results
			jump_price = V[0, num_steps];
			binomial_price = V_binomial[0, num_steps];
		}

		public static void TestHarness()
		{
			ArrayList prices_jump2x2 = new ArrayList();
			ArrayList prices_jump5x5 = new ArrayList();
			ArrayList prices_jump2x5 = new ArrayList();
			ArrayList prices_jump5x2 = new ArrayList();
			ArrayList prices_binomial = new ArrayList();
			
			ArrayList vols_jump2x2 = new ArrayList();
			ArrayList vols_jump5x5 = new ArrayList();
			ArrayList vols_jump2x5 = new ArrayList();
			ArrayList vols_jump5x2 = new ArrayList();
			ArrayList vols_binomial = new ArrayList();

			PutCallType TYPE = PutCallType.CALL;
			double STRIKE = 100.00;
			int TIMESTEPS = 75;
			double DELTA = 0.02;
			double T = 1.0;

			for (double i = STRIKE*0.6; i <= STRIKE*1.4; i += 2)
			{
				double jump_price2x2, jump_price5x5, jump_price2x5, jump_price5x2, binomial_price;
				calculatePrice(i, STRIKE, TYPE, TIMESTEPS, DELTA, 2, 2, out jump_price2x2, out binomial_price);
				calculatePrice(i, STRIKE, TYPE, TIMESTEPS, DELTA, 5, 5, out jump_price5x5, out binomial_price);
				calculatePrice(i, STRIKE, TYPE, TIMESTEPS, DELTA, 2, 5, out jump_price2x5, out binomial_price);
				calculatePrice(i, STRIKE, TYPE, TIMESTEPS, DELTA, 5, 2, out jump_price5x2, out binomial_price);

				prices_jump2x2.Add(new Point2D(i, jump_price2x2));
				prices_jump5x5.Add(new Point2D(i, jump_price5x5));
				prices_jump2x5.Add(new Point2D(i, jump_price2x5));
				prices_jump5x2.Add(new Point2D(i, jump_price5x2));
				prices_binomial.Add(new Point2D(i, binomial_price));

				double jump_vol2x2, jump_vol5x5, jump_vol2x5, jump_vol5x2, binomial_vol;
				jump_vol2x2 = LivingFinance.Options.Vanilla.ImpliedVolatility.calculateImpliedVol(TYPE, STRIKE, T, i, 0, 0, jump_price2x2);
				jump_vol5x5 = LivingFinance.Options.Vanilla.ImpliedVolatility.calculateImpliedVol(TYPE, STRIKE, T, i, 0, 0, jump_price5x5);
				jump_vol2x5 = LivingFinance.Options.Vanilla.ImpliedVolatility.calculateImpliedVol(TYPE, STRIKE, T, i, 0, 0, jump_price2x5);
				jump_vol5x2 = LivingFinance.Options.Vanilla.ImpliedVolatility.calculateImpliedVol(TYPE, STRIKE, T, i, 0, 0, jump_price5x2);
				binomial_vol = LivingFinance.Options.Vanilla.ImpliedVolatility.calculateImpliedVol(PutCallType.CALL, 100.0, 1.0, i, 0, 0, binomial_price);

				vols_jump2x2.Add(new Point2D(i, jump_vol2x2));
				vols_jump5x5.Add(new Point2D(i, jump_vol5x5));
				vols_jump2x5.Add(new Point2D(i, jump_vol2x5));
				vols_jump5x2.Add(new Point2D(i, jump_vol5x2));
				vols_binomial.Add(new Point2D(i, binomial_vol));
			}

			Utilities.GUI.Charting.GenericChartForm charts = new Utilities.GUI.Charting.GenericChartForm();
			charts.Text = "Plots of jump model results";
			charts.BackColor = System.Drawing.Color.White;
			charts.setChartCounts(2,1);

			charts[0].title = "Price against S0";
			charts[0].x_axis_title = "Stock price";
			charts[0].y1_axis_title = "Option price";
			charts[0].addSeries(new Utilities.GUI.Charting.Series("Jump2x2", Utilities.GUI.Charting.ChartType.Line, prices_jump2x2));
			charts[0].addSeries(new Utilities.GUI.Charting.Series("Jump5x5", Utilities.GUI.Charting.ChartType.Line, prices_jump5x5));
			charts[0].addSeries(new Utilities.GUI.Charting.Series("Jump2x5", Utilities.GUI.Charting.ChartType.Line, prices_jump2x5));
			charts[0].addSeries(new Utilities.GUI.Charting.Series("Jump5x2", Utilities.GUI.Charting.ChartType.Line, prices_jump5x2));
			charts[0].addSeries(new Utilities.GUI.Charting.Series("Binomial", Utilities.GUI.Charting.ChartType.Line, prices_binomial));

			charts[1].title = "Implied vol against S0";
			charts[1].x_axis_title = "Stock price";
			charts[1].y1_axis_title = "Impliedvolatility";
			charts[1].addSeries(new Utilities.GUI.Charting.Series("Jump2x2", Utilities.GUI.Charting.ChartType.Line, vols_jump2x2));
			charts[1].addSeries(new Utilities.GUI.Charting.Series("Jump5x5", Utilities.GUI.Charting.ChartType.Line, vols_jump5x5));
			charts[1].addSeries(new Utilities.GUI.Charting.Series("Jump2x5", Utilities.GUI.Charting.ChartType.Line, vols_jump2x5));
			charts[1].addSeries(new Utilities.GUI.Charting.Series("Jump5x2", Utilities.GUI.Charting.ChartType.Line, vols_jump5x2));
			charts[1].addSeries(new Utilities.GUI.Charting.Series("Binomial", Utilities.GUI.Charting.ChartType.Line, vols_binomial));
			
			charts.ShowDialog();
		}
	}
}
