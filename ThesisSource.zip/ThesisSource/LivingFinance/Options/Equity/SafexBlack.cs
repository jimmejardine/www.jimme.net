using System;

namespace LivingFinance.Options.Equity
{
	public class SafexBlack
	{
		public static double d1(double F, double X, double sigma, double tau)
		{
			return (Math.Log(F/X) + 0.5 * sigma * sigma * tau) / (sigma * Math.Sqrt(tau));
		}

		public static double d2(double F, double X, double sigma, double tau)
		{
			return d1(F, X, sigma, tau) - (sigma * Math.Sqrt(tau));
		}

		public static double priceCall(double F, double X, double sigma, double tau)
		{
			return F * N(d1(F,X,sigma,tau)) - X * N(d2(F,X,sigma,tau));
		}

		public static double pricePut(double F, double X, double sigma, double tau)
		{
			return X * N(-d2(F,X,sigma,tau)) - F * N(-d1(F,X,sigma,tau));
		}

		public static double vega(double F, double X, double sigma, double tau)
		{
			return F * Math.Sqrt(tau) * Ndash(d1(F,X,sigma,tau));
		}

		public static double volga(double F, double X, double sigma, double tau)
		{
			return vega(F,X,sigma,tau) * d1(F,X,sigma,tau) * d2(F,X,sigma,tau) / sigma;
		}

		static double N(double x)
		{
			return Utilities.Mathematics.Statistics.Distributions.Distributions.CDistStandardNormal(x);
		}

		static double Ndash(double x)
		{
			return Utilities.Mathematics.Statistics.Distributions.Distributions.DStandardNormal(x);
		}

	}
}
